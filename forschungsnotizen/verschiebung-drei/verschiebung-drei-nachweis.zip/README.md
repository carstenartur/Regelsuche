# Die Verschiebung um drei, Nachweis zum Nachtrag vom 28. November 2026

## Kurzprüfung aus dem beiliegenden Katalog

`python3 -B pruefen.py` benötigt Python 3.8 oder neuer mit Standardbibliothek. Der Lauf prüft die Wurzelklammer, sämtliche Restklassenphasen, die notwendigen Gewinne, den Hash des ausgepackten Katalogs, dessen Zeitpunkte, die erste offene Stelle mit zwei Verfahren sowie die rationale Schlussabschätzung. Mit `python3 -B src/check_shift_three_four_blockers.py` lässt sich zusätzlich ein Beispiel mit künstlich vorgegebener Vorgeschichte rechnen.

Der Katalog enthält für jede im kanonischen Präfix bis 140.000.000 gesättigte Primzahl die fehlende Restklasse und den ersten Offset der Sättigung. Seine Vollständigkeit und die Chronologie der Greedy-Aufnahmen lassen sich durch den folgenden längeren Lauf aus der Definition herstellen und prüfen. Alle Quellen liegen bei. Der native Präfixprüfer benötigt die OpenSSL-Entwicklungsdateien und libcrypto.

```sh
mkdir -p work
c++ -std=c++20 -O3 src/generator.cpp -o work/generator
c++ -std=c++20 -O3 src/verify_prefix.cpp -lcrypto -o work/verify_prefix
c++ -std=c++20 -O3 src/saturation_chronology.cpp -o work/saturation
work/generator 140000000 work/run
work/verify_prefix 140000000 work/run.u32 work/run-frozen.csv work/verified.json work/missing.csv
work/saturation derive 140000000 work/run.u32 work/catalogue.csv
work/saturation verify 140000000 work/run.u32 work/catalogue.csv
python3 -B src/check_shift_three_frontier.py 140000000 work/run.u32 work/catalogue.csv --future-stop 140136240
```

Die letzte Zeile gleicht die SHA-256-Werte der neu erzeugten Daten und die vollständige Ergebnistabelle mit `validation/shift-three-frontier-140m.json` ab. Die Prüfdaten enthalten 7.576.936 Folgenglieder einschließlich der Null. Das letzte ist 139.999.992. Die mathematischen Voraussetzungen und der Schluss von der endlichen Rechnung auf das Supremum stehen in der zugehörigen Forschungsnotiz.
