#!/usr/bin/env python3
"""Offline short verification of the shift-three bound from the saturation catalogue."""

import csv
import gzip
import hashlib
import json
import sys
from collections import Counter
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "src"))
from check_shift_three_crt import ROOT_HIGH, ROOT_LOW, greedy_through, require
from check_shift_three_four_blockers import FIRST, LATER, phase_bounds
from check_shift_three_frontier import allowed_fourth, marked_windows


def check():
    prefix = greedy_through(160)
    lower_sum = sum(ROOT_LOW**(g + 3) for g in prefix)
    upper_sum = sum(ROOT_HIGH**(g + 3) for g in prefix)
    require(lower_sum + ROOT_LOW**164 / (1 - ROOT_LOW) < 1 < upper_sum, "root bracket")
    q = Fraction(157, 200)
    phases = [0, 2, 6, 8, 12, 18, 20, 26]
    require(q**2 + q**6 + q**10 < 1, "first departure at 2")
    require((q**2 + q**6) / (1 - q**6) - q**2 < 1, "first departure at 6")
    require((q**4 + q**6) / (1 - q**6) < 1, "first departure at 8")
    for phase in phases[1:]:
        mass = sum(q**j for j in range(1, 31) if (phase + j) % 30 in phases)
        require(mass / (1 - q**30) < 1, "nonzero wheel phase")
    phase_bounds()
    reference = json.loads((ROOT / "validation/shift-three-frontier-140m.json").read_text())
    raw = gzip.decompress((ROOT / "catalogue.csv.gz").read_bytes())
    require(hashlib.sha256(raw).hexdigest() == reference["catalogue_sha256"], "catalogue digest")
    rules = [(int(row["prime"]), int(row["missing_residue"]), int(row["saturation_g"]))
             for row in csv.DictReader(raw.decode("ascii").splitlines())]
    require(len(rules) == reference["saturated_primes"], "number of rows")
    times = Counter(t for _, _, t in rules)
    counts = {str(k): v for k, v in Counter(times.values()).items()}
    require(counts == reference["simultaneous_saturations_count_by_multiplicity"],
            "saturation multiplicities")
    aligned = [(p, b, t) for p, b, t in rules if t > 8 and t % 30 == 0]
    require(len(aligned) == reference["phase_zero_saturations_after_eight"], "aligned rows")
    require(not any((t + d) % p == b for p, b, t in aligned for d in FIRST), "fresh blocker")
    T = reference["first_unexcluded_future_start_by_five_point_old_sieve"]
    X = reference["cutoff"]
    expected = [(T, [12])]
    by_progressions = marked_windows(X + 1, T, rules)
    by_division = []
    for t in range((X // 30 + 1) * 30, T + 1, 30):
        offsets = allowed_fourth(t, rules)
        if offsets:
            by_division.append((t, offsets))
    require(by_division == by_progressions == expected, "first window")
    require(ROOT_HIGH**5 < 1 - ROOT_HIGH**2, "tail prefactor")
    require(10**59 * ROOT_HIGH**560 < 1, "decimal exponent step")
    require(59 * (T // 560) == 14764337, "final decimal exponent")
    print(f"{len(rules)} saturation entries; {len(aligned)} in phase zero after 8")
    print(f"First open start {T}, fourth offset +12; upper bound 10^(-14764337)")


if __name__ == "__main__":
    check()
