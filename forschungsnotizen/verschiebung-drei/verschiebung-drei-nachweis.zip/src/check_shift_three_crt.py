#!/usr/bin/env python3
"""Check a conditioned greedy counterexample throughout a certified interval containing x_3.

Run with Python 3.8 or newer. The only prescribed canonical history is through
offset 12. The later CRT rows are chosen explicitly, before greedy choices resume.
"""

from fractions import Fraction
from math import isqrt, prod

ROOT_LOW = Fraction(784587368, 10**9)
ROOT_HIGH = Fraction(784587369, 10**9)
PREFIX_LIMIT = 12
HORIZON = 24
SPECIAL_PRIMES = (41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def primes_through(limit):
    return tuple(n for n in range(2, limit + 1)
                 if all(n % d for d in range(2, isqrt(n) + 1)))


def admissible(points):
    # Larger primes have more classes than there are points.
    return all(len({value % p for value in points}) < p
               for p in primes_through(len(points)))


def greedy_through(limit):
    chosen = set()
    for n in range(limit + 1):
        if admissible(chosen | {n}):
            chosen.add(n)
    return chosen


def crt(moduli, residues):
    value = 0
    period = 1
    for modulus, residue in zip(moduli, residues):
        step = (residue - value) * pow(period, -1, modulus) % modulus
        value += period * step
        period *= modulus
    return value


def make_history(prefix, gains):
    # Before t, precisely m and m+d are unoccupied modulo the prime for d.
    m = PREFIX_LIMIT + 1
    distances = range(2, HORIZON + 1, 2)
    require(len(SPECIAL_PRIMES) == len(distances), "one distinct prime per even offset")
    require(max(gains) <= HORIZON and min(SPECIAL_PRIMES) > m + HORIZON, "residue collision")
    row_count = max(SPECIAL_PRIMES) - 2
    cutoff = len(prefix) + row_count + len(gains) + 1
    primes = primes_through(cutoff)
    require(set(SPECIAL_PRIMES) <= set(primes), "the specified moduli must be prime")
    ordinary = tuple(p for p in primes if p not in SPECIAL_PRIMES)
    moduli = SPECIAL_PRIMES + ordinary
    period = prod(moduli)
    columns = [[r for r in range(p) if r not in (m, m + d)]
               for p, d in zip(SPECIAL_PRIMES, distances)]
    history = set(prefix)
    for i in range(row_count):
        residues = tuple(column[i % len(column)] for column in columns) + (0,) * len(ordinary)
        history.add(crt(moduli, residues) + (i + 1) * period)
    t = crt(moduli, (m,) * len(SPECIAL_PRIMES) + (0,) * len(ordinary)) + (row_count + 2) * period
    require(max(history) < t, "history must precede the first choice")
    return history, t


def check():
    greedy = greedy_through(160)
    # Every unseen offset is >=161. All exponents include the shift by three.
    upper_at_low = sum(ROOT_LOW ** (g + 3) for g in greedy) + ROOT_LOW**164 / (1 - ROOT_LOW)
    lower_at_high = sum(ROOT_HIGH ** (g + 3) for g in greedy)
    require(upper_at_low < 1 < lower_at_high, "independent x_3 bracket failed")

    prefix = {g for g in greedy if g <= PREFIX_LIMIT}
    gains = {g for g in greedy if 0 < g <= 20}
    require(prefix == {0, 2, 6, 8, 12}, "canonical prefix mismatch")
    require(gains == {2, 6, 8, 12, 18, 20}, "comparison offsets mismatch")
    history, t = make_history(prefix, gains)
    require({n for n in history if n <= PREFIX_LIMIT} == prefix, "initial membership changed")
    require(len(history) == 92 and t.bit_length() == 128, "construction changed")
    greedy_start = history | {t}
    require(admissible(greedy_start), "greedy must accept t")
    for d in range(1, HORIZON + 1):
        require(not admissible(greedy_start | {t + d}), f"unexpected greedy choice at +{d}")
    require(admissible(history | {t + b for b in gains}), "alternative is inadmissible")

    # Normalization divides out x^t (or x^(t+3) for shifted masses).
    # Opposite ends of the bracket bound both continuations uniformly at x_3.
    alternative_lower = sum(ROOT_LOW**b for b in gains)
    greedy_upper = 1 + ROOT_HIGH**(HORIZON + 1) / (1 - ROOT_HIGH)
    require(alternative_lower > Fraction(1067351, 10**6), "alternative bound changed")
    require(greedy_upper < Fraction(1010784, 10**6), "greedy bound changed")
    require(alternative_lower - greedy_upper > Fraction(56567, 10**6), "gain unproved")
    print(f"canonical prefix through {PREFIX_LIMIT}: {sorted(prefix)}")
    print(f"prescribed history size: {len(history)}, t: {t} ({t.bit_length()} bits)")
    print(f"unavailable after greedy accepts t: offsets 1 through {HORIZON}")
    print(f"x_3 lies between {ROOT_LOW} and {ROOT_HIGH}")
    print("normalized alternative > 1.067351, greedy < 1.010784, advantage > 0.056567")


if __name__ == "__main__":
    check()
