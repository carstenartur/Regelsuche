#!/usr/bin/env python3
"""Exact rational bounds and a CRT sharpness example for the fourth blocker."""

from fractions import Fraction
from math import prod

from check_shift_three_crt import (
    ROOT_HIGH, ROOT_LOW, admissible, crt, greedy_through, primes_through, require,
)

FIRST = (2, 6, 8)
LATER = (12, 18, 20)
HORIZON = 44


def phase_bounds():
    phases = [d for d in range(1, 31) if d % 2 == 0 and d % 3 != 1 and d % 5 != 4]
    upper = sum(ROOT_HIGH ** d for d in phases) / (1 - ROOT_HIGH ** 30)
    # The first subtraction removes a possible gain. A G-only offset costs once more.
    require(upper - ROOT_HIGH**12 - ROOT_LOW**12 < Fraction(97, 100),
            "an uncompensated loss at 12 is too expensive")
    require(upper - ROOT_HIGH**12 - ROOT_HIGH**18 - ROOT_LOW**18 < Fraction(1),
            "a loss at 18 is too expensive without a gain at 12")
    require(upper - sum(ROOT_HIGH ** d for d in LATER) < 1, "fourth gain required")
    require(all(upper - ROOT_HIGH**d < 1 for d in FIRST), "three compulsory gains")


def sharp_history(prefix_limit=20):
    # t has residue m at all special primes. The fourth prime is activated
    # by t+18, the final common positive increment before the rival gains +20.
    blocked = [d for d in range(2, HORIZON + 1, 2) if d not in FIRST + LATER]
    require(prefix_limit >= 20, "the common seed contains all comparison offsets")
    prefix = greedy_through(prefix_limit)
    m = prefix_limit + 1
    bound = 2 * (m + HORIZON)
    special = []
    while len(special) < 4 + len(blocked):
        special = [p for p in primes_through(bound) if p > m + HORIZON]
        bound *= 2
    special = special[:4 + len(blocked)]
    avoided = [{m, m + d} for d in FIRST] + [{m, m + 12, m + 18, m + 20}]
    avoided += [{m + d} for d in blocked]
    columns = [[r for r in range(p) if r not in empty]
               for p, empty in zip(special, avoided)]
    count = max(map(len, columns))
    # This also checks every possibly saturated prime, including |history|+7.
    moduli = primes_through(count + len(prefix) + len(FIRST + LATER) + 1)
    require(set(special) <= set(moduli), "incomplete prime range")
    ordinary = [p for p in moduli if p not in special]
    ordered = special + ordinary
    period = prod(ordered)
    history = prefix | {
        period + crt(ordered, [column[i % len(column)] for column in columns] + [0] * len(ordinary))
        for i in range(count)
    }
    t = crt(ordered, [m] * len(special) + [0] * len(ordinary)) + 2 * period
    require(len(history) == count + len(prefix) and t > max(history), "invalid CRT history")
    require({n for n in history if n <= prefix_limit} == prefix, "canonical seed changed")
    return history, t, special[:4], moduli


def saturated(points, moduli):
    return {p for p in moduli if len({n % p for n in points}) == p - 1}


def check():
    phase_bounds()
    prefix = greedy_through(160)
    require(sum(ROOT_LOW ** (g + 3) for g in prefix) + ROOT_LOW**164 / (1-ROOT_LOW) < 1
            < sum(ROOT_HIGH ** (g + 3) for g in prefix), "root bracket failed")
    history, t, special, moduli = sharp_history()
    require(admissible(history), "inadmissible common history")
    before = saturated(history, moduli)
    greedy = history.copy()
    chosen = []
    activations = {}
    for d in range(HORIZON + 1):
        if admissible(greedy | {t + d}):
            chosen.append(d)
            greedy.add(t + d)
            after = saturated(greedy, moduli)
            activations[d] = after - before
            before = after
    require(chosen == [0, 12, 18], "unexpected greedy continuation")
    require(activations[0] == set(special[:3]), "exactly three activations required at t")
    require(special[3] in activations[18], "fourth prime should first activate at +18")
    require(all((t+d) % p not in {n % p for n in greedy}
                for p, d in zip(special, FIRST + (20,))), "wrong missing classes in greedy")
    alternative = history | {t + d for d in FIRST + LATER}
    require(admissible(alternative), "inadmissible alternative")
    for p in special:
        require({n % p for n in alternative} == set(range(p)) - {t % p},
                "wrong missing class in the alternative")
    # Both sides contain +12 and +18. Bound the unknown greedy tail, even if
    # every further integer is admitted. All comparisons are exact rationals.
    gain = sum(ROOT_LOW ** d for d in FIRST + (20,))
    upper = 1 + ROOT_HIGH ** (HORIZON + 1) / (1 - ROOT_HIGH)
    require(gain - upper > Fraction(15, 100000), "sharpness margin failed")
    print(f"prescribed points: {len(history)}; t has {t.bit_length()} bits")
    print(f"three blockers at t: {special[:3]}; fourth at t+18: {special[3]}")
    print("normalized advantage at x_3 > 0.00015")


if __name__ == "__main__":
    check()
