#!/usr/bin/env python3
"""Audit necessary shift-three windows from a complete, natively checked catalogue."""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path

from check_shift_three_crt import ROOT_HIGH, require
from check_shift_three_four_blockers import FIRST, LATER, phase_bounds


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            result.update(block)
    return result.hexdigest()


def allowed_fourth(t, rules):
    """Distances for which the entire five-point set avoids every old missing class."""
    later = set(LATER)
    for p, missing, _ in rules:
        distance = (missing - t) % p
        if p > max(LATER):
            if distance in (0,) + FIRST:
                return []
            later.discard(distance)
        else:
            if any(d % p == distance for d in (0,) + FIRST):
                return []
            later = {d for d in later if d % p != distance}
        if not later:
            return []
    return sorted(later)


def marked_windows(low, last, rules):
    # Independent enumeration by striking arithmetic progressions over a block,
    # instead of visiting possible starts and testing each modulus in turn.
    width = last + max(LATER) - low + 1
    live = bytearray([1]) * width
    for p, missing, _ in rules:
        begin = (missing - low) % p
        if begin < width:
            live[begin::p] = bytes((width - 1 - begin) // p + 1)
    windows = []
    for t in range(low, last + 1):
        if t % 30 == 0 and all(live[t - low + d] for d in (0,) + FIRST):
            distances = [d for d in LATER if live[t - low + d]]
            if distances:
                windows.append((t, distances))
    return windows


def audit(limit, terms, catalogue, future_stop):
    with catalogue.open(encoding="ascii", newline="") as stream:
        rules = [(int(row["prime"]), int(row["missing_residue"]), int(row["saturation_g"]))
                 for row in csv.DictReader(stream)]
    require(rules and all(0 <= b < p and 0 <= t <= limit for p, b, t in rules),
            "malformed or out-of-range saturation")
    require(all(a[0] < b[0] for a, b in zip(rules, rules[1:])), "unordered prime catalogue")
    all_times = Counter(t for _, _, t in rules)
    aligned = defaultdict(set)
    hits = []
    for p, b, t in rules:
        if t > 8 and t % 30 == 0:
            for d in FIRST:
                if (t + d) % p == b:
                    aligned[t].add(d)
                    hits.append([t, d, p])
    triples = sorted(t for t in aligned if len(aligned[t]) == len(FIRST))
    require(not triples, f"the triple-only certificate does not resolve {triples}")
    # At any later first difference, t belongs to G and the four H additions
    # share its entire prefix through limit. All five must avoid every old b_p.
    for t in range((limit // 30 + 1) * 30, future_stop + 1, 30):
        possible = allowed_fourth(t, rules)
        if possible:
            first = t
            break
    else:
        raise ValueError("increase the future search bound to locate the first surviving window")
    require(marked_windows(limit + 1, first, rules) == [(first, possible)],
            "independent progression sieve disagrees")
    require(ROOT_HIGH**560 * 10**59 < 1,
            "exact 560-step decimal bound failed")
    require(ROOT_HIGH**5 < 1 - ROOT_HIGH**2, "geometric prefactor bound")
    return {
        "cutoff": limit,
        "terms_sha256": digest(terms),
        "catalogue_sha256": digest(catalogue),
        "saturated_primes": len(rules),
        "simultaneous_saturations_count_by_multiplicity": dict(sorted(Counter(all_times.values()).items())),
        "phase_zero_saturations_after_eight": sum(n for t, n in all_times.items() if t > 8 and t % 30 == 0),
        "phase_zero_new_blockers_at_compulsory_offsets": hits,
        "phase_zero_simultaneous_compulsory_triples": triples,
        "first_unexcluded_future_start_by_five_point_old_sieve": first,
        "permitted_fourth_distances_at_that_start": possible,
        "decimal_exponent_strict_upper_bound_for_mass_excess": 59 * (first // 560),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("cutoff", type=int)
    parser.add_argument("terms", type=Path)
    parser.add_argument("catalogue", type=Path)
    parser.add_argument("--future-stop", type=int, required=True)
    reference_path = (Path(__file__).resolve().parents[1] / "validation" /
                      "shift-three-frontier-140m.json")
    parser.add_argument("--check", type=Path, default=reference_path)
    args = parser.parse_args()
    phase_bounds()
    report = audit(args.cutoff, args.terms, args.catalogue, args.future_stop)
    require(json.loads(args.check.read_text(encoding="utf-8")) == json.loads(json.dumps(report)),
            "reference differs")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
