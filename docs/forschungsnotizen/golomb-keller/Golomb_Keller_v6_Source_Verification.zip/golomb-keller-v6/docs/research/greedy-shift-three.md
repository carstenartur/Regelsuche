# Greedy-Optimalität bei Verschiebung um drei

17. November 2026 · Die [Arbeitsfassung des Manuskripts](../review/golomb-keller/v5-draft/README.md) enthält den vollständigen Beweis für die Verschiebung um zwei. Diese Untersuchung behandelt die nächste Wurzel. Sie verwendet ausschließlich die kombinatorische Zulässigkeit von Offsetmengen.

Ein [weiterführender Beweis](greedy-exchange-threshold.md) erreicht die Wurzel der positiven Greedy-Masse einschließlich des Randpunkts. Dort steht auch die genaue Chronologie der Restklassensättigungen bis $10^8$.

## Frage und exakte Vergleichspunkte

Eine normalisierte zulässige Menge enthält 0 und lässt modulo jeder Primzahl mindestens eine Restklasse aus. Die Greedy-Folge $G$ nimmt der Reihe nach jeden Offset auf, dessen Hinzunahme diese Bedingung erhält. Sie beginnt mit $0,2,6,8,12,18,20,26$. Für die eindeutige Wurzel $x_3$ der Gleichung $\sum_{g\in G} x_3^{g+3}=1$ fragen wir, ob jede andere solche Menge $S$ eine strikt kleinere Summe hat. Die Eindeutigkeit der Wurzel folgt aus Stetigkeit, strikter Monotonie und der Unendlichkeit von $G$.

Der exakte Vergleich des Präfixes bis 160 mit einem geometrischen Rest ergibt

$$0{,}784587368 < x_3 < 0{,}784587369.$$

Für die folgenden Beweise genügt $x_3<q=157/200$. Schon die Summe über die Greedy-Offsets bis 20 übersteigt bei $q$ die Eins. Gewichte werden im Folgenden durch den positiven gemeinsamen Faktor $x^{t+3}$ geteilt, wobei $t$ die erste unterschiedliche Position bezeichnet. Dort enthält $G$ den Offset, während $S$ ihn auslässt: Hätte Greedy einen früher gemeinsam möglichen Offset verworfen, wäre das zugehörige endliche Hindernis auch in $S$ enthalten.

## Notwendige Bedingung für Gleichstand und Verbesserung

Für $t>8$ stehen $0,2,6,8$ im gemeinsamen Präfix. Die möglichen Positionen beider Mengen liegen damit in

$$R=\{0,2,6,8,12,18,20,26\}\pmod {30}.$$

Die Bedingung folgt aus den ausgelassenen Klassen 1 modulo 2, 1 modulo 3 und 4 modulo 5. Für jede der acht zulässigen Phasen $r=t\bmod30$ lautet die normierte obere Schranke für spätere Beiträge

$$T_r(x)=\frac{\sum_{1\le j\le30,\ (r+j)\bmod30\in R}x^j}{1-x^{30}}.$$

Alle folgenden oberen Abschätzungen betreffen die positiven Gewichte aus $S\setminus G$. Gemeinsame Elemente fallen weg. Nach Streichung bestimmter Monome bleiben Reihen mit nichtnegativen Koeffizienten, sodass die Kontrolle bei $q$ für jedes kleinere $x>0$ gilt.

* Für die sieben von null verschiedenen Phasen gilt $T_r(q)<0{,}953$. Der größte Wert liegt bei $r=6$.
* Für $r=0$ gilt $T_0(q)<1{,}074$. Entfernt man eines der Gewichte mit $j=2,6,8$, ist der größte verbleibende Wert $T_0(q)-q^8<0{,}929$. Ohne alle drei Beiträge aus $S\setminus G$ ist der Verlust bei $t$ daher strikt größer als der spätere Gewinn.
* Für dieselbe Phase gilt außerdem $T_0(q)-q^{12}-q^{18}-q^{20}<0{,}998$. Mindestens einer dieser drei weiteren Offsets muss ebenfalls zu $S\setminus G$ gehören.

Die Anfangsfälle benötigen die bereits festgelegten Klassen modulo 2 und 3. Für $t=2$ liefert der größtmögliche spätere Rest von $S$ die Schranke $(x^2+x^4)/(1-x^6)$, während $G$ bereits bei 2 und 6 die normierte Masse $1+x^4$ enthält. Die strikte Ungleichung ist äquivalent zu $x^2+x^6+x^{10}<1$ und gilt bei $q$. Für $t=6$ fällt das mögliche Zusatzgewicht $x^2$ weg, da $8\in G$. Die Schranke $(x^2+x^6)/(1-x^6)-x^2$ ist bei $q$ kleiner als $0{,}494$. Für $t=8$ ist die Schranke $(x^4+x^6)/(1-x^6)$ bei $q$ kleiner als $0{,}802$.

## Was zur selben Zeit in der Greedy-Folge geschehen müsste

Somit müsste $t\equiv0\pmod{30}$ gelten. Bei $t+2,t+6,t+8$ müsste $S$ jeweils ein Element besitzen, das Greedy verwirft. Zwischen $t$ und $t+8$ kommen wegen $R$ keine weiteren Greedy-Elemente in Betracht. Für jede der drei Verwerfungen existiert eine Primzahl $p$, für die das bis dahin angenommene Präfix bereits $p-1$ Klassen belegt und der geprüfte Offset die letzte füllen würde. Vor $t$ durfte diese letzte Klasse noch nicht dauerhaft gesperrt sein, denn vor $t$ stimmen $G$ und $S$ überein. Folglich ist $t$ in jeder dieser drei Rechnungen der Schritt von $p-2$ auf $p-1$ belegte Klassen. Die drei Primzahlen sind verschieden: Die Klassen modulo 2, 3 und 5 erlauben die drei Offsets; eine größere Primzahl teilt keine ihrer paarweisen Differenzen 2, 4 und 6.

Das schränkt selbst jenseits jeder Rechengrenze die möglichen ersten Abweichungen ein. Unter den ersten $N$ Greedy-Elementen können höchstens $\pi(N+1)/3$ solche Positionen vorkommen. Jede verbraucht drei verschiedene Primzahlen $p\le N+1$ für deren einmaligen Übergang zu $p-1$ belegten Klassen. Damit geht der Anteil der verbleibenden Positionen unter den Greedy-Elementen gegen null. Diese Schranke entscheidet die Existenz einer einzelnen solchen Abweichung nicht.

## Endlicher Nachweis

Für die [zertifizierte Präfixrechnung](greedy-counting/README.md) stehen zu jeder ausgelassenen geraden Zahl Ausschlusszeugen zur Verfügung. Jeder Datensatz bindet eine Primzahl, ihre fehlende Klasse und einen Zeitpunkt, **vor dem bereits alle anderen Klassen besetzt waren**. Dieser aufgezeichnete erste Ausschluss ist nur eine obere Schranke für den tatsächlichen Zeitpunkt der Sättigung. Ein früher als $t$ aufgezeichnetes Zeugnis schließt die betreffende Position für $S$ aus.

Wird ein hypothetischer Zusatzoffset $t+d$ mit $d\in\{2,6,8\}$ ausgeschlossen, muss mindestens ein Zeuge für ihn vorliegen. Ein mit dem gemeinsamen Präfix verträglicher Zeuge kann erst bei $t+d$ aufgezeichnet worden sein: seine Primzahl ist größer als 5, ein früherer Treffer derselben Klasse unter den geraden Offsets läge mindestens $2p>8$ zurück. Daher ist ein erster Ausschlusseintrag bei **jeder** der drei Positionen eine notwendige, unmittelbar an den Daten prüfbare Bedingung.

Die maschinenlesbaren [Ergebnisse](greedy-counting/validation/shift-three-1e8.json) und der [Prüfer](greedy-counting/src/check_shift_three.py) binden Terme und Ausschlüsse an die beiden SHA-256-Werte der unabhängig geprüften Präfixdaten. Die zusätzliche Prüfung verwendet die bereits erzeugten Dateien. Ihre Reproduktion beginnt mit dem Generator und dem eigenständigen Präfixprüfer aus der oben verlinkten Anleitung.

Das Präfix enthält 5.522.856 Elemente und endet bei 99.999.972. Unter den 680.409 möglichen Starts in Phase null nach Offset 8 fehlen bei 349.318 die drei Greedy-Nachfolger. Von diesen Starts haben 348.258 keinen, 1.058 einen und zwei genau zwei erstmals aufgezeichnete Ausschlusspositionen unter den drei Pflichtstellen. Keiner hat alle drei. Ein zweiter Test markiert direkt alle Folgeglieder jeder bereits dokumentierten Ausschlussklasse; auch hier bleiben null Starts. Für den letzten Greedy-Offset liegt das gesamte Fenster bis $t+8$ innerhalb der geprüften Grenze.

**Folgerung.** Für jedes $0<x\le157/200$ schlägt $G$ jede normalisierte zulässige Menge strikt, deren erste Abweichung spätestens bei $N=10^8$ liegt. Dies folgt aus der uniformen Restrechnung und dem vollständigen Ausschluss sämtlicher zulässiger erster Abweichungen in diesem Bereich.

Darüber hinaus ergibt die endliche Prüfung eine Schranke für das **unendliche** Problem. Setze $F_3(x)=\sup_S\sum_{s\in S}x^{s+3}$. Bei $x_3$ gilt unbedingt

$$0\le F_3(x_3)-1 < 10^{-10\,000\,000}.$$

Wer überhaupt einen positiven Überschuss erzielt, muss den vollständigen Präfix bis $N$ teilen. Die gesamte danach noch mögliche positive Masse ist höchstens $x_3^{N+5}/(1-x_3^2)$, weil nur gerade Offsets vorkommen. Mit $u=79/100$ gelten $x_3<u$, $u^5<1-u^2$ und $u^{10}<1/10$. Dieselbe strikte obere Schranke gilt einheitlich für alle Konkurrenten und somit auch für das Supremum. Der Beweis lässt sowohl die exakte Gleichheit als auch einen tatsächlich positiven kleineren Überschuss zu.

Für die Extremalwurzel $z$ mit $F_3(z)=1$ folgt sogar $0\le x_3-z<10^{-10\,000\,000}/3$. Die supremale Masse ist stetig auf kompakten Teilintervallen von $(0,1)$ durch die uniforme geometrische Restschranke; sie wächst strikt, da jede Menge schon den Term $x^3$ besitzt. Für $\varepsilon=10^{-10\,000\,000}$ und $y=x_3/(1+\varepsilon)^{1/3}$ gilt $F_3(y)\le (y/x_3)^3 F_3(x_3)<1$. Also $y<z\le x_3$, und $x_3-y<\varepsilon/3$ durch die Tangentenabschätzung für $(1+\varepsilon)^{-1/3}$. Die Schranke betrifft die Differenz zweier Größen. Eine Berechnung ihrer einzelnen Dezimalentwicklungen ist dafür entbehrlich.

## Weshalb eine beliebige zulässige Vorgeschichte als Ersatz für Greedy scheitert

Ein endlicher Vergleich zeigt, welche zusätzliche Voraussetzung eine Verallgemeinerung benötigt. Sei $L=2\cdot3\cdot5\cdot7\cdot11\cdot13\cdot17\cdot19$. Den zehn Offsets $d=2,4,\ldots,20$ ordne der Reihe nach die zehn Primzahlen von 23 bis 61 zu. Für jedes zugehörige $p_d$ sollen die Reste einer Menge $F$ genau alle Klassen außer $1$ und $1+d$ belegen. Dies kann man mit 59 Elementen erreichen: Man listet die $p_d-2$ erlaubten Reste aufsteigend auf und wiederholt die Liste zyklisch bis zur Länge 59. Der chinesische Restsatz kombiniert jeweils eine Zeile dieser zehn Listen mit Rest 0 modulo $L$. Wähle die nichtnegativen Vertreter. Die erste Zeile liefert 0, die Spalte modulo 61 sichert 59 verschiedene Elemente.

Wähle $t>\max F$ mit Rest 0 modulo $L$ und Rest 1 modulo allen $p_d$. Vergleiche Fortsetzungen der vorgeschriebenen Vorgeschichte $F$ unterhalb von $t$. $F\cup\{t\}$ ist zulässig. Wer danach greedy fortsetzt, muss alle geraden $t+d$ bis $t+20$ wegen des jeweiligen $p_d$ verwerfen. Hingegen ist $F\cup\{t+2,t+6,t+8,t+12\}$ zulässig. Bei den zehn $p_d$ bleibt Rest 1 frei, bei Primteilern von $L$ genügen die zulässigen Klassen der Menge $\{0,2,6,8,12\}$, und die übrigen Primzahlen sind größer als ihre Kardinalität 63. Für $39/50<x<157/200$ liefert die Alternative nach $t$ normiert mehr als $1{,}021$, die Fortsetzung mit $t$ höchstens $1+x^{22}/(1-x^2)<1{,}013$. Ein Beweis der uneingeschränkten Optimalität bei $x_3$ muss also die tatsächliche Entstehung der kanonischen Greedy-Folge nutzen, wenn er über lokale Austausche argumentiert.

## Beitrag von Regelsuche

Der [Java-Verbraucher](../../integrations/greedy-shift-three/) führt die periodischen Restklassenschranken mit Regelsuche 0.5.3 aus. Das Rad und die Auswahl der Gewichte sind Eingaben. Regelsuche leitet die rationalen Beobachtungszustände und ihre Übergänge her. Die mathematische Folgerung über gleichzeitige Sättigungen und die endliche Prüfung des historischen Greedy-Präfixes kommen hinzu. Für einen Laufzeitvergleich waren diese Versuche nicht ausgelegt.
