# Greedy-Optimalität bis zur Wurzel der positiven Greedy-Masse

## Aussage

Eine Menge von nichtnegativen ganzen Zahlen heißt zulässig, wenn sie modulo jeder Primzahl mindestens eine Restklasse auslässt. Wir betrachten endliche oder unendliche Mengen, die 0 enthalten. Die kanonische Greedy-Menge $G$ (A135311) beginnt bei 0 und nimmt jeden nächsten Offset in aufsteigender Reihenfolge genau dann auf, wenn die Zulässigkeit erhalten bleibt. Schreibe

$$W_x(H)=\sum_{h\in H}x^h,\qquad 0<x<1.$$

Sei $\beta$ die eindeutige Lösung von

$$\sum_{g\in G,\ g>0}\beta^g=1,\qquad\text{also}\qquad W_\beta(G)=2.$$

**Satz.** Für jedes $0<x\le\beta$ und jede normalisierte zulässige Menge $H\ne G$ gilt streng $W_x(H)<W_x(G)$. Die strikte Ungleichung gilt auch an der exakt definierten Wurzel $\beta$. Eine Multiplikation aller Gewichte mit derselben positiven Potenz von $x$ erhält die Ordnung.

Die Greedy-Menge ist unendlich. Ist ein angenommener Präfix endlich und hat er $m$ Elemente, so lässt er sich um ein größeres Vielfaches aller Primzahlen bis $m+1$ erweitern. Für diese Primzahlen belegt der neue Offset bereits die Klasse von 0, für größere Primzahlen reichen $m+1$ Elemente nicht zur Überdeckung aller Klassen. Die Vereinigung aller Präfixe ist zulässig, weil jede Verletzung endlich viele Zeugen hätte. Die positive Greedy-Masse ist auf $(0,1)$ stetig (lokal gleichmäßig konvergente Reihe), wächst streng von 0 und wird für $x\uparrow1$ beliebig groß. Damit ist $\beta$ wohldefiniert.

## Wie groß ist das Produkt der schon festgelegten Primmoduln?

Für einen ganzzahligen Offset $t>0$ sei $L(t)$ die Menge der Primzahlen $p$, für die $G\cap[0,t)$ bereits genau $p-1$ Klassen belegt. Schreibe $b_p$ für die einzig fehlende Klasse und $Q(t)=\prod_{p\in L(t)}p$. Die einmal erreichte Sättigung bleibt dauerhaft erhalten. $L(t)$ ist endlich, da $p-1\le |G\cap[0,t)|$. Es zählen ausschließlich Schritte **vor** $t$.

**Lemma.** Für alle ganzen $t>8$ gilt $Q(t)>t$.

Für $8<t\le18$ sind 2, 3 und 5 gesättigt, also $Q(t)\ge30$. Für $18<t\le36$ kommt 7 hinzu, also $Q(t)\ge210$. Ab $t>36$ ist auch 11 gesättigt. Diese Angaben folgen direkt aus dem Greedy-Präfix $0,2,6,8,12,18,20,26,30,32,36$.

Sei nun $t>36$, $k=|L(t)|\ge5$, $Q=Q(t)$ und $p$ die kleinste Primzahl außerhalb von $L(t)$. Die Zahlen in $[0,t)$, die alle Klassen $b_\ell$ für $\ell\in L(t)$ vermeiden, sind **genau** die Greedy-Elemente dieses Intervalls. Jedes angenommene Element vermeidet die Klassen. Jedes verworfene Element hätte seinerzeit bei mindestens einer Primzahl die letzte freie Klasse gefüllt. Diese Primzahl gehört seither zu $L(t)$.

Fixiere eine Klasse $a\bmod p$. Nach Inklusion–Exklusion beträgt die Anzahl solcher Greedy-Elemente mit Rest $a$ mindestens

$$\frac{t}{p}\frac{\varphi(Q)}{Q}-2^k.$$

Tatsächlich stellen $n\equiv a\pmod p$ und die gewählten verbotenen Kongruenzen einer Teilmenge von $L(t)$ nach dem chinesischen Restsatz genau eine Klasse modulo $pd$ dar, wobei $d$ das Produkt dieser Teilmenge ist. Ihre Anzahl in $[0,t)$ weicht von $t/(pd)$ um weniger als 1 ab. Summiert man die Hauptterme mit ihren Vorzeichen, erhält man die angegebene Eulerproduktform.

Für die $j$-te Primzahl $p_j$ gilt

$$\varphi(Q)\ge\prod_{j=1}^k(p_j-1)>2^k p_{k+1}\ge 2^k p.$$

Die mittlere Ungleichung beginnt bei $k=5$ mit $480>32\cdot13$. Im nächsten Schritt wird die linke Seite mit $p_{k+1}-1>4$ multipliziert, während die rechte Seite wegen des Bertrandschen Postulats $p_{k+2}<2p_{k+1}$ um einen Faktor kleiner als 4 wächst. Bei $Q\le t$ wäre die untere Zählschranke damit für *jede* Klasse $a$ positiv. Das widerspräche der Zulässigkeit von $G\cap[0,t)$. Folglich $Q(t)>t$. [Ramanujans Beweis des Bertrandschen Postulats (1919)](https://ramanujan.sirinudi.org/Volumes/published/ram24.html)

**Folgerung für die Zahl der Sättigungen.** Ist $k(t)=|L(t)|$, dann gilt für $t\to\infty$

$$k(t)\ge \log_2 t-O(\log\log t).$$

Denn für eine fehlende Klasse modulo der kleinsten ungesättigten Primzahl $p$ ist die tatsächliche Anzahl null. Die obige Zählung ergibt $t\le p\,2^k Q/\varphi(Q)$. Für die nach Größe geordneten $\ell_i\in L(t)$ gilt $\ell_i\ge i+1$, also $Q/\varphi(Q)=\prod_i\ell_i/(\ell_i-1)\le k+1$. Ferner ist $p\le p_{k+1}=O(k^2)$. Für diese grobe Primzahlschranke genügen $4^m/(2m+1)\le\binom{2m}{m}\le(2m)^{\pi(2m)}$. Der größte Binomialkoeffizient ist mindestens so groß wie der Mittelwert, und jede Primzahlpotenz im mittleren Koeffizienten trägt zu dessen Primexponenten pro Potenzstufe höchstens 1 bei. Somit $\pi(2m)\gg m/\log m$ und $p_{k+1}=O(k^2)$. Aus $t=O(2^k k^3)$ folgt die behauptete Untergrenze, indem man für $k<\log_2 t$ logarithmiert. Der Fall $k\ge\log_2 t$ erfüllt sie unmittelbar. Es werden also unbegrenzt viele verschiedene Primmoduln gesättigt. Ob jede einzelne Primzahl irgendwann gesättigt wird, ist eine eigene Frage.

## Abstieg auf eine frühere erste Abweichung

Fixiere $0<x\le\beta$. Wir zeigen per starker Induktion nach $t$ eine etwas umfassendere Aussage. Hat $H\subseteq\mathbb N_0$ mit $0\in H$ seine erste Abweichung von $G$ bei $t$, so genügt seine Zulässigkeit **an den Primmoduln** $\{2,3\}\cup L(t)$, um $W_x(H)<W_x(G)$ zu folgern. Zulässigkeit an einem einzelnen Modul bedeutet hier lediglich, dass mindestens eine Klasse fehlt. Jede ursprünglich zugelassene Menge erfüllt diese schwächeren Voraussetzungen.

Die erste Abweichung ist stets $t\in G\setminus H$. Wäre $t$ von Greedy abgelehnt worden, hätte die Ergänzung des gemeinsamen vorangehenden Präfixes um $t$ alle Klassen einer schon vor $t$ gesättigten Primzahl belegt. Dieselben Zeugen lägen in $H$.

**Anfang $t\le8$.** Es kommen nur $2,6,8$ infrage. Setze $q=157/200$. Es gilt $\beta<q$, weil $q^2+q^6+q^8+q^{12}>1$ und alle vier Offsets zu $G$ gehören. Die folgenden Gewichte sind durch $x^t$ geteilt.

- Bei $t=2$ erlaubt $0\in H$ nur gerade Offsets, und modulo 3 muss eine der beiden von null verschiedenen Klassen fehlen. Der spätere Beitrag von $H$ ist höchstens $(x^2+x^4)/(1-x^6)$. Die Greedy-Offsets 2 und 6 liefern $1+x^4$. Die strikte Trennung ist äquivalent zu $x^2+x^6+x^{10}<1$, und bereits bei $q$ ist die linke Seite kleiner als $0{,}940$.
- Bei $t=6$ enthalten beide Mengen 0 und 2. Damit sind nur die Klassen 0 und 2 modulo 6 möglich. Das spätere Zusatzgewicht aus $H\setminus G$ ist höchstens $(x^2+x^6)/(1-x^6)-x^2$, weil $8\in G$. Die verbleibende Reihe hat nichtnegative Koeffizienten und ist bei $q$ kleiner als $0{,}494$.
- Bei $t=8$ sind dieselben Klassen festgelegt, und der gesamte spätere Beitrag ist höchstens $(x^4+x^6)/(1-x^6)$, bei $q$ kleiner als $0{,}802$.

**Induktionsschritt $t>8$.** Alle $p\in L(t)$ zwingen $H$ zur selben Auslassung $b_p$ wie $G$, denn ihr gemeinsamer Präfix vor $t$ belegt schon alle anderen Klassen. Außerdem vermeidet $t\in G$ diese Klasse. Vergleiche die übersetzte normierte Restmenge

$$H'=\{0\}\cup\{h-t:h\in H,\ h>t\}$$

mit $G$. Modulo jedem $p\in L(t)$ fehlt in $H'$ die Klasse $b_p-t$. Angenommen, $H'$ und $G$ stimmten auf $[0,t)$ überein. Dann enthält $H'$ die $p-1$ von $G\cap[0,t)$ belegten Klassen. Es fehlte also ausschließlich $b_p$, zugleich aber auch $b_p-t$. Es folgt $p\mid t$ für alle $p\in L(t)$, folglich $Q(t)\mid t$. Das Lemma und $t>0$ schließen dies aus.

Daher hat $H'$ eine erste Abweichung $u<t$. Die Induktionsannahme ist anwendbar, denn $L(u)\subseteq L(t)$, und auch 2 und 3 liegen für $t>8$ in $L(t)$. Die normierte Restmenge erfüllt damit alle bei $u$ verlangten lokalen Zulässigkeitsbedingungen. Es folgt

$$\sum_{h\in H,\ h>t}x^{h-t}=W_x(H')-1<W_x(G)-1\le1.$$

Die Greedy-Menge liefert bereits am Offset $t$ den normierten Beitrag 1. Der gemeinsame frühere Teil hebt sich auf. Dies beweist die Induktionsaussage und den Satz auch im Randfall $W_x(G)=2$.

## Numerische Einordnung und Reichweite

Die [direkte Rechnung](greedy-counting/src/check_exchange_threshold.py) erzeugt die Greedy-Terme durch 230 aus der Definition. Für die positiven Terme sei $P(x)$ die Summe der entsprechenden Monome. An den folgenden rationalen Grenzen $a$ und $b$ ergibt sich $P(a)+a^{232}/(1-a^2)<1<P(b)$,

$$0{,}77274572771007138835<\beta<0{,}77274572771007138836.$$

Die [Untersuchung zur Verschiebung um drei](greedy-shift-three.md) lokalisiert deren Wurzel bei $x_3>0{,}784587368$. Der obige Satz reicht bis einschließlich $\beta$. Ob im kanonischen Problem eine größere allgemeine Optimalitätsschranke möglich ist und ob $G$ bei $x_3$ maximiert, bleibt offen.

## Was oberhalb von $\beta$ an der Vorgeschichte hängt

**Satz.** Zu jedem $\beta<x<1$ und jeder ganzen Grenze $N\ge0$ gibt es eine vorgeschriebene zulässige Vorgeschichte $F$ und eine Position $t>\max F$. Bis einschließlich $N$ stimmt $F$ mit $G$ überein. Ab $t$ ist die gierige Fortsetzung dieser Vorgeschichte einer zulässigen Alternative bei Gewicht $x$ strikt unterlegen.

**Beweis.** Wegen $\sum_{g>0,\,g\in G}x^g>1$ gibt es eine endliche Menge positiver Greedy-Offsets $B$ mit $b(x)=\sum_{b\in B}x^b>1$. Wähle eine gerade Zahl $H\ge\max B$ so groß, dass $1+x^{H+1}/(1-x)<b(x)$. Setze $P=G\cap[0,N]$ und $m=N+1$. Weise jedem geraden $d$ zwischen 2 und $H$ eine eigene Primzahl $p_d>m+H$ zu. Für sie soll $F$ sämtliche Restklassen außer $m$ und $m+d$ enthalten. Die bereits vorgeschriebenen Elemente von $P$ liegen in den erlaubten Klassen.

Seien $J=\max_d(p_d-2)$ und $K=|P|+J+|B|+1$. Für jede Sonderprimzahl liste man die $p_d-2$ erlaubten Klassen auf und wiederhole die Liste zyklisch bis zur Länge $J$. Der chinesische Restsatz liefert für jede der $J$ Zeilen eine Zahl mit genau diesen Resten und Rest 0 bei jeder übrigen Primzahl bis $K$. Wähle paarweise verschiedene Vertreter oberhalb von $N$ und füge sie zu $P$ hinzu. Das ergibt $F$. Wähle $t>\max F$ mit Rest $m$ bei allen $p_d$ und Rest 0 bei den übrigen Primzahlen bis $K$.

Die Menge $F\cup\{t\}$ lässt jeweils $m+d$ modulo $p_d$ frei. Hingegen würde die zusätzliche Aufnahme von $t+d$ diese letzte Klasse füllen. Alle ungeraden Abstände bis $H$ sind durch die Parität gesperrt. Die Alternative $F\cup(t+B)$ lässt bei den Sonderprimzahlen $m$ frei, weil $0<b\le H<p_d$. Bei den übrigen Primzahlen bis $K$ stammen alle verwendeten Reste aus $P\cup B\subseteq G$, bei den größeren reicht die Kardinalität. Damit sind beide gewählten Fortsetzungen zulässig. Normiert auf das Gewicht an Position $t$ erzielt die gierige Fortsetzung durch das gesamte verbleibende Fenster und darüber hinaus höchstens $1+x^{H+1}/(1-x)$, die Alternative bereits $b(x)$. Das beweist die Behauptung.

Die spätere Vorgeschichte oberhalb von $N$ wurde frei vorgeschrieben. Der Satz erklärt, weshalb sich ein Gegenbeispiel für eine solche Vorgeschichte auch nach einem beliebig langen richtigen Anfangsstück herstellen lässt. Für die **kanonische** Folge bleibt die Optimalität zwischen $\beta$ und der Wurzel $x_3$ weiter zu untersuchen. Ein [nachrechenbares Beispiel](greedy-counting/src/check_shift_three_crt.py) erhält den echten Anfang bis 12 und liefert bei $x_3$ einen normierten Vorteil von mehr als $0{,}056567$ für die Alternative.

## Wann Restklassen tatsächlich feststehen

Perry untersuchte bereits, wie lang ein verschobenes Anfangsstück innerhalb von $G$ erneut auftritt, und bewies, dass bei positiver Verschiebung die exakte Wiederholung endlich ist. Der obige Abstieg benötigt zusätzlich eine Abweichung vor dem ursprünglichen Offset und erfasst Konkurrenten mit lokalen Modulbedingungen. [Perrys Forschungsbericht von 1983](https://oeis.org/A274260/a274260.pdf)

R. Michael Perry hat die Anzahl der Greedy-Terme bis zur Festlegung jeder einzelnen fehlenden Klasse als *exhaustion number* beschrieben. Die folgende Rechnung ermittelt zusätzlich, welche Festlegungen auf denselben Greedy-Offset fallen und welche für die Verschiebung um drei relevant wären. [Perrys Definition, OEIS A274261](https://oeis.org/A274261) · [Fehlende Restklassen, OEIS A274260](https://oeis.org/A274260)

Im zertifizierten Präfix bis $10^8$ liegen 5.522.856 Greedy-Offsets. Eine Sättigung kann daher nur für $p\le5.522.857$ vorliegen. Für jede dieser Primzahlen bestimmt die Rechnung entweder zwei noch fehlende Klassen oder die einzige fehlende Klasse und den ersten Greedy-Offset, an dem bereits alle anderen belegt waren. Ein zweites Verfahren prüft die Zeugnisse an den ursprünglichen Greedy-Termen.

| Ereignis bis einschließlich $10^8$ | Anzahl |
|---|---:|
| Gesättigte Primzahlen, einschließlich 2 | 43.670 |
| Greedy-Positionen mit genau einer Sättigung | 43.280 |
| Greedy-Positionen mit genau zwei Sättigungen | 195 |
| Greedy-Positionen mit drei oder mehr Sättigungen | 0 |

Die erste Doppelsättigung liegt bei $t=21.740$ und betrifft 547 und 607. Noch gezielter lässt sich die notwendige Bedingung für $x_3$ prüfen. Für alle $t>8$ mit $t\equiv0\pmod{30}$ liegen 5.158 Sättigungen vor. **Keine einzige** davon sperrt frisch auch nur einen der drei erforderlichen Offsets $t+2,t+6,t+8$. Diese Aussage betrifft den geprüften Zahlenbereich. Die kleinste bei $10^8$ noch ungesättigte Primzahl ist 371.291, mit den beiden fehlenden Resten 102.699 und 185.645.

Die beiden zuvor auffälligen Stellen $t=3.053.730$ und $t=87.343.620$ hatten je zwei *erstmals protokollierte* Ausschlüsse bei $t+6$ und $t+8$. Bei keinem der beiden $t$ trat überhaupt eine Sättigung ein. Beispielsweise war bei $t=3.053.730$ die Klasse für den protokollierten Ausschluss bei $t+6$ modulo 29.501 bereits seit 3.035.418 festgelegt. Zwischen der Festlegung und ihrer ersten Protokollierung können viele Greedy-Schritte liegen.

Die globalen Aussagen bis $\beta$ folgen aus dem Induktionsbeweis. Die Zahlen bis $10^8$ stammen aus dem [Prüfergebnis](greedy-counting/validation/saturation-chronology-1e8.json). [Berechnung und unabhängige Prüfung der Zeitpunkte](greedy-counting/src/saturation_chronology.cpp) · [Auswertung](greedy-counting/src/check_saturation_chronology.py) · [Frühere Schranke für $x_3$](greedy-shift-three.md)

Eine weitere [Folgerung für die Primfaktoren von $2g+1$](greedy-counting/half-residues.md) reicht über die berechneten Offsets hinaus. Bis einschließlich 72.461.708.495 lässt sich für alle Greedy-Offsets jeder Primfaktor der Form $4k+3$ ausschließen.

### Reproduktion

Im Verzeichnis `docs/research/greedy-counting` laufen die beiden rationalen Prüfungen mit `python3 src/check_exchange_threshold.py` und `python3 src/check_shift_three_crt.py`. Für die Chronologie wird das bereits erzeugte und unabhängig verifizierte Präfix `/tmp/g-shift-three.u32` samt zugehörigem Protokoll verwendet.

```sh
g++ -O3 -std=c++20 -Wall -Wextra -Werror src/saturation_chronology.cpp -o /tmp/greedy-saturation
/tmp/greedy-saturation derive 100000000 /tmp/g-shift-three.u32 /tmp/saturation.csv
/tmp/greedy-saturation verify 100000000 /tmp/g-shift-three.u32 /tmp/saturation.csv
python3 src/check_saturation_chronology.py /tmp/g-shift-three /tmp/saturation.csv --check validation/saturation-chronology-1e8.json
```
