# Die fehlende Halbklasse und die Primfaktoren von 2g+1

Für die Greedy-Folge $G=\{0,2,6,8,12,\ldots\}$ gilt folgende **nachprüfbare endliche Aussage**. Für jedes $g\in G$ mit $g\le 72\,461\,708\,495$ sind alle Primfaktoren von $2g+1$ kongruent $1\pmod 4$. Dabei ist $2\cdot0+1=1$ zugelassen. Die Rechnung verwendet das unabhängig bestätigte Präfix bis $10^8$. Über diese Grenze hinaus folgt die Aussage aus den bereits dauerhaft gesperrten Klassen.

## Die Halbklasse im vollständigen Katalog

Sobald $G$ modulo einer Primzahl $p$ erstmals $p-1$ Klassen besetzt hat, bleibt die einzige fehlende Klasse $r_p$ für alle späteren Greedy-Terme verboten. Sei $T_p$ der Offset der erstmaligen Sättigung. Die **Halbklasse** $r=(p-1)/2$ hat für ungerades $p$ die Eigenschaft $g\equiv r\pmod p\iff p\mid 2g+1$.

| Durch $10^8$ gesättigte ungerade Primzahlen | Anzahl | Davon mit $r_p=(p-1)/2$ |
|---|---:|---:|
| $p\equiv1\pmod4$ | 22 460 | 0 |
| $p\equiv3\pmod4$ | 21 209 | 21 209 |

Für alle 21 209 Primzahlen in der zweiten Zeile gilt zusätzlich $T_p<(p^2-1)/2$. Das größte beobachtete Verhältnis $2T_p/(p^2-1)$ beträgt exakt $169/180$ bei $p=71$ und $T_{71}=2366$. Alle 839 Primzahlen $p\equiv3\pmod4$ bis $\lfloor\sqrt{2\cdot10^8+1}\rfloor=14\,142$ sind darunter. Ein separates Teilersieb fand unter den 5 522 856 berechneten Werten $2g+1$ keinen Primfaktor $3\pmod4$.

## Beweis der Grenze über das berechnete Präfix hinaus

Alle $g\in G$ sind gerade. In $2g+1\equiv1\pmod4$ treten Primfaktoren $3\pmod4$ daher mit gerader Gesamtzahl auf, mit Vielfachheiten gezählt. Wenn es einen solchen Faktor gibt, gibt es mindestens zwei. Jede im Katalog verzeichnete Halbklasse schließt ihren Primfaktor für die gesamte Folge aus. Die kleinste Primzahl $3\pmod4$ ohne dieses Zeugnis ist $p_0=371291$. Für $2g+1<p_0^2$ ist die Behauptung damit bewiesen.

Die nächste Grenze lässt sich mit vier exakten Rechnungen bestimmen. Für ein Gegenbeispiel mit $2g+1\le 371291\cdot390323<2p_0^2$ müsste $2g+1$ genau das Produkt zweier durch Halbklassen bisher ungeschützter Primzahlen sein. Jeder weitere Faktor würde das Produkt mindestens verdoppeln. Beide Primzahlen liegen zwischen 371291 und 390323. Ein vollständiges Primzahlsieb und der Vergleich mit dem Katalog ergeben in diesem Produktbereich genau vier Paare.

| Faktoren von $2g+1$ | Offset $g$ | Primmoduln, deren dauerhaft fehlende Klasse $g$ trifft |
|---|---:|---|
| $371291\cdot371291$ | 68 928 503 340 | 53 549, 429 589 |
| $371291\cdot383659$ | 71 224 566 884 | 5, 229 |
| $371291\cdot389167$ | 72 247 102 298 | 269 |
| $371291\cdot390323$ | 72 461 708 496 | keine im Katalog |

Damit kann kein früherer Greedy-Term die Faktoreigenschaft verletzen. Ob $72\,461\,708\,496$ selbst zu $G$ gehört, ist offen. Später aktivierte Module können den Kandidaten noch ausschließen.

## Welche unendliche Aussage bleibt offen?

Ein hinreichendes Ziel wäre zu beweisen, dass **jede** Primzahl $q\equiv3\pmod4$ vor dem Offset $(q^2-1)/2$ gesättigt wird. Angenommen, es gäbe dann einen ersten $g\in G$, für den $2g+1$ einen Primfaktor $3\pmod4$ hat. Der kleinste solche Primfaktor $q$ wäre höchstens $\sqrt{2g+1}$. Nach Voraussetzung gilt $T_q<(q^2-1)/2\le g$. Bis einschließlich $T_q$ hätte wegen der Minimalität von $g$ noch kein Greedy-Term die Halbklasse modulo $q$ getroffen. Sie wäre also bei $T_q$ die einzig fehlende Klasse gewesen und auch für $g$ verboten. Dieser Widerspruch erklärt, warum die Sättigung vor dem Quadrat eine überprüfbare hinreichende Bedingung ist. Die globale Zeitschranke, die Faktoreigenschaft für beliebiges $g$ und die beobachtete Gegenrichtung für $p\equiv1\pmod4$ sind durch die Daten nicht entschieden.

Perry untersuchte die fehlenden Reste und die Zahl der bis zur Sättigung benötigten Folgenglieder bereits in seinem Bericht von 1983. Seine OEIS-Einträge führen beide Größen. Die überprüfte Modulo-4-Aufteilung wird in den erläuternden Texten dieser Einträge nicht formuliert. Eine historische Priorität wird hier nicht beansprucht. [Perrys Bericht](https://oeis.org/A274260/a274260.pdf) · [A274260](https://oeis.org/A274260) · [A274261](https://oeis.org/A274261)

## Gelockerte hinreichende Fristen

Die [Fortsetzung mit polynomialen Restklassenfamilien](../greedy-saturation-deadlines.md)
ersetzt die Quadratgrenze für 56 von 96 Parameterklassen durch eine spätere
hinreichende Frist. Sie verwendet zusätzlich eine Kofaktorschranke und ändert
die oben nachgewiesene endliche Faktorgrenze nicht. Ob alle Primzahlen ihre
jeweilige Frist einhalten, bleibt offen.

## Reproduktion

Der Prüfer bindet die tatsächlich eingelesenen Bytes der Folge und des vollständigen Sättigungskatalogs an deren SHA-256-Werte. Die Quellen für Erzeugung und unabhängige Zeitprüfung liegen neben dem Prüfer. Die folgende Prüfung benötigt Python und NumPy. [Prüfer](src/check_half_residues.py) · [Katalogprüfung](src/saturation_chronology.cpp) · [Referenzergebnis der Chronologie](validation/saturation-chronology-1e8.json)

```sh
python src/check_half_residues.py /pfad/g-1e8.u32 /pfad/catalogue.csv
```
