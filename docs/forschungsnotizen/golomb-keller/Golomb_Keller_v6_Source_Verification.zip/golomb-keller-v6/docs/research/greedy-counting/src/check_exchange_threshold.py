#!/usr/bin/env python3
"""Check the finite inputs to the exchange-threshold proof using exact arithmetic."""
from fractions import Fraction
from math import isqrt, prod


def primes_through(bound):
    return [
        n for n in range(2, bound + 1)
        if all(n % divisor for divisor in range(2, isqrt(n) + 1))
    ]


def direct_greedy_prefix(bound):
    accepted = []
    primes = primes_through(bound + 1)
    for candidate in range(bound + 1):
        trial = [*accepted, candidate]
        if all(len({g % p for g in trial}) < p for p in primes if p <= len(trial)):
            accepted.append(candidate)
    return accepted


def require(condition, message):
    if not condition:
        raise ValueError(message)


def main():
    limit = 230
    terms = direct_greedy_prefix(limit)
    require([g for g in terms if g <= 36] == [0, 2, 6, 8, 12, 18, 20, 26, 30, 32, 36],
            "unexpected seed")
    for p, first in ((2, 0), (3, 2), (5, 8), (7, 18), (11, 36)):
        seen = {g % p for g in terms if g < first}
        require(len(seen) == p - 2 and first % p not in seen, f"saturation of {p}")
    small = (2, 3, 5, 7, 11)
    require(prod(p - 1 for p in small) > 2 ** len(small) * 13,
            "inclusion-exclusion seed")
    q = Fraction(157, 200)
    require(q**2 + q**6 + q**10 < 1, "first disagreement at 2")
    require((q**2 + q**6)/(1 - q**6) - q**2 < 1, "first disagreement at 6")
    require((q**4 + q**6)/(1 - q**6) < 1, "first disagreement at 8")
    require(sum(q**g for g in (2, 6, 8, 12)) > 1, "beta must be below q")

    lower = Fraction("0.77274572771007138835")
    upper = Fraction("0.77274572771007138836")
    lower_sum = sum(lower**g for g in terms if g > 0)
    upper_sum = sum(upper**g for g in terms if g > 0)
    require(lower_sum + lower**(limit + 2)/(1 - lower**2) < 1 < upper_sum,
            "exact root bracket")
    print("Checked the three induction seeds, five saturations, sieve constant "
          "and the 20-decimal root bracket.")


if __name__ == "__main__":
    main()
