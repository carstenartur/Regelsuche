#!/usr/bin/env python3
"""Summarize the certified complete saturation catalogue at 100 million."""
import argparse
from collections import Counter, defaultdict
import csv
from math import isqrt
from io import StringIO
import json
from pathlib import Path

import numpy as np


from check_shift_three import TERM_HASH, FROZEN_HASH, verified_bytes

CATALOGUE_DIGEST = "0f4e34e44448e32d7980d96e4afebabc4759711081b1ab1aaeddaa0d9b26557e"
OFFSETS = (2, 6, 8)


def decoded_rows(data, names):
    rows = csv.DictReader(StringIO(data.decode("ascii")))
    return [tuple(int(row[name]) for name in names) for row in rows]


def first_unsaturated(terms, records):
    # Every prime through and including the smallest unlisted one is covered
    # by a completed sieve. The catalogue itself was audited independently.
    limit = len(terms) + 1
    prime = np.ones(limit + 1, dtype=bool)
    prime[:2] = False
    for p in range(2, isqrt(limit) + 1):
        if prime[p]:
            prime[p*p::p] = False
    prime[list(records)] = False
    p = int(np.flatnonzero(prime)[0])
    missing = np.flatnonzero(np.bincount(terms % p, minlength=p) == 0).tolist()
    return {"prime": p, "missing_residues": missing}, int(np.count_nonzero(prime))


def report(prefix, catalogue_path):
    terms = np.frombuffer(verified_bytes(Path(str(prefix) + ".u32"), TERM_HASH), dtype="<u4")
    frozen = decoded_rows(
        verified_bytes(Path(str(prefix) + "-frozen.csv"), FROZEN_HASH),
        ["prime", "forbidden_g_residue", "first_rejected_g"],
    )
    catalogue = decoded_rows(
        verified_bytes(catalogue_path, CATALOGUE_DIGEST),
        ["prime", "missing_residue", "saturation_g"],
    )
    records = {p: (residue, t) for p, residue, t in catalogue}
    by_time = defaultdict(list)
    for p, residue, t in catalogue:
        by_time[t].append((p, residue))
    log_by_position = defaultdict(list)
    logged = set()
    for p, residue, position in frozen:
        omitted, t = records[p]
        if residue != omitted or t >= position:
            raise ValueError(f"catalogue/log inconsistency at {p}")
        logged.add(p)
        log_by_position[position].append(p)
    phase_zero = {t: primes for t, primes in by_time.items() if t >= 10 and t % 30 == 0}
    aligned = [
        [d, p, residue, t] for p, residue, t in catalogue for d in OFFSETS
        if (t + d) % p == residue
    ]
    phase_aligned = [row for row in aligned if row[-1] >= 10 and row[-1] % 30 == 0]
    multis = sorted((t, primes) for t, primes in by_time.items() if len(primes) >= 2)
    maximum_lag = max((pos - records[p][1], p, records[p][1], pos) for p, _, pos in frozen)
    # Fresh recorded rejections at two or more of a phase-zero start's three
    # compulsory offsets, with no intervening G-term before its last offset.
    next_terms = np.concatenate((terms[1:], [100_000_001]))
    possible = terms[(terms >= 10) & (terms % 30 == 0) & (next_terms > terms + 8)]
    fresh_starts = [
        int(t) for t in possible
        if sum(int(t) + d in log_by_position for d in OFFSETS) >= 2
    ]
    details = {}
    for t in fresh_starts:
        details[t] = {
            "saturations_at_t": by_time.get(t, []),
            "blockers_at_required_offsets": {
                d: [
                    {"prime": p, "residue": r, "first_logged": u, "saturation": records[p][1]}
                    for p, r, u in frozen if u <= t + d and (t + d) % p == r
                ] for d in OFFSETS
            },
        }
    first_unsat, unsaturated_count = first_unsaturated(terms, records)
    return {
        "cutoff": 100_000_000,
        "terms_sha256": TERM_HASH,
        "frozen_sha256": FROZEN_HASH,
        "catalogue_sha256": CATALOGUE_DIGEST,
        "saturated_primes_including_two": len(catalogue),
        "logged_odd_primes": len(logged),
        "saturated_unlogged_odd_primes": len(records.keys() - logged - {2}),
        "minimum_saturated_unlogged_odd_prime_record": next(
            row for row in catalogue if row[0] != 2 and row[0] not in logged
        ),
        "minimum_unsaturated_prime": first_unsat,
        "unsaturated_relevant_primes": unsaturated_count,
        "verified_historical_classes_for_odd_saturated_primes": sum(p - 1 for p in records if p != 2),
        "number_of_offsets_by_simultaneous_saturations": dict(Counter(map(len, by_time.values()))),
        "first_simultaneous_saturations": multis[0],
        "phase_zero_saturating_offsets": len(phase_zero),
        "phase_zero_saturations": sum(map(len, phase_zero.values())),
        "all_newly_saturated_blockers_of_plus_2_6_8": aligned,
        "phase_zero_aligned": phase_aligned,
        "maximum_lag_as_lag_prime_saturation_first_logged": maximum_lag,
        "two_fresh_logged_offsets": details,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prefix", type=Path)
    parser.add_argument("catalogue", type=Path)
    options = parser.add_mutually_exclusive_group()
    options.add_argument("--output", type=Path, help="write the JSON to this file")
    options.add_argument("--check", type=Path, help="compare against this saved JSON")
    arguments = parser.parse_args()
    rendered = json.dumps(report(arguments.prefix, arguments.catalogue), indent=2) + "\n"
    if arguments.check:
        if arguments.check.read_bytes() != rendered.encode("utf-8"):
            raise ValueError("saved chronology summary differs")
        print("Saturation chronology summary matches the saved JSON.")
    elif arguments.output:
        arguments.output.write_bytes(rendered.encode("utf-8"))
    else:
        print(rendered, end="")
