#!/usr/bin/env python3
"""Certify the finite first-difference obstruction and shift-three root bracket.

Usage: python check_shift_three.py /path/to/g-1e8 [--output FILE | --check FILE]
Reads PREFIX.u32 (little-endian) and PREFIX-frozen.csv. Requires NumPy.
The input digests are from validation/integration-recheck-2026-10-04.json.
"""
import argparse
import csv
import hashlib
import io
import json
from fractions import Fraction
from pathlib import Path

import numpy as np


CUTOFF = 100_000_000
TERM_HASH = "61b9fa4b2f31ab88dc2d9bd60136ad24c561a9d7f9e9bd0c0498642ee0eb3569"
FROZEN_HASH = "6d2742f3b3ae56645422a057524fbb1848a148f623b57b2f5c0de36d4bde533e"
ROOT_LOW = Fraction(784587368, 10**9)
ROOT_HIGH = Fraction(784587369, 10**9)
CEILING = Fraction(157, 200)
OFFSETS = (2, 6, 8)
FOURTH_CHOICES = (12, 18, 20)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verified_bytes(path, expected_hash):
    data = path.read_bytes()
    require(hashlib.sha256(data).hexdigest() == expected_hash, f"digest mismatch: {path}")
    return data


def root_bracket(terms):
    local = terms[:np.searchsorted(terms, 160, side="right")].tolist()
    # A term after offset 160 first contributes the power 164 with shift three.
    upper_at_low = sum(ROOT_LOW ** (g + 3) for g in local) + ROOT_LOW**164 / (1 - ROOT_LOW)
    lower_at_high = sum(ROOT_HIGH ** (g + 3) for g in local)
    require(upper_at_low < 1 < lower_at_high, "shift-three root bracket failed")
    require(ROOT_HIGH < CEILING, "root bracket is outside the uniform interval")
    return [str(ROOT_LOW), str(ROOT_HIGH)]


def uniform_bounds():
    q = CEILING
    # For t=2 compare the worst rival tail to G's points at 2 and 6.
    # For t=6 remove the possible rival weight at +2, covered by G's point 8.
    # For t=8 the possible positive distances are 4,6,10,12,... modulo six.
    # All resulting polynomials/series have nonnegative coefficients.
    early = {
        "2": q**2 + q**6 + q**10,
        "6": (q**2 + q**6) / (1 - q**6) - q**2,
        "8": (q**4 + q**6) / (1 - q**6),
    }
    require(all(value < 1 for value in early.values()), "small first-difference case failed")

    phases = [r for r in range(30) if r % 2 == 0 and r % 3 != 1 and r % 5 != 4]
    bounds = {}
    for phase in phases:
        distances = [(r - phase) % 30 or 30 for r in phases]
        bounds[phase] = sum(q**d for d in distances) / (1 - q**30)
    require([r for r in phases if bounds[r] >= 1] == [0], "critical phase changed")

    # An omitted S gain or a term also in G removes this weight from an upper
    # bound for the normalized positive difference. Each indicated weight is in
    # the phase-zero series, so each residual series remains increasing in x.
    require(set(OFFSETS + FOURTH_CHOICES) <= set(phases), "weight absent from phase zero")
    omitted = {d: bounds[0] - q**d for d in OFFSETS}
    require(all(value < 1 for value in omitted.values()), "compulsory gain failed")
    fourth = bounds[0] - sum(q**d for d in FOURTH_CHOICES)
    require(fourth < 1, "no fourth gain forced")

    # Floats below are diagnostics. Every decision above compares exact rational numbers.
    return {
        "uniform_ceiling": str(q),
        "early_case_bounds_at_ceiling": {key: float(value) for key, value in early.items()},
        "phase_bounds_at_ceiling": {str(key): float(value) for key, value in bounds.items()},
        "bounds_if_one_compulsory_gain_absent": {
            str(key): float(value) for key, value in omitted.items()
        },
        "bound_if_no_gain_at_12_18_20": float(fourth),
    }


def exclusion_masks(frozen_data):
    # If a position occurs later than a prime's first recorded rejection,
    # the difference between these even positions is at least 2p. For p>=5
    # this puts that first rejection strictly before t for every queried t+d.
    # Both smaller primes permit every queried position.
    previous = np.zeros(CUTOFF // 2 + 1, dtype=bool)
    first = np.zeros_like(previous)
    count = 0
    for row in csv.DictReader(io.StringIO(frozen_data.decode("ascii"))):
        p = int(row["prime"])
        start = int(row["first_rejected_g"])
        residue = int(row["forbidden_g_residue"])
        require(start % p == residue and start % 2 == 0 and 0 < start <= CUTOFF,
                f"inconsistent exclusion {row}")
        count += 1
        if p >= 5:
            first[start // 2] = True
            previous[start // 2 + p::p] = True
    return previous, first, count


def first_difference_cases(terms, previous, first):
    # At the last term the next admissible offset exceeds the certified cutoff.
    # Every phase-zero start has all three required offsets inside that cutoff.
    require(CUTOFF % 30 >= max(OFFSETS), "cutoff intersects the last queried window")
    require(int(terms[-1]) + max(OFFSETS) <= CUTOFF, "last term crosses checked endpoint")
    next_terms = np.concatenate((terms[1:], [CUTOFF + 1]))
    phase_zero = (terms >= 10) & (terms % 30 == 0)
    # The only possible G-terms in (t,t+8] for this phase are t+2,+6,+8.
    starts = terms[phase_zero & (next_terms > terms + max(OFFSETS))]
    indices = starts[:, None] // 2 + np.array(OFFSETS)[None, :] // 2
    fresh_count = np.count_nonzero(first[indices], axis=1)
    survivors = starts[~np.any(previous[indices], axis=1)]
    return {
        "phase_zero_starts": int(np.count_nonzero(phase_zero)),
        "phase_zero_starts_gap_gt_8": int(starts.size),
        "distribution_number_fresh_first_rejection_offsets": np.bincount(
            fresh_count, minlength=4
        ).tolist(),
        "previously_blocked_sieve_surviving_starts": survivors.tolist(),
    }


def audit(prefix):
    term_data = verified_bytes(Path(str(prefix) + ".u32"), TERM_HASH)
    frozen_data = verified_bytes(Path(str(prefix) + "-frozen.csv"), FROZEN_HASH)
    terms = np.frombuffer(term_data, dtype="<u4").astype("int64")
    require(terms.size == 5_522_856 and terms[0] == 0 and terms[-1] == 99_999_972,
            "incomplete prefix")
    require(np.all(terms[1:] > terms[:-1]), "term order")
    previous, first, rows = exclusion_masks(frozen_data)
    cases = first_difference_cases(terms, previous, first)
    result = {
        "cutoff": CUTOFF,
        "number_terms": int(terms.size),
        "last_term": int(terms[-1]),
        "terms_sha256": TERM_HASH,
        "frozen_sha256": FROZEN_HASH,
        "frozen_rows": rows,
        "rational_root_bracket": root_bracket(terms),
        **uniform_bounds(),
        **cases,
    }

    if not cases["previously_blocked_sieve_surviving_starts"]:
        # A competitor that improves the mass agrees through CUTOFF. Its even
        # shift-three tail is <= x^(N+5)/(1-x^2), uniformly for x<=CEILING.
        q = CEILING
        require(q**5 < 1 - q**2, "tail prefactor bound")
        require(q**10 < Fraction(1, 10) and CUTOFF % 10 == 0, "decimal tail bound")
        epsilon = f"10^(-{CUTOFF // 10})"
        result["global_mass_excess_strict_upper_bound"] = epsilon
        # F(y) <= (y/x)^3 F(x) when y<=x. At x=x_3 and F(x)<1+epsilon,
        # this brackets the optimal root above x/(1+epsilon)^(1/3).
        result["optimal_root_distance_strict_upper_bound"] = f"{epsilon}/3"
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("prefix", type=Path)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--output", type=Path, help="write the recomputed JSON result")
    mode.add_argument("--check", type=Path, help="compare existing JSON to canonical output")
    args = parser.parse_args()
    rendered = json.dumps(audit(args.prefix), indent=2) + "\n"
    if args.check:
        require(args.check.read_bytes() == rendered.encode("utf-8"), "reference JSON differs")
        print("Shift-three prefix audit matches the reference JSON.")
    elif args.output:
        args.output.write_bytes(rendered.encode("utf-8"))
    else:
        print(rendered, end="")


if __name__ == "__main__":
    main()
