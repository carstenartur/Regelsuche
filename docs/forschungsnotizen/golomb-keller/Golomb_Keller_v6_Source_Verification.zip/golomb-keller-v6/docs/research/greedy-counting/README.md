# Greedy-Zählfunktion: reproduzierbarer Forschungsstand

Stand: 2. Oktober 2026. Die Folge ist OEIS A135311, beginnend mit 0.
Das vollständige Präfix bis 100 000 000 enthält 5 522 856 Elemente.
Die Definition, Literatur, Beweise und Aussagegrenzen stehen in
[`report/report.md`](report/report.md).

## Dateien

- `src/generator.cpp`: exakter ereignisgesteuerter Generator ohne heuristische Primzahlgrenze.
- `src/verify_prefix.cpp`: unabhängige Prüfung durch arithmetische Progressionen; keine Generator-Warteschlange.
- `src/test_generator.py`: Definitionsvergleich bis 2000 und optional alle 10 000 OEIS-Werte.
- `src/test_verifier.py`: zwölf handgeprüfte Erfolgs-, Rand- und Manipulationsfälle.
- `src/analyze.py`: Zählwerte, Vergleich mit eigenem Primzahlsieb, Fits, Diagramme und rationale Kehrwertintervalle.
- `data/results.json`: vollständige numerische Zusammenfassung, Modellparameter und rationale Intervalle.
- `data/checkpoints.csv`, `dyadic.csv`, `index-comparison.csv`, `log-grid.csv`: lesbare Messwerte.
- `data/g-1e8.u32`: vollständige eigene Folge, 32-Bit-Ganzzahlen in Little-Endian, einschließlich 0.
- `data/g-1e8-frozen.csv`: dauerhafte Ausschlussklassen und überprüfbare erste Ausschlusszeitpunkte.
- `validation/certificate-1e8.json`: Ergebnis der unabhängigen großen Prüfung.
- `validation/missing-residues-1e8.csv`: eine geprüfte fehlende Restklasse für jede Primzahl bis N+1.
- `SHA256SUMS.txt`: Prüfsummen der ausgelieferten Dateien.

Die großen Rohdaten und die erzeugte PDF sind im Auslieferungs-ZIP enthalten.
Im Git-Repository werden Programme, Berichtsquelle, kleine Ergebnistabellen
und Prüfzusammenfassungen versioniert. Die großen Dateien können dort mit
den folgenden Befehlen neu erzeugt werden.

## Berechnung und Prüfung

Voraussetzungen: C++20-Compiler (hier GNU g++), Python 3, für die Auswertung
NumPy, SciPy und Matplotlib sowie OpenSSL-Entwicklungsdateien (`libssl-dev`)
für den Verifier. Der Generator und der Verifier benötigen diese
Python-Pakete nicht. Das Veröffentlichungspräfix ist `g-1e8`.

Aus diesem Verzeichnis:

```sh
mkdir -p data validation figures
g++ -O3 -std=c++20 -Wall -Wextra src/generator.cpp -o generator
g++ -O3 -std=c++20 -Wall -Wextra src/verify_prefix.cpp -lcrypto -o verify_prefix
python3 src/test_generator.py
python3 src/test_verifier.py
./generator 100000000 data/g-1e8
./verify_prefix 100000000 data/g-1e8.u32 data/g-1e8-frozen.csv validation/certificate-1e8.json validation/missing-residues-1e8.csv
python3 src/analyze.py --certificate validation/certificate-1e8.json
```

Der optionale OEIS-Gegenvergleich erwartet `external/b135311.txt` mit den
unveränderten Zahlenpaaren der [b-Datei](https://oeis.org/A135311/b135311.txt).
Fehlt sie, meldet der Test ausdrücklich einen übersprungenen Vergleich.
Die originale Tabelle wird nicht mitverteilt. Der durchgeführte Lauf hatte
diese Quelle vollständig vorliegen: beide Generatortests und alle zwölf
Verifierfälle bestanden. Die Zählwerte in Perrys Tabelle wurden zusätzlich
gegengeprüft; siehe `validation/perry-counts.json`.

Der Generator meldet seine abgeschlossene Laufmetadatei erst nach dem
Schließen der Ausgaben. Ein abgebrochener Lauf ist kein vollständiges Präfix.
Die unabhängige Prüfung verlangt das explizite Ende und kontrolliert auch
alle Kandidaten nach dem letzten ausgegebenen Folgenglied bis zu diesem Ende.

## PDF erneut erstellen

Mit Pandoc und einer LaTeX-Installation:

```sh
python3 src/build_report.py
```

Der Build verwendet die von `analyze.py` erzeugten Vektordiagramme in PDF-Form.
Die Markdown-Fassung verlinkt dieselben Diagramme als SVG für die Ansicht im Repository.

## Aussagegrenzen und Provenienz

Die [dynamische Fortsetzung](../greedy-derived-nonactivation.md) leitet auch
größere Sperrregeln aus zuvor bestätigten Klassen selbst her. Drei bewiesene
Regeln ermöglichen drei Nichtaktivierungsnachweise und insgesamt 19 zusätzliche
Aufnahmen in zwei kompakten Ketten: 3396 und 3620 bei p=107 sowie die verbesserte
Schranke `T_719 <= 49550`. Das Manifest
`derived-nonactivation-certificates.json` und der unabhängige Prüfer
`src/check_derived_nonactivation.py` verwenden dieselbe 300000-Datenbasis.
Der universelle Fristsatz bleibt offen; auch der neue monotone Defizitsatz
garantiert noch nicht genügend zusätzliche Ausschlüsse für alle Primzahlen.

Die [kanonischen Fristurkunden](../greedy-canonical-bootstrap.md) verwenden
dieselbe unabhängig geprüfte Datenbasis für sechs endliche Beweise aus
kleineren Regeln. Ihre Schlussrechnung leitet frühere Greedy-Zeugen selbst
her; die tatsächlichen größeren Aktivierungsdaten werden ihr nicht übergeben.
Manifest, Prüfer und Reproduktionsbefehle sind in der Forschungsnotiz verlinkt.
Die dort ebenfalls dokumentierte historische Gegenprobe zur Primzahlordnung
nutzt den vorhandenen Katalog bis $10^8$; sie verlängert kein Präfix.

Ganzzahlige Zählungen, Ausschlussprüfungen und rationale Summenintervalle
sind exakt. Diagrammkoordinaten, Logarithmen, Fits und Extrapolationsszenarien
verwenden Gleitkommaarithmetik. Sie liefern keine Konfidenzaussage und keinen
Beweis einer Asymptotik. Laufzeiten sind Einzelmessungen dieser Umgebung.

Das Präfix wurde aus der Definition berechnet. Externe Vergleichsdaten
stammen aus OEIS A135311 (Pontus von Brömssen; erste 2089 Werte Alessandro
Languasco) und aus Perrys technischem Bericht CU-CS-253-83. Vollständige
fremde Artikel werden nicht weitergegeben. Alle Primärquellen stehen im Bericht.
Die Entwicklung und mathematische Analyse erfolgten KI-gestützt; eine
formale Verifikation oder unabhängige menschliche Begutachtung wird nicht behauptet.

Die binäre Präfixdatei ist deterministisch. Laufzeiten, Umgebungsangaben und
Metadaten in neu erstellten Diagrammen/PDFs können beim Wiederholen variieren;
die Prüfsummen beschreiben die konkret ausgelieferte Fassung.


## Integration hardening (4 October 2026)

The focused `Greedy counting checks` CI now compiles both actual C++ programs,
runs the definition, 12 verifier and output/interval controls, and independently
checks the complete prefix through one million. The OEIS-reference test is
explicitly optional unless its external reference file is present; it is not
silently counted as passed.

The verifier uses OpenSSL (`libssl-dev` on Debian/Ubuntu; link with `-lcrypto`)
for standard SHA-256. It hashes the exact bytes consumed from the term stream
and frozen-witness CSV and records both digests in its successful JSON. The
analysis rejects byte-mismatched files before processing them, including a
modified file with unchanged cutoff/count/last. Older unbound verifier JSON is
not accepted by the updated analysis; rerun the verifier and pass its receipt
with `--certificate`. Generator metadata open/flush failures now prevent a
successful completion message.

```sh
python3 src/test_evidence.py -v
python3 src/analyze.py --prefix g-1e8 --certificate validation/certificate-1e8.json
```

The reciprocal-interval and first-crossing code is independently callable
without NumPy, SciPy or plotting dependencies. Its small tests compare against
exact Fraction sums and include certified below/above cases and a deliberately
unresolved crossing. These checks are also part of CI; insufficient precision
cannot be reported as a certified crossing.

`validation/integration-recheck-2026-10-04.json` records a new complete local
replay of the 100-million prefix, its consumed-input hashes and an exact replay
of all historical reciprocal intervals/crossings. The old numerical observation
files remain unchanged. Their sequence SHA-256 is explicitly matched by the
new verifier receipt. This is finite software verification, not independent
human review of the asymptotic arguments or a portable timing comparison.

## Hall-Urkunden für mögliche größere Sperren

Für die zwei festen Klassen im [Hall-Manifest](hall-certificates.json) erzeugt
`src/check_hall_certificates.py build` aus der geprüften kleineren Chronologie vier Graphen.
Der Java-Consumer prüft das maximale Matching und eine Hall-Zeugenmenge für jeden Graphen.
`src/check_hall_certificates.py check` authentisiert die Quellen erneut und rekonstruiert die
Kanten durch direkte Belegungstests. Der Endbericht weist die garantierte Zahl echter
Greedy-Terme in jeder Zeugenmenge und einen gesonderten Vergleich mit dem Präfix aus.
[Reproduktion](../../../integrations/regelsuche-modular-coverage/README.md#hall-urkunden)
und [Beweis der lokalen Untergrenze](../greedy-hall-certificates.md).
