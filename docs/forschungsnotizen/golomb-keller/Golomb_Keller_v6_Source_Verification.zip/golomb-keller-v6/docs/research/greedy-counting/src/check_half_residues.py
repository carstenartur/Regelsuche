#!/usr/bin/env python3
"""Replay the mod-four half-residue claims using the certified A135311 catalogue.

Usage: python check_half_residues.py PREFIX.u32 CATALOGUE.csv
Reads the exact term and catalogue bytes bound in the chronology experiment.
"""
import argparse
import csv
from fractions import Fraction
from io import StringIO
from itertools import combinations_with_replacement
import json
from math import isqrt
from pathlib import Path

import numpy as np

from check_saturation_chronology import CATALOGUE_DIGEST
from check_shift_three import TERM_HASH, require, verified_bytes


CUTOFF = 100_000_000
LAST_PAIR = (371291, 390323)
LAST_PRODUCT = LAST_PAIR[0] * LAST_PAIR[1]


def primes_through(limit):
    prime = np.ones(limit + 1, dtype=bool)
    prime[:2] = False
    for p in range(2, isqrt(limit) + 1):
        if prime[p]:
            prime[p*p::p] = False
    return np.flatnonzero(prime).tolist()


def replay(term_path, catalogue_path):
    terms = np.frombuffer(verified_bytes(term_path, TERM_HASH), dtype="<u4")
    data = verified_bytes(catalogue_path, CATALOGUE_DIGEST)
    catalogue = {
        int(row["prime"]): (int(row["missing_residue"]), int(row["saturation_g"]))
        for row in csv.DictReader(StringIO(data.decode("ascii")))
    }
    split = {1: 0, 3: 0}
    protected = {}
    for p, (residue, epoch) in catalogue.items():
        if p == 2:
            continue
        is_half = 2*residue + 1 == p
        require(is_half == (p % 4 == 3), f"half-class exception at {p}")
        split[p % 4] += 1
        if is_half:
            require(2*epoch < p*p-1, f"late saturation at {p}")
            protected[p] = epoch
    require(split == {1: 22460, 3: 21209}, "incorrect class counts")
    ratio, tight_prime = max((Fraction(2*epoch, p*p-1), p) for p, epoch in protected.items())
    require((ratio, tight_prime, protected[tight_prime]) == (Fraction(169, 180), 71, 2366),
            "incorrect tight timing case")

    # For a number 1 mod 4, an even number of factors 3 mod 4 occur with
    # multiplicity. If any occurs, one of them is at most the square root.
    all_primes = primes_through(LAST_PAIR[1])
    small = [p for p in all_primes if p <= isqrt(2*CUTOFF+1) and p % 4 == 3]
    require(len(small) == 839 and small[-1] == 14107 and all(p in protected for p in small),
            "small primes not all protected")
    forbidden = np.zeros(CUTOFF//2 + 1, dtype=bool)
    for p in small:
        g = (p-1)//2
        if g % 2:
            g += p
        # g/2 is the array index because every accepted g is even.
        forbidden[g//2::p] = True
    require(not np.any(forbidden[terms//2]), "direct divisor sieve found an exception")

    # A possible bad product n <= LAST_PRODUCT is the product of two
    # unprotected primes, with no cofactor since LAST_PRODUCT < 2*p0^2.
    unprotected = [p for p in all_primes if p % 4 == 3 and p not in protected]
    p0 = unprotected[0]
    require(p0 == LAST_PAIR[0] and LAST_PRODUCT < 2*p0*p0, "pair reduction failed")
    require(LAST_PRODUCT//p0 == all_primes[-1], "prime search range is incomplete")
    candidates = []
    for p, q in combinations_with_replacement(unprotected, 2):
        if p*q <= LAST_PRODUCT:
            g = (p*q-1)//2
            blockers = [m for m, (r, _) in catalogue.items() if g % m == r]
            candidates.append({"p": p, "q": q, "g": g, "blockers": blockers})
    candidates.sort(key=lambda row: row["g"])
    require(len(candidates) == 4, "unexpected pair count")
    require(all(row["blockers"] for row in candidates[:-1]), "earlier surviving offset")
    last = candidates[-1]
    require((last["p"], last["q"]) == LAST_PAIR and not last["blockers"],
            "claimed first survivor differs")
    return {
        "cutoff": CUTOFF,
        "accepted_offsets": int(terms.size),
        "saturated_odd_primes_by_class_mod_4": split,
        "largest_ratio": {"ratio": str(ratio), "prime": tight_prime, "epoch": protected[tight_prime]},
        "small_3_mod_4_primes": len(small),
        "direct_factor_sieve_exceptions": 0,
        "finite_catalogue_pair_obstructions": candidates,
        "last_guaranteed_offset": last["g"] - 1,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("terms", type=Path)
    parser.add_argument("catalogue", type=Path)
    args = parser.parse_args()
    print(json.dumps(replay(args.terms, args.catalogue), indent=2))
