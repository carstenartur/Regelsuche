#!/usr/bin/env python3
"""Exact finite certificates for the accompanying Golomb--Keller preprint.

Python standard library only. Decimal arithmetic PROPOSES endpoints; Fraction
arithmetic VERIFIES every numerical enclosure used in the manuscript. This is
not a formal verification of the infinite/asymptotic mathematical argument.
AI-assisted implementation; see README.md and the manuscript disclosure.
"""
from __future__ import annotations

import argparse
import json
import platform
from decimal import Decimal, ROUND_FLOOR, localcontext
from fractions import Fraction
from pathlib import Path
from typing import Sequence


def primes_upto(n: int) -> list[int]:
    """Return every prime <= n by an elementary sieve."""
    if n < 2:
        return []
    sieve = bytearray(b'\x01') * (n + 1)
    sieve[0:2] = b'\x00\x00'
    for p in range(2, n + 1):
        if sieve[p] and p * p <= n:
            sieve[p*p:n+1:p] = b'\x00' * ((n - p*p)//p + 1)
    return [p for p in range(2, n + 1) if sieve[p]]


def admissible(h: Sequence[int]) -> bool:
    """A finite set need only be tested at primes <= its cardinality."""
    values = set(h)
    return all(len({v % p for v in values}) < p
               for p in primes_upto(len(values)))


def greedy_prefix(cutoff: int) -> list[int]:
    """Generate G intersect [0,cutoff] from the definition, not an OEIS table."""
    if not isinstance(cutoff, int) or cutoff < 0:
        raise ValueError('cutoff must be a nonnegative integer')
    g = [0]
    for candidate in range(2, cutoff + 1, 2):
        if admissible(g + [candidate]):
            g.append(candidate)
    return g


def mass(g: Sequence[int], x: Fraction, shift: int = 1) -> Fraction:
    """Evaluate sum(x**(g+shift)) using homogeneous integer Horner evaluation."""
    if shift < 1 or any(h < 0 for h in g):
        raise ValueError('shift must be positive and offsets nonnegative')
    if not g:
        return Fraction(0)
    exponents = {h + shift for h in g}
    degree = max(exponents)
    a, b = x.numerator, x.denominator
    value, denominator_power = 0, 1
    for d in range(degree, -1, -1):
        value *= a
        if d in exponents:
            value += denominator_power
        if d:
            denominator_power *= b
    return Fraction(value, denominator_power)


def even_tail(x: Fraction, cutoff: int, shift: int = 1) -> Fraction:
    """Bound every omitted even offset; assumes the prefix is complete."""
    if not 0 < x < 1 or cutoff < 0 or shift < 1:
        raise ValueError('require 0<x<1, cutoff>=0, shift>=1')
    next_even = 2 * (cutoff // 2 + 1)
    return x ** (next_even + shift) / (1 - x*x)


def negative_log_bounds(x: Fraction, terms: int = 100) -> tuple[Fraction, Fraction]:
    """Rational enclosure of -log(x), from the positive atanh series."""
    if not 0 < x <= 1 or terms < 1:
        raise ValueError('require 0<x<=1 and terms>=1')
    z = (1 - x) / (1 + x)
    z2 = z*z
    power = z
    lower = Fraction(0)
    for j in range(terms):
        lower += 2 * power / (2*j + 1)
        power *= z2
    remainder = 2 * power / ((2*terms + 1) * (1 - z2))
    return lower, lower + remainder


def decimal_outward(x: Fraction, places: int, up: bool) -> str:
    """Format a nonnegative rational with proved outward decimal rounding."""
    if x < 0 or places < 0:
        raise ValueError('require nonnegative x and places')
    scale = 10**places
    q, r = divmod(x.numerator * scale, x.denominator)
    if up and r:
        q += 1
    if not places:
        return str(q)
    integer, fractional = divmod(q, scale)
    return f'{integer}.{fractional:0{places}d}'


def verify_bracket(g: Sequence[int], cutoff: int, lo: Fraction,
                   hi: Fraction, shift: int = 1) -> bool:
    """Verify a bracket, given G intersect [0,cutoff]. Strict checks are exact."""
    if not 0 < lo < hi < 1:
        return False
    if list(g) != greedy_prefix(cutoff):
        return False
    return (mass(g, lo, shift) + even_tail(lo, cutoff, shift) < 1
            and mass(g, hi, shift) > 1)


def propose_bracket(g: Sequence[int], shift: int,
                    places: int = 60) -> tuple[Fraction, Fraction]:
    """Use approximate arithmetic only to propose, never to certify, endpoints."""
    with localcontext() as ctx:
        ctx.prec = places + 25
        left, right = Decimal(0), Decimal(1)
        for _ in range(4 * (places + 10)):
            midpoint = (left + right) / 2
            total = sum(midpoint ** (h + shift) for h in g)
            if total < 1:
                left = midpoint
            else:
                right = midpoint
        scale = 10**places
        a = int((left * scale).to_integral_value(rounding=ROUND_FLOOR))
    return Fraction(a, scale), Fraction(a + 1, scale)


def constant_certificate(g: Sequence[int], cutoff: int, shift: int) -> dict:
    lo, hi = propose_bracket(g, shift)
    if not verify_bracket(g, cutoff, lo, hi, shift):
        raise ArithmeticError('Proposed numerical interval failed exact verification')
    c_lo, _ = negative_log_bounds(hi)
    _, c_hi = negative_log_bounds(lo)
    return {
        'shift': shift,
        'x_lower': decimal_outward(lo, 60, False),
        'x_upper': decimal_outward(hi, 60, True),
        'c_lower': decimal_outward(c_lo, 50, False),
        'c_upper': decimal_outward(c_hi, 50, True),
        'inverse_c_lower': decimal_outward(1/c_hi, 45, False),
        'inverse_c_upper': decimal_outward(1/c_lo, 45, True),
        'lower_endpoint_mass_plus_tail_below_one': True,
        'upper_endpoint_prefix_mass_above_one': True,
        'logarithm_series_terms': 100,
        'certification_arithmetic': 'exact Python integers and fractions.Fraction',
        'decimal_arithmetic_role': 'propose endpoints only'
    }


def create_report(cutoff: int = 512) -> dict:
    g = greedy_prefix(cutoff)
    witness = mass([0, 2, 6, 8, 12], Fraction(2, 3))
    if witness != Fraction(1678250, 1594323):
        raise ArithmeticError('Exact witness mismatch')
    g26 = greedy_prefix(26)
    coarse_mass = mass(g26, Fraction(13, 20)) + even_tail(Fraction(13, 20), 26)
    if not coarse_mass < 1:
        raise ArithmeticError('Coarse root lower bound failed')
    _, coarse_log_upper = negative_log_bounds(Fraction(13, 20), 20)
    if not coarse_log_upper < Fraction(431, 1000):
        raise ArithmeticError('Coarse log upper bound failed')
    return {
        'purpose': 'Numerical supplement; not a formal or independent human proof review',
        'python_version': platform.python_version(),
        'cutoff': cutoff,
        'number_of_greedy_offsets': len(g),
        'greedy_offsets': g,
        'exact_two_thirds_witness': '1678250/1594323 > 1',
        'coarse_certified_bound': '13/20 < x_G; c_* < log(20/13) < 0.431 < 0.4332',
        'golomb_keller_constant': constant_certificate(g, cutoff, 1),
        'thompson_comparison_only': constant_certificate(g, cutoff, 2),
        'thompson_scope': 'Shift-2 root only. No greedy optimality claim at that root.'
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, help='JSON destination; default stdout')
    args = parser.parse_args()
    data = json.dumps(create_report(), indent=2) + '\n'
    if args.output:
        args.output.write_text(data, encoding='utf-8')
        print(f'Exact numerical certificates written to {args.output}')
    else:
        print(data, end='')


if __name__ == '__main__':
    main()
