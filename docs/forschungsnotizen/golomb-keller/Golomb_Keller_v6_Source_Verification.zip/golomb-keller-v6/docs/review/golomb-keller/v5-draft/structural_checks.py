#!/usr/bin/env python3
"""Exact finite certificates for recurrence/finite-rigidity additions.

Reuses v5's arithmetic helpers; proves no infinite-prime theorem or solver claim.
All decision arithmetic is integer/Fraction; no external package is required.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
from fractions import Fraction as F
from math import isqrt
import json
from pathlib import Path
from typing import Any
import checks


def ceil_fraction(x: F) -> int:
    return -(-x.numerator // x.denominator)


def pair_root(gap: int, bits: int = 80) -> tuple[F, F]:
    """Directed dyadic enclosure for x+x**(gap+1)=1, for a bounded even gap."""
    checks.integer(gap, 2, 2048, 'gap')
    checks.integer(bits, 1, 128, 'bits')
    if gap % 2:
        raise ValueError('expected an even prime-gap bound')
    a, b = F(0), F(1)
    for _ in range(bits):
        x = (a+b)/2
        if x+x**(gap+1) < 1:
            a=x
        else:
            b=x
    return a,b


@dataclass(frozen=True)
class RigidityThreshold:
    last_offset: int
    d: F
    eta: F
    L: int
    K: int
    Q: int
    J: int
    P: int


def finite_rigidity(last_offset: int) -> RigidityThreshold:
    """Compute sufficient thresholds, not the smallest possible true start."""
    checks.integer(last_offset, 2, 1024, 'last offset')
    if checks.greedy(last_offset)[-1] != last_offset:
        raise ValueError('the last offset must be an actual greedy term')
    d=F(1,5)*F(13,20)**(last_offset+1)
    eta=checks.exponent_gap(last_offset)
    L=last_offset
    while 6*F(5,6)**(L+1) > d/8:
        L+=1
    K=0
    while F(80,2**K) > d:
        K+=1
    Q=max(5,L+2,ceil_fraction(4*L*L/d),ceil_fraction(F(5*K,2)))
    required=1/(25*eta)
    J=isqrt(required.numerator//required.denominator)
    if J*J < required:
        J+=1
    # Bound allocation for the known-p threshold: its binary size is 2*J bits.
    # Examples use exact integers; longer prefixes may exhaust this explicit budget.
    if J > 1_000_000:
        raise ValueError('known-prime threshold exceeds the finite certificate budget')
    P=max(396738,Q,4**J)
    return RigidityThreshold(last_offset,d,eta,L,K,Q,J,P)


def verify_threshold(value: Any) -> bool:
    if type(value) is not RigidityThreshold:
        return False
    try:
        return value == finite_rigidity(value.last_offset)
    except (ValueError, TypeError, OverflowError):
        return False


def build_report() -> dict[str, Any]:
    a,b=pair_root(246)
    lo=checks.negative_log(b,40)[0]
    hi=checks.negative_log(a,40)[1]
    rows=[]
    for g in (2,6,8,12,26):
        r=finite_rigidity(g)
        u=F(r.L*r.L,4*r.Q)
        total=(1-r.d/2)/(1-u)+6*F(5,6)**(r.L+1)+F(10,2**r.K)
        if total > 1-r.d/8:
            raise ArithmeticError('finite-rigidity error budget failed')
        rows.append(dict(last_offset=g, d=checks.rational(r.d),eta=checks.rational(r.eta),
                         L=r.L,K=r.K,Q=r.Q,J=r.J,P=str(r.P),
                         total_rational_upper=checks.rational(total),
                         certified_margin=checks.rational(r.d/8)))
    return {
        'schema':'gk-structural-finite-certificates/v1',
        'baseline_commit':'ddde74d35e52a96faef324cc6284ed85eee34671',
        'infinite_prime_theorems_formally_verified':False,
        'pair246':dict(gap=246,bits=80,x_lower=checks.rational(a),x_upper=checks.rational(b),
                       exponent_interval=checks.decimal_enclosure(lo,hi),
                       lower_sign_negative=a+a**247<1,upper_sign_nonnegative=b+b**247>=1,
                       external_theorem='Polymath8b, arXiv:1407.4897, H_1 <= 246'),
        'finite_rigidity':rows,
        'scope':'Finite arithmetic and selected boundary tests. Written proofs handle all quantifiers, tail limits, prime recurrence, and the use of Dusart. No end-to-end formalization claimed.'
    }


def verify_report(value: Any) -> bool:
    try:
        if type(value) is not dict:
            return False
        return json.dumps(value,sort_keys=True,allow_nan=False)==json.dumps(build_report(),sort_keys=True,allow_nan=False)
    except (TypeError,ValueError,OverflowError):
        return False


def write_report(path: Path) -> None:
    data=json.dumps(build_report(),indent=2,sort_keys=True,allow_nan=False)+'\n'
    with path.open('x',encoding='utf-8') as out:
        out.write(data)


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    choice=parser.add_mutually_exclusive_group()
    choice.add_argument('--write',type=Path)
    choice.add_argument('--check',type=Path)
    args=parser.parse_args()
    if args.write:
        write_report(args.write)
        print('Exact finite structural certificates written.')
    elif args.check:
        if args.check.stat().st_size>1024*1024 or not verify_report(json.loads(args.check.read_text())):
            raise SystemExit('Structural certificate mismatch')
        print('Exact finite structural certificates match.')
    else:
        print(json.dumps(build_report(),indent=2,sort_keys=True))


if __name__=='__main__': main()
