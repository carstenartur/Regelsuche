# Structural review extension of revision 5 — 4 October 2026

This is a further working state of the unsent v5 draft, based on the integrated
v5 source at `ddde74d35e52a96faef324cc6284ed85eee34671`. The sent v4 is
unchanged. No official-sharing pointer, repository visibility or publication
status is changed. Identify this state by the exported source SHA-256, not by
"v5" alone. The prior v5 remains in repository history and the prior export.

## What changed

The existing upper-bound proof, quantitative stability, greedy-prefix
equivalence, twin-prime dichotomy, effective exponent and compactness appendix
are retained. Added arguments:

- `gk5s:cor:coefficient`: coefficients above C_GK eventually work, coefficients
  strictly below C_GK fail infinitely often, including rounded coefficients.
  Equality at the boundary is deliberately not decided.
- `gk5s:thm:recurring`: C_GK is the supremum of c_H over finite patterns with
  infinitely many simultaneous prime translates. The statement imposes no
  requirement that the indicated primes be consecutive.
- `gk5s:cor:gap246`: the known bounded-gap theorem gives the unconditional
  lower bound c_246, with a new exact interval certificate.
- `gk5s:prop:finite`: an explicit missing-prefix bound at q=p_(n+1), including
  a uniform local error and both nonlocal tails.
- `gk5s:cor:known-prime`: a much more conservative conversion to a start based
  only on p_n, using the explicitly cited Dusart result.

## Targeted analytic review

1. In the supremum theorem, fix L before discarding the finitely occurring
   exact windows. Verify the implication from exact-window recurrence to
   recurrence as a contained tuple. The start may depend on L.
2. Confirm the uniform margin exp(-(c-b)) below one for S<b<c. Without this
   margin, the local-to-global transfer would not follow merely from a
   pointwise strict inequality.
3. Check the finite local logarithm inequality and that no composite coprime
   term can occur below q+L when q>=L+2. The tails cover all integer offsets,
   not only primes.
4. Check the integer endpoint: tau<c_m*q gives s_n<=ceil(c_m*q); the forcing
   hypothesis is strictly s_n>ceil(c_m*q), not a non-strict variant.
5. For the p_n conversion verify Dusart's applicability, J_m^2>=1/(25*eta_m),
   log(4)>1, and the strict c_m<1/2 comparison. Do not confuse this large bound
   with a practical estimate or the earlier 0.431 exponent guarantee.

## Primary-source comparison

Cloitre, arXiv:2508.02690v2, Remark 16 already describes the association with
recurring constellations. The general connection is prior work. The additional
claim is the precise supremum equality with a uniform proof, not the idea of
using constellations. Conjecture 19 states the fixed-coefficient upper direction;
our short corollary derives it directly from the exact real threshold.

Polymath8b, arXiv:1407.4897, supplies H_1<=246. The lower-bound corollary is
an elementary consequence of this deep external theorem, not a new sieve result
or a claim that 246 is a current optimal bound. These primary sources were
consulted on 4 October 2026. Targeted searches did not establish an exhaustive
priority result for the precise new characterization or finite thresholds.

## Finite verification versus proof

`structural_checks.py` reuses the earlier exact Fraction/logarithm helpers.
`structural-certificates.json` binds the new finite intervals and the displayed
threshold table. Twelve tests cover root signs, monotonicity examples, exact
ceilings, domain checks, three error budgets, premise-to-p_n conversion,
manipulated fields, finite contraction examples and immutable output.
`test_structural_assembly.py` separately tests insertion and preservation.
The resource budget for enormous 4^J values is explicit; it is a computational
limit, not a restriction on the written theorem.

These tests do not prove statements about all prime starts or validate the
imported PNT, Polymath8b or Dusart theorems. No whole-theorem Lean result,
independent human review, new prime-pattern infinitude or autonomous discovery
is claimed. Paper-specific formalization stays in private Primachsenraum.

## Stop line for this paper

The counting-function asymptotic, different weight regimes, and large-scale
algorithm comparisons remain follow-up research. The present additions do not
rely on their completion. General Regelsuche infrastructure is developed in
Regelsuche; manuscripts, detailed lemma mappings and campaign data stay here.
