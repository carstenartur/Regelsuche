# Revision audit — current editorial revision 4, 2 October 2026

## Revision 4: definition, literature and an open question

The sequence is now introduced in Section 1 through the residue-class definition of admissibility and the precise greedy extension rule. The example explains why 4 is rejected after 0, 2 and why 6 is accepted. The text distinguishes admissibility from an assumption about infinitely many prime translates. Section 3 refers back to these definitions and explains the cardinality cutoff in finite admissibility tests.

Ford, Luca and Moree's paper is now cited directly, in both the embedded bibliography and `references.bib`. Its Section 1.4 supplies the greedy definition and the reported first reciprocal-sum crossing of 2 at the 2089th term, 18932. The manuscript states the indexing conversion `a(i)=g_(i-1)` and does not present that published calculation as its own.

A brief paragraph after Section 6 asks whether the counting function has order `A*X/log(X)` in the asymptotic-equivalence sense. It explicitly gives no estimate of A, asserts no growth theorem, and contributes no assumption to the existing proof. No new large-range numerical study has been added.

The existing lemma, theorem, proposition and proof blocks are unchanged from revision 3. The numerical verifier, 14 numerical tests and reference certificates are also unchanged. This revision checks presentation and dependencies, including the strict ceiling threshold, the first-difference range, finite-window admissibility, the tail estimate, the order of limits, and the separate assumption for equality. It is an AI-assisted editorial check, not independent human review or proof-assistant verification.

The build writes its fresh numerical test output and regenerated certificates to `current-test-results.txt` and `current-certificates.json` in the exported supplement. The source manifest and the ZIP manifest identify the exact files. The historical records below describe revisions 2 and 3; their dates and scope are retained.

## Historical revision-2 audit — 13 September 2026

## What this audit is

This is an AI-assisted mathematical and computational revision record, not a referee report, independent human verification, or formal proof-assistant certificate. The 14 tests and exact numerical run were actually executed. No unresolved central proof gap was identified in this AI-assisted inspection; that finding does not guarantee correctness or novelty.

## Corrections to the earlier working note

**1. Singleton.** The earlier definition assigned a positive equilibrium exponent to every normalized finite admissible set. For `{0}`, the equation is `exp(-c)=1`, whose solution is `c=0`, not a positive value. Revision 2 explicitly defines this boundary case; all positive-root statements restrict to sets with at least two elements.

**2. Integer threshold.** From `s=floor(tau)+1`, the general bound is `0 < s-tau <= 1`, not `<1`. The endpoint can be attained when tau is an integer. No unproved nonintegrality assertion is used.

**3. Error-budget accounting.** The earlier proof assigned a local approximation error and three separate tail/composite errors, but displayed their total as only three delta terms. The new proof does not reuse that count. It works directly with `F_n(s)=(q-1)^s(D_n(s)-1)` and bounds every nonlocal coprime term in one uniform tail. This simplifies the proof and makes the order of limits explicit.

**4. Prior work.** Thompson's 2012 entries A217552 and A217926 were absent from the first note. They are now discussed in Section 1 and the references. The target's shift is `g+1`; Thompson's defining equation gives `g+2` with parameter `1/K`. A change of normalization is not treated as sufficient evidence of novelty. The first-difference lemma does not apply at Thompson's larger x-root.

**5. Scope.** The main claim is the unconditional upper bound. The conditional equality is separately labelled. Additional bounded-prime-gap lower-bound corollaries are omitted from this short version, not retracted or silently reclassified as a current record.

## Proof dependency map

1. Exact threshold: positive Dirichlet-series terms imply a unique decreasing crossing of `F_n(s)=1`; ordinary ceiling means a strict inequality. Section 2.
2. Finite admissibility: primes only up to cardinality need testing; normalized admissible sets are even. Section 3.
3. Greedy existence and admissibility of the union: explicit primorial extension and finite witnesses for residue coverage. Lemma 3.1.
4. First difference: the first missing greedy term dominates every possible subsequent even term when `2*x*x<1`. Lemma 3.2.
5. Root and finite-set supremum: exact two-thirds witness, continuity and monotone prefix roots; singleton handled separately. Theorem 3.3.
6. Uniform tail: near part bounded geometrically; far part bounded by an integral. Lemma 4.1.
7. Transfer: each FIXED local prime window is admissible for large q; composites cannot occur in the local coprime window since they start at q squared. All nonlocal terms are covered by Lemma 4.1. First n tends to infinity, then the window grows. Theorem 4.2.
8. Normalization: `p_(n+1)/p_n -> 1` is the standard prime number theorem consequence, not a new result.
9. Conditional converse: retains only finitely many prescribed prime terms, under the explicitly stated infinite-recurrence assumption. Proposition 6.1.

## What was executed

The Python supplement regenerated 91 greedy offsets through 512, checked the exact witness `1678250/1594323 > 1`, verified rational brackets for both shift-1 and shift-2 roots, and bounded their logarithms by positive rational series. All 14 unit tests pass. The 1,024-subset finite dominance test is a consistency check, not an exhaustive proof about all admissible sets. The exact certificate checks establish the stated numeric enclosures, conditional on the transparently stated arithmetic formulas; they do not formalize the analytic theorem.

## What remains unestablished

- A comprehensive independent human review of the complete revised argument.
- A formal theorem-prover verification.
- An exhaustive priority search across all literature.
- Acceptance by Zenodo or any journal.
- The author's final approval and licence decision for a public deposit.

At the time of revision 2, no consent to a personal acknowledgment was assumed. Publicly available papers are cited normally.

## Revision 3: permitted acknowledgment (13 September 2026)

An editorial acknowledgment to Benoît Cloitre has been added with permission, solely for pointing to Thompson’s related OEIS work. Its wording explicitly states that it implies no verification or endorsement of the results. The manuscript revision marker changes from 2 to 3. References start on a separate page to avoid an orphaned final citation; their content is unchanged. No mathematical statement, proof, reference, numerical program or certificate parameter has changed. No private correspondence is reproduced. The review status remains AI-assisted and not peer reviewed; this editorial revision is not a new independent mathematical audit.
