import importlib.util
import contextlib
import io
import shutil
import sys
from unittest.mock import patch
import re
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent

class ManuscriptAssemblyTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        spec = importlib.util.spec_from_file_location('build_review', HERE / 'build_review.py')
        cls.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(cls.module)
        cls.base = (HERE.parent / 'v4/manuscript.tex').read_text()

    def test_rejects_changed_base_before_assembly(self):
        with self.assertRaises(ValueError):
            self.module.assemble(self.base + '\n')

    def test_all_original_statement_and_proof_blocks_remain(self):
        result = self.module.assemble(self.base)
        pattern = r'\\begin\{(theorem|lemma|proposition|proof|remark)\}.*?\\end\{\1\}'
        old = [m.group() for m in re.finditer(pattern, self.base, re.S)]
        self.assertGreater(len(old), 10)
        for block in old:
            self.assertIn(block.replace(self.module.OLD_RECURRENCE_SCOPE, self.module.NEW_RECURRENCE_SCOPE), result)

    def test_retains_v4_introduction_counting_and_references(self):
        result = self.module.assemble(self.base)
        for start, end in [
            ('The prime-offset sequence used here', "Thompson's 2012 entry"),
            ('\\paragraph{Further question, not used in the proof.}', '\\section{Provenance'),
            ('\\bibitem{FordLucaMoree}', '\\bibitem{A217552}')]:
            block = self.base.split(start, 1)[1].split(end, 1)[0]
            self.assertIn(block.replace(self.module.OLD_RECURRENCE_SCOPE, self.module.NEW_RECURRENCE_SCOPE), result)

    def test_draft_version_and_new_references_resolve(self):
        result = self.module.assemble(self.base)
        self.assertIn(
            r'\date{17 November 2026 \quad\textbar\quad Manuscript revision 5 --- structural review draft}',
            result)
        self.assertIn('\\label{gk5:thm:rigidity}', result)
        self.assertIn('\\label{gk5:thm:twin}', result)
        self.assertIn('\\label{gk5:thm:effective}', result)
        labels = re.findall(r'\\label\{([^}]+)\}', result)
        self.assertEqual(len(labels), len(set(labels)))
        refs = re.findall(r'\\(?:eqref|ref)\{([^}]+)\}', result)
        self.assertEqual([], sorted(set(refs) - set(labels)))
        bibs = set(re.findall(r'\\bibitem\{([^}]+)\}', result))
        cites = set()
        for group in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}', result):
            cites.update(group.split(','))
        self.assertEqual(set(), cites - bibs)

    def test_inherited_numerical_sources_are_exact(self):
        for name, expected in self.module.INHERITED_BLOBS.items():
            self.assertEqual(expected, self.module.blob((HERE.parent/'v4/supplement'/name).read_bytes()))

    def test_only_one_document_and_bibliography(self):
        result = self.module.assemble(self.base)
        for token in ('\\begin{document}', '\\end{document}', '\\begin{thebibliography}'):
            self.assertEqual(1, result.count(token))

    def test_no_unannounced_replacement_of_sent_version(self):
        self.assertIn('723603459c381ae827b21107c62fa684c8a99eaa', self.module.BASE_BLOB)
        before = (HERE.parent / 'v4/manuscript.tex').read_bytes()
        self.module.assemble(self.base)
        self.assertEqual(before, (HERE.parent / 'v4/manuscript.tex').read_bytes())


class PackagingBoundaryTest(unittest.TestCase):
    def setUp(self):
        spec = importlib.util.spec_from_file_location('build_review', HERE / 'build_review.py')
        self.module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(self.module)
        self.directory = tempfile.TemporaryDirectory()
        self.addCleanup(self.directory.cleanup)
        self.root = Path(self.directory.name)
        self.draft = self.root / 'v5-draft'
        shutil.copytree(HERE, self.draft, ignore=shutil.ignore_patterns('build', '__pycache__'))
        shutil.copytree(HERE.parent / 'v4', self.root / 'v4',
                        ignore=shutil.ignore_patterns('build', '__pycache__'))

    def build(self, output=None, latex_warning=None):
        output = self.root / 'output' if output is None else output
        args = ['build_review', '--output-root', str(output)]
        def fake_typesetter(command, cwd, log):
            if command[0] == 'pdflatex':
                log.write_text('test typesetter, not a mathematical proof\n')
                (cwd / 'manuscript.log').write_text(latex_warning or '')
                (cwd / 'manuscript.pdf').write_bytes(b'test-only-placeholder')
            else:
                # Isolate packaging boundaries; the release build separately runs
                # every genuine numerical check and the genuine typesetter.
                log.write_text('mock dependency for packaging-boundary test only\n')
                if 'verify.py' in command and '--output' in command:
                    destination = Path(command[command.index('--output') + 1])
                    destination.write_bytes((cwd / 'certificates.json').read_bytes())
        if latex_warning is None:
            args.append('--sources-only')
        with patch.object(self.module, 'HERE', self.draft), patch.object(sys, 'argv', args), \
                patch.object(self.module, 'run', side_effect=fake_typesetter), \
                contextlib.redirect_stdout(io.StringIO()):
            self.module.main()

    def test_output_inside_v4_rejected_before_any_write(self):
        before = sorted(str(p.relative_to(self.root / 'v4')) for p in (self.root / 'v4').rglob('*'))
        # Stop a broken preflight before it could recursively copy itself.
        with patch.object(self.module, 'assemble', side_effect=ValueError('recursion safety stop')) as assemble:
            with self.assertRaises(ValueError):
                self.build(self.root / 'v4/supplement/build-output')
            self.assertFalse(assemble.called, 'immutable-root rejection must precede assembly and writes')
        after = sorted(str(p.relative_to(self.root / 'v4')) for p in (self.root / 'v4').rglob('*'))
        self.assertEqual(before, after)

    def test_symlink_alias_to_v4_is_also_rejected_before_writes(self):
        alias = self.root / 'alias'
        alias.symlink_to(self.root / 'v4', target_is_directory=True)
        with patch.object(self.module, 'assemble', side_effect=ValueError('recursion safety stop')) as assemble:
            with self.assertRaises(ValueError):
                self.build(alias / 'new-directory')
            self.assertFalse(assemble.called)
        self.assertFalse((self.root / 'v4/new-directory').exists())

    def test_extra_unvalidated_supplement_file_rejected(self):
        (self.root / 'v4/supplement/private-note.txt').write_text('must never be shared')
        with self.assertRaises(ValueError):
            self.build()
        self.assertEqual([], list(self.root.rglob('Golomb_Keller_v5_Source_Verification.zip')))

    def test_changed_provenance_is_not_just_copied(self):
        (self.root / 'v4/supplement/source-provenance.md').write_text('changed provenance')
        with self.assertRaises(ValueError):
            self.build()

    def test_missing_expected_provenance_file_rejected(self):
        (self.root / 'v4/supplement/revision-audit.md').unlink()
        with self.assertRaises(ValueError):
            self.build()

    def test_byte_identical_symlink_is_not_followed(self):
        source = self.root / 'v4/supplement/verify.py'
        outside = self.root / 'outside.py'
        outside.write_bytes(source.read_bytes())
        source.unlink()
        source.symlink_to(outside)
        with self.assertRaises(ValueError):
            self.build()

    def test_supplement_directory_symlink_rejected(self):
        source = self.root / 'v4/supplement'
        outside = self.root / 'outside-supplement'
        source.rename(outside)
        source.symlink_to(outside, target_is_directory=True)
        with self.assertRaises(ValueError):
            self.build()

    def test_python_cache_is_not_exported(self):
        cache = self.root / 'v4/supplement/__pycache__'
        cache.mkdir()
        (cache / 'generated.pyc').write_bytes(b'generated-local-cache')
        self.build()
        archive, = self.root.rglob('Golomb_Keller_v5_Source_Verification.zip')
        with self.module.zipfile.ZipFile(archive) as bundle:
            self.assertFalse(any('__pycache__' in name for name in bundle.namelist()))
            inherited = {Path(name).name for name in bundle.namelist() if '/supplement/' in name}
        self.assertEqual({'verify.py', 'test_verify.py', 'certificates.json',
                          'revision-audit.md', 'source-provenance.md', 'test-results.txt'}, inherited)

    def test_undefined_citations_block_export(self):
        with self.assertRaises(ValueError):
            self.build(latex_warning='LaTeX Warning: There were undefined citations.\n')

    def test_individual_undefined_citation_blocks_export(self):
        with self.assertRaises(ValueError):
            self.build(latex_warning="LaTeX Warning: Citation `missing' on page 3 undefined on input line 17.\n")

    def test_overfull_vertical_box_blocks_export(self):
        with self.assertRaises(ValueError):
            self.build(latex_warning='Overfull \\vbox (1.2pt too high) detected at line 12\n')

if __name__ == '__main__':
    unittest.main(verbosity=2)
