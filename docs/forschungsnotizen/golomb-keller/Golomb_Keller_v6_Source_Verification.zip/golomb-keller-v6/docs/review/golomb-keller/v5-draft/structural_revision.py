"""Assemble the approved structural extension of the already assembled v5 draft."""
from pathlib import Path


def replace_once(text: str, marker: str, replacement: str) -> str:
    if text.count(marker) != 1:
        raise ValueError('expected exactly one structural revision marker: '+marker[:90])
    return text.replace(marker,replacement,1)


def insert_once(text: str, marker: str, addition: str) -> str:
    return replace_once(text,marker,addition+'\n'+marker)


def apply(text: str, directory: Path) -> str:
    text=insert_once(text,r'\section{A quantitative stability statement}',
                     (directory/'structural-theorems.tex').read_text())
    text=insert_once(text,'\\clearpage\n\\begin{thebibliography}{9}',
                     (directory/'finite-rigidity.tex').read_text())
    text=replace_once(text,'Manuscript revision 5 --- review draft',
                     'Manuscript revision 5 --- structural review draft')
    old=('The original conditional proposition is retained. This review draft adds a quantitative stability '
         'argument and a converse characterizing equality by recurrence of every finite greedy prefix, '
         'a twin-prime dichotomy, and an explicit finite exponent guarantee. '
         'These implications do not establish any prime-recurrence conjecture.')
    new=('The original conditional proposition is retained. The actual limsup is characterized as the '
         'supremum of the equilibrium exponents of finite patterns having infinitely many prime translates. '
         'Quantitative stability characterizes equality by recurrence of every greedy prefix and gives '
         'an explicit finite missing-prefix criterion. A bounded-gap corollary supplies an unconditional '
         'positive lower bound, alongside a twin-prime dichotomy and an explicit sufficient exponent. '
         'These results do not establish any prime-recurrence conjecture.')
    text=replace_once(text,old,new)
    old=('The upper-bound argument above does not require the bounded-gap lower-bound corollaries or '
         'broader computational experiments of the earlier working package. The following new sections '
         'concern stability and recurrence implications, not a new bounded-prime-gap record.')
    new=('The following sections place the upper bound in a recurring-pattern characterization, '
         'include its bounded-gap lower-bound consequence, and make the stability implication effective. '
         'Broader computational experiments remain separate.')
    text=replace_once(text,old,new)
    bibliography=r'''\bibitem{Polymath8b}
D. H. J. Polymath, \emph{Variants of the Selberg sieve, and bounded intervals
containing many primes}, Research in the Mathematical Sciences \textbf{1}
(2014), Article 12. \newline
\url{https://arxiv.org/abs/1407.4897}.
\end{thebibliography}'''
    return replace_once(text,r'\end{thebibliography}',bibliography)
