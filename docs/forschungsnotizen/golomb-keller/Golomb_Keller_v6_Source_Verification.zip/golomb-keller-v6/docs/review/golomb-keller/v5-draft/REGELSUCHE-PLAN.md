# Regelsuche as an extensible proof system for this manuscript

## Implementation target, not a permanent capability limit

The authoritative development issue is
https://github.com/carstenartur/Regelsuche/issues/1066.
Generic proof-infrastructure PR: Regelsuche #1068 (still under integration).
The earlier application PR #1067 was closed without merging. Its paper-specific
consumer is in private Primachsenraum PR #341, under
`integrations/golomb-keller-proofs/`. Do not move manuscript-specific statements
back into the public infrastructure repository. Current execution claims must
be tied to the actual source, exact task, assumptions and retained run.

Use the existing `SolverIr.Obligation` and capability-aware portfolio.
Do not introduce a second AST, search engine or ad hoc proof status. The newer
Z3 adapter handles structured real predicates and obtains a proof object; the
old string-based Lean/SMT bridges are not the complete current architecture.

## Stages

1. **Universal algebra, now first.** Use the existing exact polynomial
   normal-form backend for denominator-cleared first-difference identities,
   denominator/reserve decompositions and stability-budget cancellation.
   Retain whole obligations, translations, results and executions. Deliberately
   false identities must be refuted. This is symbolic proof in the supported
   polynomial fragment, not testing a finite list of values.
2. **Real inequalities.** Use the existing Z3 adapter losslessly for strict
   signs and denominator obligations. Persist actual SMT input/output/proof
   objects and solver configuration, not merely a certificate hash. Test
   assumption consistency separately so an inconsistent premise set cannot
   silently authorize a claimed useful lemma.
3. **Checked Lean algebra.** Add a Lean backend for the same IR, with an exact
   theorem-type contract and transitive axiom audit. Reject placeholder proofs,
   unsupported sorts/operations, hidden axioms, stale artifacts and altered
   goals. PR #1068 replaces the old skeleton with bounded actual Lean proofs and a
   transitive axiom audit. Its general exp/log controls do not themselves prove
   any manuscript lemma. Verify the integrated revision before consuming it.
4. **Analytic IR and lemmas.** Extend, version and migrate the same IR for
   binders, capture-avoiding substitution, quantifiers, finite sets, summability
   and limits. Formalize the general first-difference inequality, geometric
   tail, uniform derivative bound and the local-to-global implication.
5. **Whole theorem.** Connect the missing-prefix contrapositive and equivalence
   only when dependencies are discharged. List PNT/Dusart as explicit external
   inputs unless checked library theorems are supplied. Preserve a full
   manuscript-to-formal-statement map and independent rebuild instructions.

## What a proof result may claim

The normal-form campaign's valid polynomial identities are elementary known
algebra. They can support the manuscript without establishing its analytic
claims, historical priority, autonomous discovery, a learning gain or a solver
speedup. A stored certificate hash is not a substitute for reconstructible
proof contents. An external mathematical reader still checks the translation
between the human statement and the formal theorem.

Reference for transitive axiom auditing:
https://lean-lang.org/doc/reference/latest/Axioms/

## Structural-addendum proof map

Formalization should proceed from the uniform mass-contraction inequality to
finite-window recurrence, then the transfer theorem. A successful rewrite of
an elementary identity is not evidence for this quantifier step. Next encode
the finite-rigidity local error and both tails with their exact side conditions,
then connect the rounding implication. Imported PNT, Polymath8b and Dusart must
be visible as dependencies unless their genuine library proofs are supplied.
The exact natural-power inequalities can be checked before the richer
set/summability/limit fragment is ready; keep that staged scope explicit.
