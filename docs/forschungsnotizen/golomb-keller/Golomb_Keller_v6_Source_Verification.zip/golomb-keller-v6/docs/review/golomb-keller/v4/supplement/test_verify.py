"""Finite checks for the numerical supplement; not a proof of the limsup theorem."""
import unittest
from decimal import Decimal, localcontext
from fractions import Fraction
import verify


class VerificationTests(unittest.TestCase):
    def test_primes(self):
        self.assertEqual(verify.primes_upto(20), [2, 3, 5, 7, 11, 13, 17, 19])

    def test_admissibility(self):
        self.assertTrue(verify.admissible([0, 2, 6, 8, 12]))
        self.assertFalse(verify.admissible([0, 2, 6, 8, 12, 14]))
        self.assertFalse(verify.admissible([0, 2, 6, 8, 12, 16]))
        self.assertFalse(verify.admissible([0, 1]))
        self.assertTrue(verify.admissible([0]))

    def test_greedy_reference_prefix(self):
        self.assertEqual(verify.greedy_prefix(60),
                         [0, 2, 6, 8, 12, 18, 20, 26, 30, 32, 36, 42, 48, 50, 56])

    def test_singleton_mass(self):
        self.assertEqual(verify.mass([0], Fraction(1)), 1)
        self.assertLess(verify.mass([0], Fraction(2, 3)), 1)

    def test_exact_witness(self):
        self.assertEqual(verify.mass([0, 2, 6, 8, 12], Fraction(2, 3)),
                         Fraction(1678250, 1594323))

    def test_polynomial_evaluation(self):
        x = Fraction(7, 11)
        g = [0, 2, 6, 8, 12]
        self.assertEqual(verify.mass(g, x), sum(x ** (h + 1) for h in g))

    def test_even_tail(self):
        x = Fraction(2, 3)
        self.assertEqual(verify.even_tail(x, 26), x ** 29 / (1 - x*x))
        self.assertEqual(verify.even_tail(x, 27), x ** 29 / (1 - x*x))

    def test_log_enclosure(self):
        lo, hi = verify.negative_log_bounds(Fraction(1, 2), 80)
        with localcontext() as ctx:
            ctx.prec = 110
            value = Decimal(2).ln()
            self.assertLess(Decimal(lo.numerator) / Decimal(lo.denominator), value)
            self.assertGreater(Decimal(hi.numerator) / Decimal(hi.denominator), value)

    def test_outward_rounding(self):
        self.assertEqual(verify.decimal_outward(Fraction(1, 3), 5, False), '0.33333')
        self.assertEqual(verify.decimal_outward(Fraction(1, 3), 5, True), '0.33334')
        self.assertEqual(verify.decimal_outward(Fraction(1, 2), 5, True), '0.50000')

    def test_rounding_endpoint(self):
        for tau in [Fraction(2), Fraction(9, 4), Fraction(299, 100)]:
            s = tau.numerator // tau.denominator + 1
            self.assertTrue(0 < s - tau <= 1)
        self.assertEqual((2 + 1) - Fraction(2), 1)

    def test_certified_root(self):
        g = verify.greedy_prefix(160)
        lo = Fraction('0.65048413696890252181')
        hi = Fraction('0.65048413696890252183')
        self.assertTrue(verify.verify_bracket(g, 160, lo, hi))

    def test_bad_root_rejected(self):
        g = verify.greedy_prefix(160)
        self.assertFalse(verify.verify_bracket(g, 160, Fraction('0.64'), Fraction('0.645')))
        self.assertFalse(verify.verify_bracket(g, 160, Fraction('0.66'), Fraction('0.67')))

    def test_invalid_inputs(self):
        with self.assertRaises(ValueError):
            verify.greedy_prefix(-1)
        with self.assertRaises(ValueError):
            verify.negative_log_bounds(Fraction(0), 10)
        with self.assertRaises(ValueError):
            verify.negative_log_bounds(Fraction(1, 2), 0)

    def test_first_difference_finite_family(self):
        # Exhaust every even normalized subset of {0,...,20} at x=2/3.
        g = verify.greedy_prefix(20)
        x = Fraction(2, 3)
        optimum = verify.mass(g, x)
        self.assertTrue(verify.admissible(g))
        for mask in range(1 << 10):
            h = [0] + [2 * (j + 1) for j in range(10) if mask & (1 << j)]
            if verify.admissible(h) and h != g:
                self.assertLess(verify.mass(h, x), optimum)


if __name__ == '__main__':
    unittest.main(verbosity=2)
