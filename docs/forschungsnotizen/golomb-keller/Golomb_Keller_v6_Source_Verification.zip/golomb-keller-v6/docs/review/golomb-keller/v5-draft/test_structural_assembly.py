"""Integration checks for the exact assembled manuscript, not mathematical proof."""
from pathlib import Path
import re
import unittest
import build_review

HERE=Path(__file__).resolve().parent
BASE=(HERE.parent/'v4/manuscript.tex').read_text()

class StructuralAssemblyTest(unittest.TestCase):
    def test_new_results_are_in_the_actual_assembled_manuscript(self):
        text=build_review.assemble(BASE)
        for label in ('gk5s:thm:recurring','gk5s:cor:coefficient','gk5s:cor:gap246',
                      'gk5s:prop:finite','gk5s:cor:known-prime'):
            self.assertIn('\\label{'+label+'}',text)

    def test_sent_v4_is_still_exact(self):
        self.assertEqual(build_review.blob(BASE.encode()),build_review.BASE_BLOB)
        build_review.assemble(BASE)
        self.assertEqual((HERE.parent/'v4/manuscript.tex').read_text(),BASE)

    def test_previous_statement_and_proof_blocks_are_retained(self):
        text=build_review.assemble(BASE)
        for content in (BASE,(HERE/'additions.tex').read_text(),(HERE/'appendix.tex').read_text()):
            for kind in ('theorem','lemma','proposition','corollary','proof','remark'):
                for block in re.findall(r'\\begin\{'+kind+r'\}.*?\\end\{'+kind+r'\}',content,re.S):
                    self.assertIn(block,text)

    def test_new_reference_and_earlier_literature_are_present(self):
        text=build_review.assemble(BASE)
        for ref in ('Polymath8b','Cloitre','FordLucaMoree','Dusart','A217552','A217926'):
            self.assertIn('\\bibitem{'+ref+'}',text)
        self.assertIn('Conjecture~19',text)
        self.assertIn('Remark~16',text)

    def test_disclaimer_stays_removed_and_computational_scope_stays_local(self):
        text=build_review.assemble(BASE)
        self.assertNotIn('No faster prime-generation or factorization algorithm is asserted.',text)
        self.assertIn('computational benefit depends',text)
        self.assertIn('review draft',text)

    def test_structural_insertions_fail_on_ambiguous_or_changed_markers(self):
        import structural_revision as r
        with self.assertRaises(ValueError): r.apply('unrelated input',HERE)
        old='\\section{A quantitative stability statement}'
        for malformed in ('without this marker', old+'\n'+old):
            with self.assertRaises(ValueError): r.insert_once(malformed,old,'new')

    def test_no_duplicate_labels_and_all_citations_defined(self):
        text=build_review.assemble(BASE)
        labels=re.findall(r'\\label\{([^}]+)\}',text)
        self.assertEqual(len(labels),len(set(labels)))
        cites=set()
        for field in re.findall(r'\\cite(?:\[[^]]*\])?\{([^}]+)\}',text):
            cites.update(field.split(','))
        self.assertLessEqual(cites,set(re.findall(r'\\bibitem\{([^}]+)\}',text)))

    def test_supplement_build_includes_new_certificate_checks(self):
        script=(HERE/'build_review.py').read_text()
        for filename in ('structural_checks.py','test_structural_checks.py','structural-certificates.json',
                         'STRUCTURAL-REVIEW.md'):
            self.assertIn(filename,script)

if __name__=='__main__': unittest.main()
