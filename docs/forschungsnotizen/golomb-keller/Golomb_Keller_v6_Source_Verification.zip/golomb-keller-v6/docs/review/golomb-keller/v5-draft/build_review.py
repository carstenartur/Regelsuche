#!/usr/bin/env python3
"""Build a review draft from exact, immutable v4 source. Never changes v4."""
from __future__ import annotations
import argparse
import difflib
import hashlib
import json
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path
import structural_revision

HERE = Path(__file__).resolve().parent
BASE_BLOB = '723603459c381ae827b21107c62fa684c8a99eaa'
BASE_COMMIT = '301ee78ea84fcd08ecbf459a8e23b9958d7c2362'
INHERITED_BLOBS = {
    'verify.py': '952f7b02ee92820601aaaab486a2f4120d9dd49d',
    'test_verify.py': '483f72869a453bfa5ea347710430f1361d04831a',
    'certificates.json': 'efe9a77b9e07c34af0a74613be40a53eebfc3062',
    'revision-audit.md': '25562f2f512f24f8a89e834fa9ec341d5bb22798',
    'source-provenance.md': '2192a08a663add434b2649855f15d7a08ec05bc0',
    'test-results.txt': 'cadcb006513b97f3e11b8c23d7367f88ec5bac4a',
}
OLD_RECURRENCE_SCOPE = ('That recurrence assumption is used only in\n'
                        'Section~\\ref{sec:conditional}.')
NEW_RECURRENCE_SCOPE = ('Its sufficiency is used in Section~\\ref{sec:conditional}; '
                        'the new converse characterizes it in Theorem~\\ref{gk5:thm:rigidity}.')



def blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def assemble(base: str) -> str:
    if blob(base.encode()) != BASE_BLOB:
        raise ValueError('v4 source does not match the reviewed base; reconcile before rebuilding')
    text = base.replace('2 October 2026 \\quad\\textbar\\quad Manuscript revision 4',
                        '17 November 2026 \\quad\\textbar\\quad Manuscript revision 5 --- review draft')
    text = text.replace('\\newcommand{\\cs}{c_*}',
                        '\\newcommand{\\cs}{c_*}\n\\newcommand{\\mc}[2]{M_{#1}(#2)}')
    # Editorial change in the new draft only; the pinned sent v4 is immutable.
    text = text.replace(' No faster prime-generation or factorization algorithm is asserted.', '')
    text = text.replace('\\rhead{Preprint: not peer reviewed}', '\\rhead{Revision 5: review draft}')
    text = text.replace('A separate conditional proposition identifies the limsup under recurrence of every finite greedy prefix.',
        'The original conditional proposition is retained. This review draft adds a quantitative stability argument and a converse characterizing equality by recurrence of every finite greedy prefix, a twin-prime dichotomy, and an explicit finite exponent guarantee. These implications do not establish any prime-recurrence conjecture.')
    old_scope = ('This short version focuses on the unconditional upper bound. The bounded-gap lower-bound corollaries and broader computational experiments in the earlier working package are not needed for its proof and are not included here.')
    new_scope = ('The upper-bound argument above does not require the bounded-gap lower-bound corollaries or broader computational experiments of the earlier working package. The following new sections concern stability and recurrence implications, not a new bounded-prime-gap record.')
    text = text.replace(old_scope, new_scope)
    text = text.replace(OLD_RECURRENCE_SCOPE, NEW_RECURRENCE_SCOPE)
    mark = '\\section{Provenance, AI assistance, and verification status}'
    if text.count(mark) != 1:
        raise ValueError('ambiguous disclosure insertion point')
    text = text.replace(mark, (HERE/'additions.tex').read_text()+'\n'+mark)
    mark = '\\textbf{No comprehensive independent human mathematical review'
    pos = text.index(mark)
    text = text[:pos] + ('Revision~5 is a review draft based on the complete revision~4, not a return to revision~3. '
        'It preserves all prior statement and proof blocks, explanations and references. '
        'Its added analytic arguments require external scrutiny; finite tests and algebraic solver checks do not prove their infinite-prime conclusions. '
        'The additional supplement distinguishes exact arithmetic, general algebraic obligations, and the remaining analytic formalization tasks.\n\n') + text[pos:]
    mark = '\\clearpage\n\\begin{thebibliography}{9}'
    if text.count(mark) != 1:
        raise ValueError('ambiguous bibliography insertion point')
    text = text.replace(mark, (HERE/'appendix.tex').read_text()+'\n'+mark)
    text = text.replace('\\end{thebibliography}', r'''\bibitem{Dusart}
P. Dusart, \emph{Estimates of Some Functions Over Primes without R.H.},
arXiv:1002.0442v1 (2010), Proposition 6.8, printed page 8.\newline
\url{https://arxiv.org/abs/1002.0442v1}. The stated interval is
$(x,x(1+1/(25\log^2 x))]$ for $x\ge396738$.
\end{thebibliography}''')
    return structural_revision.apply(text, HERE)


def run(command: list[str], cwd: Path, log: Path) -> None:
    with log.open('x') as out:
        result = subprocess.run(command, cwd=cwd, stdout=out, stderr=subprocess.STDOUT,
                                timeout=180, check=False)
    if result.returncode:
        raise RuntimeError(f'command failed ({result.returncode}); evidence retained at {log}')


def safe_output_root(requested: Path) -> Path:
    """Resolve aliases before creating anything in the immutable sent tree."""
    root = requested.resolve()
    preserved = (HERE.parent / 'v4').resolve()
    if root == preserved or preserved in root.parents:
        raise ValueError('output root must not be inside the immutable v4 tree')
    return root


def copy_inherited_supplement(source: Path, target: Path) -> None:
    """Validate the full public allowlist before writing any inherited file."""
    if source.is_symlink() or not source.is_dir():
        raise ValueError('expected a real v4 supplement directory, not a symlink')
    entries = {path.name: path for path in source.iterdir()}
    # A locally generated Python cache is never part of the sharing package.
    cache = entries.pop('__pycache__', None)
    if cache is not None and (cache.is_symlink() or not cache.is_dir()):
        raise ValueError('invalid local Python cache entry')
    if set(entries) != set(INHERITED_BLOBS):
        raise ValueError('v4 supplement must contain exactly the expected public files')
    contents = {}
    for name, expected in INHERITED_BLOBS.items():
        path = entries[name]
        if path.is_symlink() or not path.is_file():
            raise ValueError('inherited supplement file must not be a symlink: ' + name)
        data = path.read_bytes()
        if blob(data) != expected:
            raise ValueError('v4 inherited source changed: ' + name)
        contents[name] = data
    target.mkdir()
    for name, data in contents.items():
        with (target / name).open('xb') as output:
            output.write(data)


def validate_latex_log(log: str) -> None:
    pattern = (r'undefined (?:references|citations)|'
               r'(?:Citation|Reference)[^\n]*undefined|multiply defined|Overfull')
    if re.search(pattern, log, flags=re.IGNORECASE):
        raise ValueError('LaTeX reference, citation or layout warnings require inspection')


def main() -> None:
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, default=HERE/'build')
    parser.add_argument('--sources-only', action='store_true')
    args=parser.parse_args()
    args.output_root = safe_output_root(args.output_root)
    args.output_root.mkdir(parents=True,exist_ok=True)
    output=Path(tempfile.mkdtemp(prefix='review-',dir=args.output_root.resolve()))
    source=output/'source'; source.mkdir()
    try:
        run([sys.executable,'-m','unittest','-v','test_structural_assembly.py'],
            HERE,output/'structural-assembly-tests.log')
        base=(HERE.parent/'v4/manuscript.tex').read_text()
        assembled=assemble(base)
        (source/'manuscript.tex').write_text(assembled)
        (source/'v4-to-v5.patch').write_text(''.join(difflib.unified_diff(
            base.splitlines(True), assembled.splitlines(True),
            fromfile='v4/manuscript.tex',tofile='v5-draft/manuscript.tex')))
        # The published v4 supplement remains byte-identical in the standalone bundle.
        inherited=HERE.parent/'v4/supplement'
        copy_inherited_supplement(inherited, source/'supplement')
        extension=source/'extension'; extension.mkdir()
        for filename in ('checks.py','test_checks.py','certificates.json','README.md',
                         'REVIEW-CHECKLIST.md','REGELSUCHE-PLAN.md',
                         'structural_checks.py','test_structural_checks.py',
                         'structural-certificates.json','STRUCTURAL-REVIEW.md'):
            shutil.copyfile(HERE/filename,extension/filename)
        run([sys.executable,'-m','unittest','-v','test_verify.py'],source/'supplement',output/'v4-tests.log')
        run([sys.executable,'verify.py','--output',str(output/'v4-certificates.json')],source/'supplement',output/'v4-replay.log')
        expected=json.loads((inherited/'certificates.json').read_text())
        actual=json.loads((output/'v4-certificates.json').read_text())
        expected.pop('python_version',None); actual.pop('python_version',None)
        if expected!=actual: raise ValueError('old v4 certificate contents changed')
        for optimization in ([],['-O']):
            suffix='optimized' if optimization else 'normal'
            run([sys.executable,*optimization,'-m','unittest','-v','test_checks.py','test_structural_checks.py'],extension,output/f'extension-tests-{suffix}.log')
        run([sys.executable,'checks.py','--check','certificates.json'],extension,output/'extension-replay.log')
        run([sys.executable,'structural_checks.py','--check','structural-certificates.json'],
            extension,output/'structural-replay.log')
        hashes={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in sorted(source.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
        (source/'SOURCE-SHA256.json').write_text(json.dumps(hashes,indent=2,sort_keys=True)+'\n')
        for cache in source.rglob('__pycache__'): shutil.rmtree(cache)
        if not args.sources_only:
            for index in (1,2):
                run(['pdflatex','-halt-on-error','-interaction=nonstopmode','manuscript.tex'],source,output/f'latex-{index}.log')
            log=(source/'manuscript.log').read_text(errors='replace')
            validate_latex_log(log)
            shutil.copyfile(source/'manuscript.pdf',output/'Golomb_Keller_v5_Review_Draft.pdf')
        with zipfile.ZipFile(output/'Golomb_Keller_v5_Source_Verification.zip','x',zipfile.ZIP_DEFLATED) as archive:
            for path in sorted(source.rglob('*')):
                if path.is_file() and path.suffix not in ('.pdf','.aux','.log','.out'):
                    archive.write(path,'golomb-keller-v5-review/'+str(path.relative_to(source)))
            for path in sorted(output.glob('*.log')):
                archive.write(path,'golomb-keller-v5-review/executed/'+path.name)
        status={'status':'BUILT_REVIEW_DRAFT','base_commit':BASE_COMMIT,'base_blob':BASE_BLOB,
                'new_sha256':hashlib.sha256(assembled.encode()).hexdigest(),
                'independent_human_review':False,'whole_analytic_proof_formalized':False}
        (output/'build-status.json').write_text(json.dumps(status,indent=2)+'\n')
    except BaseException as error:
        (output/'FAILED.txt').write_text(f'{type(error).__name__}: {error}\n')
        raise
    print(output)

if __name__=='__main__': main()
