# Source and revision provenance

## Revision 4 — 2 October 2026

Baseline: repository `carstenartur/primachsenraum`, commit `acc67f0a00af291ea24789b78aef97175e52af10`, directory `docs/review/golomb-keller/v3/`. All nine frozen source hashes matched the restored revision-3 package before editing. Revision 4 preserves the existing statements and proof blocks, numerical programs and reference certificate parameters. It adds an earlier definition, an example, a direct literature reference and a separate exploratory counting-function paragraph.

New primary reference: Kevin Ford, Florian Luca and Pieter Moree, *Values of the Euler phi-function not divisible by a given odd prime, and the distribution of Euler-Kronecker constants for cyclotomic fields*, Mathematics of Computation 83 (2014), no. 287, 1447–1476; arXiv:1108.3805v3. The arXiv abstract record was used for bibliographic metadata and Section 1.4 of the HTML text for the sequence definition, indexing, and the reported reciprocal-sum threshold at 2089 terms and value 18932.

- https://arxiv.org/abs/1108.3805v3
- https://arxiv.org/html/1108.3805v3

The counting-function question is not presented as a new conjecture or attributed to a published theorem. This revision includes no private correspondence and makes no new personal acknowledgment or endorsement claim. The earlier source logs below are historical records; the final package's `repository-build.json` identifies its build source, and `SHA256SUMS.txt` pins the included bytes.

## Historical source log for revision 2

Checked on 13 September 2026. This is a source log, not an exhaustive literature search.

## Starting manuscript

Repository: `carstenartur/primachsenraum`  
Path: `docs/review/golomb-keller/research-note.tex`  
Git blob SHA read for the earlier manuscript: `17ba648ffd5048f3b876e8eab5ad718cdd1b9204`  
References path: `docs/review/golomb-keller/references.bib`  
References Git blob SHA: `41059cd35a7658b3ee089ab86766dd975fd8ce0e`

The sources were read through the connected GitHub tool. This local revision does not claim to have changed or committed the repository. A file/blob SHA is not a repository commit SHA.

## Primary mathematical sources

1. Benoit Cloitre, *An effective analytic recurrence for prime numbers*, arXiv:2508.02690v2. The public HTML and abstract record were consulted. Theorem 14 states the 0.4332 upper bound; Sections 3.2–3.3 give the recurrence and real/integer thresholds. The revised manuscript supplies its own normalized-threshold proof and uses the safe non-strict rounding endpoint.
   - https://arxiv.org/html/2508.02690v2
   - https://arxiv.org/abs/2508.02690v2
2. OEIS A135311. Defining greedy admissibility rule and displayed prefix checked. The supplement derives its prefix afresh rather than importing the OEIS table.
   - https://oeis.org/A135311
3. Roger Thompson, OEIS A217552 (6 October 2012). Formula, numerical value, conjectural comment and date were available in the indexed OEIS primary-source text; direct page retrieval was intermittently unsuccessful. No unexamined attached paper or full independent proof is attributed to this entry.
   - https://oeis.org/A217552
4. Roger Thompson, OEIS A217926 (15 October 2012). The zeta-product construction, upward rounding to the next odd integer and `P-2` failure threshold were checked in the public entry.
   - https://oeis.org/A217926

Only short source descriptions and mathematical facts are incorporated. Full third-party papers, OEIS dumps and private emails are not redistributed.

## Interpretation limits

The exact shift distinction is elementary algebra. It does not by itself prove historical novelty. The current note does not certify Thompson's conjectural claim or promote the previously discussed 240/246 lower bounds as current records. Its intended object of review is the unconditional upper-bound argument.

## Editorial revision 3

Derived from the committed v2 source package in `carstenartur/primachsenraum` at `77e81a38cc0843686a468958f1940f7c56bafdb5`. The prior source-check history above is retained; no fresh literature audit is represented. Revision 3 adds a permitted literature-pointer acknowledgment that explicitly excludes verification or endorsement, and updates the manuscript revision marker. The private permission correspondence is not part of the distributed package. The mathematical body, bibliography, numerical programs and reference certificates remain unchanged.
