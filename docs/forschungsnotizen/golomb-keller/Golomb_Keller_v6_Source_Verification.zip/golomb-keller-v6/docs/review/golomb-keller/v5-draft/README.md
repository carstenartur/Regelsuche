# Golomb–Keller revision 5 — review draft

Updated 17 November 2026. This draft continues the **sent revision 4** and the
structural draft of 4 October 2026. The November revision adds weighted
dominance at Thompson’s shift-two root.
The official-sharing README must continue to identify v4 until the author
chooses to promote a reviewed successor. No message, deposit, release or DOI
is created by building this draft.

## Preserved baseline

The assembler requires the exact v4 manuscript blob
`723603459c381ae827b21107c62fa684c8a99eaa` from commit
`301ee78ea84fcd08ecbf459a8e23b9958d7c2362`. It reads but never overwrites v4.
All original theorem/lemma/proposition/proof/remark blocks are preserved.
So are the introduction to admissibility, the rejected-4/accepted-6 example,
Ford–Luca–Moree discussion and reference, counting-function question,
Thompson/Cloitre attribution and permitted acknowledgment.

Only the draft/date/header, abstract, scope and recurrence cross-reference sentences are adjusted;
the new sections and the Dusart/Polymath references are inserted. The source ZIP includes
an exact v4-to-v5 diff so a previous recipient need not re-review unchanged
material. Original numerical checks and certificates remain in `supplement/`;
additional checks are separately identified under `extension/`.

## New mathematics proposed for scrutiny

- Quantitative first-difference loss and explicit exponent deficit
  `eta_m = (5/156) (13/20)^(g_m+1)`.
- Equality of the actual limsup with the admissibility extremum is equivalent
  to recurrence of every fixed finite greedy prefix. This characterizes an
  assumption; it does not prove that assumption.
- A twin-prime dichotomy with a non-strict lower bound and a separated upper
  bound in the eventual-gap-four case; no twin-prime infinitude claim.
- Appendix: sufficient exponent `ceil(431*p_n/1000)` for `p_n >= 10^6`,
  conditional only on the explicitly cited established inputs PNT/Dusart.
- Appendix: alternate qualitative compactness proof of the converse.

## Build and verify

From a repository checkout:

```sh
python3 -m unittest discover -s docs/review/golomb-keller/v5-draft -p 'test_*.py' -v
python3 docs/review/golomb-keller/v5-draft/build_review.py
```

Every build uses a new output directory, preserves failed-build logs and
refuses a modified v4 base. It executes the unchanged 14 v4 numerical tests,
regenerates and compares their certificate contents, executes all 24 extension
arithmetic tests normally and under `python -O`, and compares both extension
certificates. The repository-only assembly and packaging tests are separate.
LaTeX is compiled twice, with reference/layout warnings checked. A generated
PDF still requires visual inspection before distribution.

In the standalone source ZIP:

```sh
python3 -m unittest discover -s supplement -p 'test_verify.py' -v
python3 -m unittest discover -s extension -p 'test*checks.py' -v
python3 extension/checks.py --check extension/certificates.json
python3 extension/structural_checks.py --check extension/structural-certificates.json
pdflatex -halt-on-error manuscript.tex
pdflatex -halt-on-error manuscript.tex
```

## Evidence boundaries

A successful build proves neither historical novelty nor an infinite-prime
statement. No independent human mathematical review or complete Lean
formalization is claimed. Regelsuche issue #1066 and its first algebra campaign
separate universal polynomial identities from positivity, summability and
limit obligations. Unsupported steps remain explicitly open, not axioms
silently assumed by a success flag. See `REGELSUCHE-PLAN.md` and
`REVIEW-CHECKLIST.md`.

## Structural completion of the v5 working draft

The new section characterizes the actual limsup by recurring finite patterns,
adds the fixed-coefficient and bounded-gap corollaries, and Appendix C makes
the missing-prefix implication effective. See `STRUCTURAL-REVIEW.md` for the
exact scope, primary-source comparison and focused review questions. The
existing sent v4 files and all prior theorem/proof blocks remain unchanged.
This is a new identifiable working state of the unsent v5 draft, not a
replacement of a previously distributed v4. Use the source hash in reviews.

Additional repository checks (run from the repository root, not the exported ZIP):

```sh
python3 -m unittest discover -s docs/review/golomb-keller/v5-draft -p 'test_structural*.py' -v
python3 docs/review/golomb-keller/v5-draft/structural_checks.py --check docs/review/golomb-keller/v5-draft/structural-certificates.json
```

The normal build also runs the new finite checks and exports their certificate.
Concrete proof applications belong to the private consuming project, not the
public Regelsuche core. No general Lean demonstration is counted as a proof of
the analytic manuscript.

## Weighted dominance at Thompson’s root

The modulo-six first-difference proof includes its endpoint and establishes
strict optimality at Thompson’s shift-two root. The shift-three root lies
above the proved interval. The separate
[shift-three research note](../../../research/greedy-shift-three.md) records
the finite computations and their scope.
