#!/usr/bin/env python3
"""Recompute finite rational certificates for the proposed GK extension.

No external libraries, network, float signs, or imported prime tables.
The written proofs, PNT and Dusart's theorem are NOT proved by these checks.
"""
from __future__ import annotations
import argparse
from fractions import Fraction as F
import json
from pathlib import Path
from typing import Any

X_BRACKET = (F(650484136968902521, 10**18), F(650484136968902523, 10**18))


def integer(value: int, minimum: int, maximum: int, name: str) -> int:
    if type(value) is not int:
        raise TypeError(f'{name} must be an exact integer')
    if not minimum <= value <= maximum:
        raise ValueError(f'{name} outside [{minimum}, {maximum}]')
    return value


def unit_fraction(x: F) -> F:
    if type(x) is not F:
        raise TypeError('expected Fraction')
    if not 0 < x < 1:
        raise ValueError('expected 0 < x < 1')
    return x


def primes_up_to(n: int) -> tuple[int, ...]:
    integer(n, 0, 2048, 'prime bound')
    sieve = [True] * (n + 1)
    if n >= 0:
        sieve[0] = False
    if n >= 1:
        sieve[1] = False
    for p in range(2, n + 1):
        if sieve[p]:
            for j in range(p*p, n + 1, p):
                sieve[j] = False
    return tuple(i for i in range(2, n+1) if sieve[i])


def admissible(h: tuple[int, ...]) -> bool:
    if not isinstance(h, tuple) or not h or len(h) > 1025 or h[0] != 0:
        raise ValueError('expected a nonempty normalized tuple')
    previous = -1
    for a in h:
        integer(a, 0, 2048, 'offset')
        if a <= previous:
            raise ValueError('offsets must be strictly increasing')
        previous = a
    return all(len({a % p for a in h}) < p for p in primes_up_to(len(h)))


def greedy(cutoff: int) -> tuple[int, ...]:
    integer(cutoff, 0, 1024, 'cutoff')
    h = (0,)
    for a in range(1, cutoff + 1):
        if admissible(h + (a,)):
            h += (a,)
    return h


def mass(h: tuple[int, ...], x: F) -> F:
    unit_fraction(x)
    return sum((x**(a + 1) for a in h), F(0))


def parity_tail(x: F, cutoff: int) -> F:
    unit_fraction(x)
    integer(cutoff, 0, 2048, 'cutoff')
    first_even = 2 * (cutoff // 2 + 1)
    return x**(first_even + 1) / (1 - x*x)


def first_difference_gap(x: F, t: int) -> F:
    unit_fraction(x)
    integer(t, 0, 2048, 'first difference')
    if t % 2 or 2*x*x >= 1:
        raise ValueError('requires even t and x < 1/sqrt(2)')
    return x**(t + 1) * (1 - 2*x*x) / (1 - x*x)


def exponent_gap(last_offset: int) -> F:
    integer(last_offset, 2, 2048, 'last offset')
    if last_offset % 2:
        raise ValueError('greedy offsets are even')
    return F(5, 156) * F(13, 20)**(last_offset + 1)


def negative_log(x: F, terms: int = 50) -> tuple[F, F]:
    unit_fraction(x)
    integer(terms, 1, 200, 'terms')
    z = (1 - x) / (1 + x)
    lower = 2 * sum((z**(2*j+1) / (2*j+1) for j in range(terms)), F(0))
    tail = 2 * z**(2*terms+1) / ((2*terms+1)*(1-z*z))
    return lower, lower + tail


def polynomial_root(power: int, bits: int) -> tuple[F, F]:
    """Bracket the positive root of x + x**power = 1 using exact signs."""
    integer(power, 2, 10, 'power')
    integer(bits, 1, 128, 'bits')
    lo, hi = F(0), F(1)
    for _ in range(bits):
        mid = (lo + hi) / 2
        if mid + mid**power < 1:
            lo = mid
        else:
            hi = mid
    return lo, hi


def effective_components() -> dict[str, F]:
    x = F(13, 20)
    b = mass(greedy(26), x) + parity_tail(x, 26)
    u = F(431, 1000) * 64**2 / (2 * 10**6)
    near = b / (1 - u)
    middle_tail = F(81, 100)**65 / (1 - F(81, 100))
    remote_tail = F(3, 2**23)
    return dict(B=b, u=u, local=near, middle_tail=middle_tail,
                remote_tail=remote_tail, total=near+middle_tail+remote_tail)


def rational(x: F) -> dict[str, str]:
    return dict(numerator=str(x.numerator), denominator=str(x.denominator))


def decimal_enclosure(lo: F, hi: F, digits: int = 16) -> dict[str, str]:
    """Outward decimal rounding by integer division, not binary floating point."""
    scale = 10**digits
    a = lo.numerator * scale // lo.denominator
    b = -((-hi.numerator * scale) // hi.denominator)
    def fmt(n: int) -> str:
        return f'{n // scale}.{n % scale:0{digits}d}'
    return dict(lower=fmt(a), upper=fmt(b))


def build_report() -> dict[str, Any]:
    g = greedy(128)
    lo, hi = X_BRACKET
    m_lo = mass(g, lo) + parity_tail(lo, 128)
    m_hi = mass(g, hi)
    if not m_lo < 1 < m_hi:
        raise ArithmeticError('proposed root bracket did not verify')
    cstar = (negative_log(hi)[0], negative_log(lo)[1])
    beta = negative_log(F(7, 10))
    roots = {}
    intervals = {}
    for name, k in (('alpha_twin', 3), ('alpha_gap4', 4)):
        a, b = polynomial_root(k, 64)
        bounds = (negative_log(b)[0], negative_log(a)[1])
        intervals[name] = bounds
        roots[name] = dict(power=k, x_lower=rational(a), x_upper=rational(b),
                           c_outward_decimal=decimal_enclosure(*bounds))
    if not intervals['alpha_gap4'][1] < beta[0] < beta[1] < intervals['alpha_twin'][0]:
        raise ArithmeticError('twin-separator intervals did not separate')
    e = effective_components()
    if not e['total'] < F(1999, 2000):
        raise ArithmeticError('finite upper-bound certificate failed')
    valid = sum(admissible((0,) + tuple(2*i+2 for i in range(10) if mask >> i & 1))
                for mask in range(1024))
    return {
        'schema': 'golomb-keller-extension-finite-checks/v2',
        'verifies_infinite_prime_claims': False,
        'base_manuscript_git_blob': '723603459c381ae827b21107c62fa684c8a99eaa',
        'greedy_cutoff': 128, 'greedy_offsets': list(g),
        'x_star_bracket': [rational(lo), rational(hi)],
        'x_star_bracket_signs': dict(lower_total_below_one=m_lo < 1, upper_prefix_above_one=m_hi > 1),
        'c_star_outward_decimal': decimal_enclosure(*cstar),
        'stability': {
            'derivative_cap': rational(F(78, 25)),
            'prefix_deficit_factor': rational(F(1, 5)),
            'exponent_gap_coefficient': rational(F(5, 156)),
            'examples': [dict(last_offset=a, eta=rational(exponent_gap(a))) for a in (2,6,12,26,32)],
            'small_masks': 1024, 'admissible_masks': valid,
            'first_difference_finite_comparisons': 4 * valid,
        },
        'twin': {
            'separator': 'log(10/7)', 'separator_outward_decimal': decimal_enclosure(*beta),
            'pair_mass_at_7_over_10': rational(F(1043, 1000)),
            'gap4_hull_at_7_over_10': rational(F(7000, 7599)),
            **roots,
        },
        'effective': {**{k: rational(v) for k, v in e.items()},
                      'total_outward_decimal': decimal_enclosure(e['total'], e['total']),
                      'proven_upper_bound_on_total': rational(F(1999, 2000)),
                      'pn_start': 10**6, 'integer_exponent': 'ceil(431*pn/1000)',
                      'external_input': 'Dusart, arXiv:1002.0442v1, Proposition 6.8, printed page 8'},
        'boundary': 'Finite rational checks only. See the written proofs for quantifiers, local uniform convergence, tails and recurrence. No speed or scientific-priority claim.'
    }


def verify_report(report: Any) -> bool:
    try:
        if type(report) is not dict:
            return False
        actual = json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False)
        expected = json.dumps(build_report(), sort_keys=True, separators=(',', ':'), allow_nan=False)
        return actual == expected
    except (TypeError, ValueError, OverflowError):
        return False


def write_report(path: Path) -> None:
    text = json.dumps(build_report(), indent=2, sort_keys=True, allow_nan=False) + '\n'
    with path.open('x', encoding='utf-8') as out:
        out.write(text)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    group = parser.add_mutually_exclusive_group()
    group.add_argument('--write', type=Path)
    group.add_argument('--check', type=Path)
    args = parser.parse_args()
    if args.write:
        write_report(args.write)
        print('Finite certificates written. Infinite-prime claims are not machine-proved.')
    elif args.check:
        if args.check.stat().st_size > 1024*1024 or not verify_report(json.loads(args.check.read_text())):
            raise SystemExit('Certificate mismatch')
        print('Finite certificate recomputation matches exactly.')
    else:
        print(json.dumps(build_report(), indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
