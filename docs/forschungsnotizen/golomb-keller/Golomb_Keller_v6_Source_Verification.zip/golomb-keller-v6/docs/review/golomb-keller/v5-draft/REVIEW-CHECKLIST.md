# External review brief — revision 5 draft against sent revision 4

## Requested scope

Please distinguish correctness, completeness of the assumptions and historical
priority. A report about one checked lemma is valuable; no blanket endorsement
is requested. This work is substantially AI-assisted. Two author-side proof
routes and finite computations are not two independent reviews.

The principal new claim is the **converse**: if C_GK equals c_*, every fixed
finite greedy prefix occurs at infinitely many prime translates. It does not
assert equality or prove a prime-pattern conjecture.

## Primary checks

1. Uniformity: if a normalized admissible set omits any term of G_m, does the
   first differing term force the stated mass deficit uniformly over every
   continuation? Check t <= g_m, the direction of x^t monotonicity, and the
   distinction between containing a fixed prefix and realizing the infinite set.
2. Exponent conversion: confirm the root bracket 13/20 < x_* < 33/50, the
   interval above log(3/2), derivative bound 78/25, and D*eta_m=d_m/2.
   Verify termwise differentiation is justified uniformly for infinite sets.
3. Transfer: first fix a finite cutoff L, then let q grow, then increase L.
   Confirm all composites omitted from the local window are in the remote
   all-integer tail; never assume the entire translated prime set admissible.
4. Contrapositive: eventual absence of one **fixed** G_m yields one fixed
   strict limsup loss. Check this implies the converse and combines correctly
   with the previously proved conditional direction.
5. Twin dichotomy: retain only the two twin terms for the lower bound. In the
   opposite case use eventual prime spacing >=4 only for prime terms, not for
   composite terms of the Euler product. Check non-strict endpoints and the
   strict separator beta. No finite sample determines the limsup.
6. Finite bound: check each local/remote inequality and the exact statement of
   Dusart Prop. 6.8. Confirm the replacement of unknown next prime q by known
   p_n, and floor(tau)+1 <= ceil(b) from tau<b, including integral b.

## Literature questions

Is the quantitative missing-prefix implication, the converse characterization,
or the precise separated twin-prime dichotomy already in the literature?
The known greedy sequence, exponential-sum connection, and twin-prime lower
bound mechanism are not claimed as new. Ford–Luca–Moree material from v4 is
retained. The manuscript does not depend on the exploratory growth question.

## Suggested reply structure

- Exact version / source hash reviewed.
- Statements checked and statements not checked.
- Definite errors, missing justifications, and suggested improvements separately.
- Relevant prior work separately from the correctness report.
- Whether any quoted public acknowledgment would be permitted; absent consent,
  no private correspondence or implied endorsement is included in the manuscript.
