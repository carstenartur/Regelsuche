"""Finite controls for the structural addendum, not infinite-prime proofs."""
from fractions import Fraction as F
from pathlib import Path
import copy
import json
import tempfile
import unittest
import structural_checks as s
import checks


class StructuralCertificatesTest(unittest.TestCase):
    def test_pair_root_has_exact_opposite_signs(self):
        lo, hi = s.pair_root(246, 80)
        self.assertLess(lo + lo**247, 1)
        self.assertGreaterEqual(hi + hi**247, 1)
        self.assertEqual(hi - lo, F(1, 2**80))

    def test_lower_bound_log_interval_and_gap_monotonicity(self):
        intervals = []
        for d in (2, 4, 6, 246):
            lo, hi = s.pair_root(d, 64)
            intervals.append((checks.negative_log(hi)[0], checks.negative_log(lo)[1]))
        for a, b in zip(intervals, intervals[1:]):
            self.assertGreater(a[0], b[1])
        self.assertGreater(intervals[-1][0], F(166, 10000))
        self.assertLess(intervals[-1][1], F(167, 10000))

    def test_invalid_input_and_budgets_fail_explicitly(self):
        for d, bits in ((True, 80), (0, 80), (3, 80), (2048, 0), (4096, 64)):
            with self.assertRaises((ValueError, TypeError)):
                s.pair_root(d, bits)
        for g in (True, 0, 4, 7, 1026):
            with self.assertRaises((ValueError, TypeError)):
                s.finite_rigidity(g)

    def test_all_reported_thresholds_use_exact_ceilings(self):
        expected = {2: (37, 11, 99700), 6: (46, 13, 863281),
                    8: (51, 15, 2511599), 12: (60, 17, 19474166),
                    26: (93, 26, 19468624260)}
        for g, values in expected.items():
            r = s.finite_rigidity(g)
            self.assertEqual((r.L, r.K, r.Q), values)
            required = 4 * r.L**2 / r.d
            self.assertLess(r.Q - 1, required)
            self.assertGreaterEqual(r.Q, required)

    def test_three_error_budgets_and_minimal_search_boundaries(self):
        for g in checks.greedy(64)[1:]:
            r = s.finite_rigidity(g)
            self.assertLessEqual(6*F(5,6)**(r.L+1), r.d/8)
            self.assertGreater(6*F(5,6)**r.L, r.d/8)
            self.assertLessEqual(F(80,2**r.K), r.d)
            self.assertGreater(F(80,2**(r.K-1)), r.d)
            self.assertLessEqual(F(r.L**2,4*r.Q), r.d/16)
            self.assertTrue(s.verify_threshold(r))

    def test_local_error_envelope_plus_tails_remains_below_one(self):
        for g in (2, 6, 8, 12, 26):
            r = s.finite_rigidity(g)
            u = F(r.L**2, 4*r.Q)
            local = (1-r.d/2)/(1-u)
            tails = 6*F(5,6)**(r.L+1) + F(10, 2**r.K)
            self.assertLessEqual(local+tails, 1-r.d/8)
            self.assertGreater(r.d, 0)

    def test_integer_only_known_prime_start_is_sufficient(self):
        for g in (2, 6, 8, 12, 26):
            r = s.finite_rigidity(g)
            self.assertGreaterEqual(r.J**2, 1/(25*r.eta))
            self.assertLess((r.J-1)**2, 1/(25*r.eta))
            self.assertGreaterEqual(r.P, r.Q)
            self.assertGreaterEqual(r.P, 396738)
            self.assertGreaterEqual(r.P, 4**r.J)

    def test_constants_used_in_transcendental_envelopes(self):
        self.assertGreater(checks.negative_log(F(2,3), 20)[0], F(2,5))
        self.assertLess(checks.negative_log(F(13,20), 20)[1], F(1,2))
        self.assertGreater(2*checks.negative_log(F(1,2), 20)[0], 1)
        self.assertEqual(F(78,25)*F(5,156), F(1,10))

    def test_bad_threshold_fields_are_rejected_not_silently_recomputed(self):
        from dataclasses import replace
        r=s.finite_rigidity(12)
        for bad in (replace(r,Q=r.Q-1), replace(r,K=r.K-1), replace(r,L=r.L-1),
                    replace(r,d=r.d*2), replace(r,eta=r.eta*2), replace(r,J=r.J-1),
                    replace(r,P=r.P-1)):
            self.assertFalse(s.verify_threshold(bad))

    def test_uniform_contraction_for_finite_toy_patterns(self):
        # Algebraic analogue of e^{-(c-b)}; not a claim about recurring primes.
        for b in (F(1,3), F(1,2), F(2,3)):
            x=b*F(3,4)
            for mask in range(128):
                h=(0,)+tuple(2*(i+1) for i in range(7) if mask>>i&1)
                self.assertLessEqual(checks.mass(h,x), F(3,4)*checks.mass(h,b))

    def test_json_changes_or_infinite_proof_flags_are_rejected(self):
        report=s.build_report()
        self.assertTrue(s.verify_report(report))
        for key, value in (('infinite_prime_theorems_formally_verified',True),
                           ('schema','wrong')):
            bad=copy.deepcopy(report);bad[key]=value
            self.assertFalse(s.verify_report(bad))
        bad=copy.deepcopy(report);bad['finite_rigidity'][0]['Q']-=1
        self.assertFalse(s.verify_report(bad))

    def test_existing_report_is_never_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            p=Path(temp)/'certificate.json'
            s.write_report(p);before=p.read_bytes()
            with self.assertRaises(FileExistsError): s.write_report(p)
            self.assertEqual(before,p.read_bytes())
            self.assertTrue(s.verify_report(json.loads(before)))


if __name__ == '__main__': unittest.main()
