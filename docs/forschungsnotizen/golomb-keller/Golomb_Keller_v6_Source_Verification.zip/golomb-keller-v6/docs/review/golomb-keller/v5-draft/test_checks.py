"""Finite controls only: these do not prove any infinite-prime assertion."""
from fractions import Fraction as F
from pathlib import Path
import copy
import json
import tempfile
import unittest
import checks as c


class ExactControls(unittest.TestCase):
    def test_greedy_prefix(self):
        self.assertEqual(c.greedy(32), (0, 2, 6, 8, 12, 18, 20, 26, 30, 32))
        self.assertTrue(c.admissible(c.greedy(128)))

    def test_admissibility_against_independent_trial_division(self):
        # The control uses all divisors to recognize primes, not the tested sieve.
        for mask in range(1024):
            h = (0,) + tuple(2 * i + 2 for i in range(10) if mask >> i & 1)
            primes = [p for p in range(2, len(h) + 1)
                      if all(p % d for d in range(2, p))]
            expected = all(len({a % p for a in h}) < p for p in primes)
            self.assertEqual(c.admissible(h), expected)

    def test_first_difference_on_all_small_sets(self):
        g = c.greedy(40)
        for mask in range(1024):
            h = (0,) + tuple(2 * i + 2 for i in range(10) if mask >> i & 1)
            if not c.admissible(h):
                continue
            t = min(set(g) ^ set(h))
            self.assertIn(t, set(g) - set(h))
            for x in (F(1, 2), F(13, 20), F(33, 50), F(7, 10)):
                deficit = c.mass(g, x) - c.mass(h, x)
                self.assertGreaterEqual(deficit, c.first_difference_gap(x, t))

    def test_mass_extremal_bracket(self):
        lo, hi = c.X_BRACKET
        g = c.greedy(128)
        self.assertLess(c.mass(g, lo) + c.parity_tail(lo, 128), 1)
        self.assertGreater(c.mass(g, hi), 1)

    def test_rational_inverse_margin(self):
        self.assertGreater(c.mass((0, 2, 6, 8, 12), F(33, 50)), 1)
        d = F(2, 3) * (1 + F(2, 3)**2) / (1 - F(2, 3)**2)**2
        self.assertEqual(d, F(78, 25))
        for g_m in c.greedy(32)[1:]:
            delta = F(13, 20)**(g_m + 1) / 5
            eta = c.exponent_gap(g_m)
            self.assertGreater(eta, 0)
            self.assertLess(eta, F(1, 100))
            self.assertEqual(d * eta, delta / 2)
        log_ratio = c.negative_log(F(99, 100), 30)
        self.assertGreater(log_ratio[0], F(1, 100))

    def test_twin_separator(self):
        x = F(7, 10)
        self.assertEqual(x + x**3, F(1043, 1000))
        self.assertEqual(x / (1 - x**4), F(7000, 7599))
        b = c.negative_log(x, 50)
        r2, r4 = c.polynomial_root(3, 64), c.polynomial_root(4, 64)
        alpha2 = (c.negative_log(r2[1], 50)[0], c.negative_log(r2[0], 50)[1])
        alpha4 = (c.negative_log(r4[1], 50)[0], c.negative_log(r4[0], 50)[1])
        self.assertLess(alpha4[1], b[0])
        self.assertLess(b[1], alpha2[0])

    def test_effective_bound(self):
        data = c.effective_components()
        self.assertLess(data['B'], 1)
        self.assertLess(data['u'], 1)
        self.assertLess(data['total'], F(1999, 2000))
        self.assertGreater(F(81, 100)**2, F(13, 20))
        low, high = c.negative_log(F(13, 20), 50)
        self.assertGreater(low, F(2, 5))
        self.assertLess(high, F(1077, 2500))
        self.assertLess(F(1077, 2500) * F(3601, 3600), F(431, 1000))
        self.assertGreater(10**6, 2**18)
        self.assertGreater(F(2, 5) * 10**6, 24)
        self.assertGreater(F(2, 5) - F(1, 10**6), F(1, 3))

    def test_logarithm_series_consistency(self):
        for x in (F(1, 2), F(2, 3), F(7, 10), F(13, 20)):
            a, b = c.negative_log(x, 20)
            u, v = c.negative_log(x, 40)
            self.assertLess(a, u)
            self.assertLess(v, b)
            r, s = c.negative_log(x*x, 100)
            self.assertLessEqual(max(2*u, r), min(2*v, s))

    def test_exact_tail_index(self):
        x = F(2, 3)
        self.assertEqual(c.parity_tail(x, 26), x**29 / (1 - x*x))
        self.assertEqual(c.parity_tail(x, 27), c.parity_tail(x, 26))
        self.assertEqual(c.parity_tail(x, 28), x*x*c.parity_tail(x, 26))

    def test_invalid_input(self):
        for value in (True, -1, 1025, 3.0):
            with self.assertRaises((TypeError, ValueError)):
                c.greedy(value)
        for x in (F(0), F(1), F(-1)):
            with self.assertRaises(ValueError):
                c.negative_log(x, 20)
        with self.assertRaises(ValueError):
            c.first_difference_gap(F(3, 4), 2)
        with self.assertRaises(ValueError):
            c.exponent_gap(3)

    def test_report_and_tampering(self):
        report = c.build_report()
        self.assertTrue(c.verify_report(report))
        bad = copy.deepcopy(report)
        bad['effective']['total']['numerator'] = '0'
        self.assertFalse(c.verify_report(bad))
        bad = copy.deepcopy(report)
        bad['greedy_cutoff'] = 128.0
        self.assertFalse(c.verify_report(bad))
        self.assertFalse(report['verifies_infinite_prime_claims'])

    def test_output_never_overwrites(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'certificate.json'
            c.write_report(path)
            before = path.read_bytes()
            with self.assertRaises(FileExistsError):
                c.write_report(path)
            self.assertEqual(before, path.read_bytes())
            self.assertTrue(c.verify_report(json.loads(before)))


if __name__ == '__main__':
    unittest.main(verbosity=2)
