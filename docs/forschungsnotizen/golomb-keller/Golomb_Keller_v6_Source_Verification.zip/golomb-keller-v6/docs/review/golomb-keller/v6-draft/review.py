#!/usr/bin/env python3
"""Rebuild the private consolidated manuscript from pinned sources, or verify its inputs."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile
from fractions import Fraction
from math import isqrt
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
GK = Path("docs/review/golomb-keller")
RESEARCH = Path("docs/research/greedy-counting")
V4 = GK / "v4"
V5 = GK / "v5-draft"
V6 = GK / "v6-draft"
MANIFEST = HERE / "source-identities.json"
V5_SHA256 = "20a87f479311202afce8b6c1fad1174c5fe43ac699934eba1785ce919fdc2731"
DRAFT_FILES = ("README.md", "review.py", "test_review.py", "source-identities.json", "consolidated.tex")
ENV = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", SOURCE_DATE_EPOCH="1795132800",
           FORCE_SOURCE_DATE="1", TZ="UTC")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def stage_inputs(root, destination=None):
    """Resolve v4 blobs also from the sparse checkout; never substitute for a changed file."""
    root = root.resolve()
    raw = MANIFEST.read_bytes()
    require(sha(raw) == "6e415aeef65f68cbbddcd6b37495093cddb988b3cabf83a4f7bad71f7353d3f6",
            "digest mismatch: source identity manifest")
    manifest = json.loads(raw)
    require(sha((HERE / "consolidated.tex").read_bytes()) == manifest["v6_fragment_sha256"],
            "digest mismatch: consolidated.tex")
    for name, expected in manifest["git_blobs"].items():
        entry = root / name
        require(entry.resolve().is_relative_to(root) and not entry.is_symlink(), f"invalid source: {name}")
        if entry.is_file():
            data = entry.read_bytes()
        elif Path(name).is_relative_to(V4) and (root / ".git").exists():
            result = subprocess.run(["git", "-C", str(root), "cat-file", "blob", expected],
                                    capture_output=True)
            require(result.returncode == 0, f"missing historical blob for {name}: {expected}")
            data = result.stdout
        else:
            raise ValueError(f"missing source: {name}")
        git_header = f"blob {len(data)}\0".encode()
        require(hashlib.sha1(git_header + data).hexdigest() == expected, f"digest mismatch: {name}")
        if destination is not None:
            target = destination / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)


def run(command, cwd, log=None):
    result = subprocess.run(command, cwd=cwd, env=ENV, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, check=False)
    if log:
        log.write_bytes(result.stdout)
    if result.returncode:
        raise RuntimeError(f"{command} failed in {cwd}:\n" + result.stdout[-2000:].decode(errors="replace"))
    return result.stdout


def previous_manuscript(root):
    # Run the historical builder's pure assembly function against its own verified siblings.
    code = ("import build_review, sys; from pathlib import Path; "
            "base=Path('../v4/manuscript.tex').read_text(); "
            "sys.stdout.buffer.write(build_review.assemble(base).encode())")
    data = run([sys.executable, "-c", code], root / V5)
    require(sha(data) == V5_SHA256, "digest mismatch: complete assembled v5 manuscript")
    return data.decode()


def replace_once(text, before, after):
    require(text.count(before) == 1, "missing or ambiguous manuscript anchor: " + before[:70])
    return text.replace(before, after)


def assemble(v5):
    require(sha(v5.encode()) == V5_SHA256, "digest mismatch: assembled v5")
    text = replace_once(v5, "17 November 2026", "20 November 2026")
    text = replace_once(text, "Manuscript revision 5 --- structural review draft",
                        "Manuscript revision 6 --- consolidated review draft")
    text = replace_once(text, "Revision 5: review draft", "Revision 6: review draft")
    text = replace_once(text, r"\end{abstract}", r"""
We also prove unique weighted optimality through the positive-mass root
$\beta=0.7727457277\ldots$, exclude factors $3\pmod 4$ from $2g+1$ for all $g\in G$ through
$72\,461\,708\,495$,
and bound the shift-three supremum at its greedy root to within
$10^{-10\,000\,000}$ of one.
\end{abstract}""")
    anchor = r"\section{Provenance, AI assistance, and verification status}"
    text = replace_once(text, anchor, (HERE / "consolidated.tex").read_text() + "\n" + anchor)
    text = replace_once(text, r"\end{thebibliography}", r"""\bibitem{gk6:Bertrand}
S. Ramanujan, \emph{A proof of Bertrand's postulate}, Journal of the
Indian Mathematical Society \textbf{11} (1919), 181--182.
\newline\url{https://ramanujan.sirinudi.org/Volumes/published/ram24.html}.

\bibitem{gk6:Perry}
R. Michael Perry, \href{https://oeis.org/A274260/a274260.pdf}{1983 research report}.
See also OEIS \href{https://oeis.org/A274260}{A274260} (missing classes)
and \href{https://oeis.org/A274261}{A274261} (exhaustion numbers).

\bibitem{gk6:records}
\raggedright C. Hammer, \emph{Primachsenraum}, private repository research notes and
computational records, revision
\href{https://github.com/carstenartur/primachsenraum/tree/500cd3cea17a4b402dc839337d8802ccfca89125/docs/research}{\texttt{500cd3cea17a4b402dc839337d8802ccfca89125}}.
The review archive includes \path{greedy-exchange-threshold.md},
\path{greedy-shift-three.md} and \path{greedy-counting/half-residues.md}
under \path{docs/research/}. The accompanying
\path{certificate-1e8.json}, \path{integration-recheck-2026-10-04.json},
\path{shift-three-1e8.json} and \path{saturation-chronology-1e8.json}
are under \path{greedy-counting/validation/} there.
\end{thebibliography}""")
    return text


def check_certificates(root):
    src = root / RESEARCH / "src"
    run([sys.executable, "check_exchange_threshold.py"], src)
    # The pinned historical shift checker exposes its small rational controls independently.
    small = run([sys.executable, "-c", """
import json, numpy as np
from check_shift_three import root_bracket, uniform_bounds
from check_exchange_threshold import direct_greedy_prefix
print(json.dumps({"bracket":root_bracket(np.array(direct_greedy_prefix(160))), **uniform_bounds()}))
"""], src)
    shift = json.loads(small)

    def receipt(name):
        return json.loads((root / RESEARCH / "validation" / name).read_bytes())

    prefix = receipt("certificate-1e8.json")
    independent = receipt("integration-recheck-2026-10-04.json")["independently_verified"]
    hist = receipt("shift-three-1e8.json")
    chrono = receipt("saturation-chronology-1e8.json")
    require(hist["rational_root_bracket"] == shift.pop("bracket") and
            all(hist[key] == value for key, value in shift.items()), "small shift replay differs")
    for field in ("terms_sha256", "frozen_sha256"):
        require(hist[field] == independent[field] == chrono[field], "historical identity mismatch")
    n = 100_000_000
    require(prefix["valid"] is True and independent["valid"] is True and
            all(row["cutoff"] == n for row in (prefix, independent, hist, chrono)),
            "historical prefix verification incomplete")
    require(prefix["count"] == hist["number_terms"] == independent["count"] == 5522856 and
            prefix["last"] == hist["last_term"] == independent["last"] == 99999972 and
            hist["last_term"] + 8 <= n, "prefix coverage mismatch")
    distribution = hist["distribution_number_fresh_first_rejection_offsets"]
    require(distribution == [348258, 1058, 2, 0] and sum(distribution) ==
            hist["phase_zero_starts_gap_gt_8"] == 349318 and hist["phase_zero_starts"] == 680409
            and hist["previously_blocked_sieve_surviving_starts"] == [], "historical shift census mismatch")
    q = Fraction(157, 200)
    wheel = [r for r in range(30) if r % 2 == 0 and r % 3 != 1 and r % 5 != 4]
    bounds = {r: sum(q**((s-r) % 30 or 30) for s in wheel)/(1-q**30) for r in wheel}
    require(max(bounds[r] for r in wheel if r) < Fraction(953,1000) and
            max(bounds[0]-q**d for d in (2,6,8)) < Fraction(929,1000),
            "printed wheel bounds")
    require((q**2+q**6)/(1-q**6)-q**2 < Fraction(494,1000) and
            (q**4+q**6)/(1-q**6) < Fraction(802,1000), "printed seed bounds")
    u = Fraction(79, 100)
    require(Fraction(157, 200) < u and u**5 < 1-u**2 and u**10 < Fraction(1, 10)
            and n % 10 == 0, "strict uniform tail control")
    # Moduli and missing classes below are applications of the pinned historical half-class note;
    # recomputing residues verifies the table arithmetic, not the original classification.
    rows = [(371291, 68928503340, [(53549, 16344), (429589, 89112)]),
            (383659, 71224566884, [(5, 4), (229, 123)]),
            (389167, 72247102298, [(269, 126)]), (390323, 72461708496, [])]
    p = chrono["minimum_unsaturated_prime"]["prime"]
    require(p == 371291 and p*rows[-1][0] < 2*p*p, "invalid cofactor bound")
    for q, g, blockers in rows:
        require(p*q == 2*g+1 and p % 4 == q % 4 == 3, "factor-table arithmetic")
        for prime in [p, q] + [m for m, _ in blockers]:
            require(all(prime % d for d in range(2, isqrt(prime)+1)), "composite table modulus")
        require(all(g % m == r for m, r in blockers), "incorrect blocking residue")
    return {"beta_bracket": ["0.77274572771007138835", "0.77274572771007138836"],
            "shift_three_bracket": hist["rational_root_bracket"],
            "tail_decimal_exponent": n//10, "last_guaranteed_offset": rows[-1][1]-1,
            "large_campaign_reexecuted": False,
            "historical_input_sha256": {k: chrono[k] for k in
                                        ("terms_sha256","frozen_sha256","catalogue_sha256")}}


def build(out_root):
    out_root = out_root.resolve()
    for prior in (ROOT / V4, ROOT / V5):
        require(not out_root.is_relative_to(prior.resolve()), "use an output directory outside v4/v5")
    out_root.mkdir(parents=True, exist_ok=True)
    output = Path(tempfile.mkdtemp(prefix="review-", dir=out_root))
    package = output / "source"
    package.mkdir()
    stage_inputs(ROOT, package)
    draft = package / V6
    draft.mkdir()
    for name in DRAFT_FILES:
        shutil.copyfile(HERE / name, draft / name)
    manuscript = assemble(previous_manuscript(package))
    (package / "manuscript.tex").write_text(manuscript)
    # Preserve the supplement paths appearing in the historical manuscript.
    shutil.copytree(package / V4 / "supplement", package / "supplement")
    extension = package / "extension"
    extension.mkdir()
    for name in ("checks.py", "test_checks.py", "certificates.json", "README.md",
                 "REVIEW-CHECKLIST.md", "REGELSUCHE-PLAN.md", "structural_checks.py",
                 "test_structural_checks.py", "structural-certificates.json", "STRUCTURAL-REVIEW.md"):
        shutil.copyfile(package / V5 / name, extension / name)
    facts = check_certificates(package)
    (package / "verification.json").write_text(json.dumps(facts, indent=2) + "\n")
    for label, directory, args in [
            ("v4-tests", V4/"supplement", ["-m","unittest","-v","test_verify"]),
            ("v4-replay", V4/"supplement", ["verify.py","--output",str(output/"v4-current.json")]),
            ("v5-tests", V5, ["-m","unittest","discover","-v"]),
            ("v5-replay", V5, ["checks.py","--check","certificates.json"]),
            ("v5-structural-replay", V5, ["structural_checks.py","--check","structural-certificates.json"])]:
        run([sys.executable, *args], package / directory, output / (label+".log"))
    old = json.loads((package / "supplement/certificates.json").read_bytes())
    new = json.loads((output / "v4-current.json").read_bytes())
    for record in (old, new):
        record.pop("python_version", None)
    require(old == new, "v4 certificate replay differs")
    # TeX writes auxiliary files outside the source archive.
    tex = output / "typeset"
    tex.mkdir()
    shutil.copyfile(package / "manuscript.tex", tex / "manuscript.tex")
    for i in range(1,4):
        run(["pdflatex","-no-shell-escape","-halt-on-error","-interaction=nonstopmode","manuscript.tex"],
            tex, output / f"latex-{i}.log")
    log = (tex / "manuscript.log").read_text(errors="replace")
    require(not re.search(r"undefined (?:references|citations)|(?:Citation|Reference).*undefined|"
                          r"multiply defined|Overfull|Rerun to get|Missing character:", log, re.I),
            f"typesetting warning: inspect {tex/'manuscript.log'}")
    shutil.copyfile(tex / "manuscript.pdf", output / "Golomb_Keller_v6_Review_Draft.pdf")
    files = sorted(p for p in package.rglob("*") if p.is_file() and "__pycache__" not in p.parts)
    report = package / "SHA256SUMS"
    report.write_text("".join(f"{sha(p.read_bytes())}  {p.relative_to(package)}\n" for p in files))
    with zipfile.ZipFile(output / "Golomb_Keller_v6_Source_Verification.zip", "x") as archive:
        for p in [report, *files]:
            item = zipfile.ZipInfo("golomb-keller-v6/" + str(p.relative_to(package)),
                                   date_time=(2026,11,20,0,0,0))
            item.external_attr = 0o100644 << 16
            archive.writestr(item, p.read_bytes(), compress_type=zipfile.ZIP_DEFLATED)
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", action="store_true", help="verify pins and replay small exact certificates")
    parser.add_argument("--output-root", type=Path, default=HERE / "build")
    args = parser.parse_args()
    if args.check:
        stage_inputs(ROOT)
        print(json.dumps(check_certificates(ROOT), indent=2))
    else:
        print(build(args.output_root))
