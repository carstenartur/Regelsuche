# Consolidated Golomb–Keller review draft (v6, 20 November 2026)

This private revision adds three results to the complete structural v5 manuscript. The unique maximizer of the unshifted mass is the greedy set on the closed-right interval through β. The factor statement concerns greedy offsets through 72,461,708,495. The shift-three mass excess at its greedy root lies in [0, 10^−10000000). Exact equality at that root and membership of the next factor candidate remain open.

## Build and replay

From the repository or extracted source ZIP, with Python 3.10+, NumPy, and pdfLaTeX (TeX Live LaTeX Extra, recommended fonts, and Latin Modern) installed:

```sh
draft=docs/review/golomb-keller/v6-draft
python3 "$draft/review.py" --check
python3 -m unittest discover -s "$draft" -p 'test_*.py' -v
python3 "$draft/review.py"
```

Each full build creates a new directory under the draft's ignored `build/`, prints its path, and retains the manuscript, compiled PDF, standalone source ZIP and execution logs. Use `--output-root DIRECTORY` to select a different parent. The ZIP has fixed member timestamps and an internal `SHA256SUMS`. Run `sha256sum -c SHA256SUMS` in its extracted root to check all members before rebuilding. The PDF can also be typeset directly from the assembled `manuscript.tex` in that directory. Byte-for-byte PDF reproduction requires the same TeX toolchain.

## Evidence used

| Layer | Re-executed by the v6 builder | Historical records |
|---|---|---|
| Original manuscript and v5 extension | All v4 numerical tests, v4 certificate replay (ignoring only Python version metadata), v5 assembly and arithmetic tests, and both v5 certificate replays | Manuscript and supplement pinned to historical v4; all v5 assembly inputs pinned |
| Endpoint dominance | Generate greedy prefixes from finite admissibility, verify initial saturations, induction seeds and the 20-decimal bracket | The analytic product lemma and induction are arguments in the manuscript |
| Finite factor statement | Check the four products, primality of factors and blocker moduli, residues, cofactor inequality and inclusive endpoint | Exhaustive protection and enumeration derive from the pinned half-residue note, catalogue SHA-256 and its full replay program. The original work did not include a separate result JSON for the four rows |
| Shift three | Regenerate the 160-prefix, verify rational bracket, wheel and tail inequalities, cross-check ledger and prefix receipts | The phase counts, no-survivor sieve and saturation chronology come from the original large-prefix campaign |

`source-identities.json` records Git blob IDs of the imported paths and the SHA-256 of the v6 proof fragment. A full checkout reads the committed files. A sparse checkout may retrieve the exact historical v4 blobs from its Git object database. The standalone archive contains all required inputs for the normal v6 build, including the historical checker and generator programs, and needs no Git history. Missing or changed inputs stop verification. The three raw campaign files are identified by their SHA-256 values in `verification.json` in the built archive. The historical instructions in `docs/research/greedy-counting/README.md` describe how to regenerate them. The default build does not rerun that campaign.

The manuscript contains the mathematical proofs. The executable checks cover finite arithmetic and source identity. Comprehensive independent human review, proof-assistant formalization and historical priority are unclaimed. General-purpose algorithms belong to Regelsuche; this package documents the prime-specific application.
