"""Integration and tampering controls for the standalone v6 source package."""
import re
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[3]
GK = Path("docs/review/golomb-keller")


class ReviewTests(unittest.TestCase):
    def setUp(self):
        self.assertTrue((HERE / "review.py").is_file(), "v6 verification/assembly entrypoint missing")
        import review
        self.review = review

    def test_all_v5_statement_proof_blocks_and_references_survive(self):
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp)
            self.review.stage_inputs(ROOT, package)
            v5 = self.review.previous_manuscript(package)
            assembled = self.review.assemble(v5)
            blocks = re.findall(r"\\begin\{(theorem|lemma|proposition|corollary|proof|remark)\}.*?\\end\{\1\}", v5, re.S)
            self.assertEqual(len(blocks), 40)
            for m in re.finditer(r"\\begin\{(theorem|lemma|proposition|corollary|proof|remark)\}.*?\\end\{\1\}", v5, re.S):
                self.assertIn(m.group(), assembled)
            refs = re.findall(r"\\bibitem\{[^}]+\}", v5)
            self.assertTrue(all(item in assembled for item in refs))
            labels = re.findall(r"\\label\{([^}]+)\}", assembled)
            self.assertEqual(len(labels), len(set(labels)))
            self.assertLessEqual(set(re.findall(r"\\(?:eqref|ref)\{([^}]+)\}", assembled)), set(labels))
            self.assertLessEqual({"gk6:beta", "gk6:factor", "gk6:shift"}, set(labels))

    def test_wrong_or_missing_input_fails_closed_in_standalone_tree(self):
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp)
            self.review.stage_inputs(ROOT, package)
            for path in (GK / "v4/manuscript.tex", GK / "v5-draft/structural-theorems.tex",
                         Path("docs/research/greedy-shift-three.md"),
                         Path("docs/research/greedy-counting/validation/shift-three-1e8.json")):
                with self.subTest(path=path):
                    actual = package / path
                    original = actual.read_bytes()
                    actual.write_bytes(original + b" ")
                    with self.assertRaisesRegex(ValueError, "digest"):
                        self.review.stage_inputs(package)
                    actual.unlink()
                    with self.assertRaisesRegex(ValueError, "missing"):
                        self.review.stage_inputs(package)
                    actual.write_bytes(original)

    def test_exact_controls_and_report_identity(self):
        with tempfile.TemporaryDirectory() as tmp:
            package = Path(tmp)
            self.review.stage_inputs(ROOT, package)
            facts = self.review.check_certificates(package)
            self.assertEqual(facts["last_guaranteed_offset"], 72461708495)
            self.assertEqual(facts["tail_decimal_exponent"], 10000000)
            self.assertFalse(facts["large_campaign_reexecuted"])
            self.assertEqual(facts["beta_bracket"], ["0.77274572771007138835","0.77274572771007138836"])

if __name__ == "__main__":
    unittest.main()
