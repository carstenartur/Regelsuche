// Exact chronological greedy sieve for OEIS A135311.
// Work with h=g/2. Each relevant odd prime keeps its least absent residue.
// Residues below that witness have appeared in ACCEPTED terms. A witness can
// advance only after the candidate is accepted by every prime (transaction).
// No unproved cutoff on the primes is used.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <queue>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

struct State { uint32_t p,r; };
using Event=std::pair<uint64_t,uint32_t>;

int main(int argc,char**argv) try {
    if(argc!=3) throw std::runtime_error("usage: generator CUTOFF OUTPUT_PREFIX");
    std::string arg(argv[1]);
    if(arg.empty() || arg.find_first_not_of("0123456789")!=std::string::npos)
        throw std::runtime_error("cutoff must be a nonnegative integer");
    const uint64_t X=std::stoull(arg);
    if(X>UINT32_MAX) throw std::runtime_error("cutoff exceeds uint32 output range");
    const uint32_t H=X/2;
    const std::string prefix(argv[2]);
    std::ofstream out(prefix+".u32",std::ios::binary);
    std::ofstream frozen(prefix+"-frozen.csv");
    if(!out||!frozen) throw std::runtime_error("cannot open outputs");
    frozen<<"prime,forbidden_g_residue,first_rejected_g,count_before\n";
    const auto start=std::chrono::steady_clock::now();
    std::vector<uint8_t> member(uint64_t(H)+1,0), blocked(uint64_t(H)+1,0);
    std::vector<bool> composite(uint64_t(H)+2,false);
    std::vector<uint32_t> primes;
    for(uint64_t p=2;p<=uint64_t(H)+1;++p) if(!composite[p]) {
        if(p!=2) primes.push_back(p);
        if(p*p<=uint64_t(H)+1)
            for(uint64_t m=p*p;m<=uint64_t(H)+1;m+=p) composite[m]=true;
    }
    auto emit=[&](uint32_t g) { for(int j=0;j<4;++j) out.put((g>>(8*j))&255); };
    auto occupied=[&](uint32_t p,uint32_t r,uint32_t upto) {
        for(uint64_t h=r;h<=upto;h+=p) if(member[h]) return true;
        return false;
    };
    std::vector<State> states;
    std::priority_queue<Event,std::vector<Event>,std::greater<Event>> queue;
    auto schedule=[&](uint32_t id,uint32_t after) {
        const auto [p,r]=states[id];
        uint64_t delta=(uint64_t(r)+p-after%p)%p;
        if(!delta) delta=p;
        const uint64_t next=uint64_t(after)+delta;
        if(next<=H) queue.emplace(next,id);
    };
    uint64_t count=1,events=0,scans=0,freezes=0;
    uint32_t last=0;
    size_t next_prime=0;
    member[0]=1; emit(0);
    std::vector<uint32_t> matching,proposals;
    for(uint64_t hv=1;hv<=H;++hv) {
        const uint32_t h=hv;
        matching.clear(); proposals.clear();
        while(!queue.empty() && queue.top().first==h) {
            matching.push_back(queue.top().second); queue.pop(); ++events;
        }
        if(blocked[h]) {
            for(auto id:matching) schedule(id,h);
            continue;
        }
        bool reject=false;
        for(auto id:matching) {
            const auto [p,oldr]=states[id];
            uint32_t r=oldr+1;
            while(r<p) { ++scans; if(!occupied(p,r,h-1)) break; ++r; }
            proposals.push_back(r);
            if(r==p) {
                reject=true; ++freezes;
                frozen<<p<<','<<(uint64_t(2)*oldr)%p<<','<<2*hv<<','<<count<<'\n';
                for(uint64_t m=h;m<=H;m+=p) blocked[m]=1;
            }
        }
        if(reject) {
            for(size_t j=0;j<matching.size();++j)
                if(proposals[j]<states[matching[j]].p) schedule(matching[j],h);
            continue;
        }
        member[h]=1; ++count; last=2*hv; emit(last);
        for(size_t j=0;j<matching.size();++j) {
            states[matching[j]].r=proposals[j]; schedule(matching[j],h);
        }
        // A new prime can first forbid the p-th term: activate after p-1.
        while(next_prime<primes.size() && primes[next_prime]<=count+1) {
            const uint32_t p=primes[next_prime++];
            uint32_t r=1;
            while(r<p) { ++scans; if(!occupied(p,r,h)) break; ++r; }
            if(r==p) throw std::runtime_error("prime activation invariant failed");
            states.push_back({p,r}); schedule(states.size()-1,h);
        }
        if(count%100000==0)
            std::cerr<<"accepted="<<count<<" x="<<last<<" freezes="<<freezes<<'\n';
    }
    out.close(); frozen.close();
    if(!out||!frozen) throw std::runtime_error("output write failed");
    const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
    std::ofstream meta(prefix+"-meta.json");
    if(!meta) throw std::runtime_error("cannot open metadata output");
    meta<<"{\"cutoff\":"<<X<<",\"count\":"<<count<<",\"last\":"<<last
        <<",\"prime_states\":"<<states.size()<<",\"freezes\":"<<freezes
        <<",\"events\":"<<events<<",\"residue_scans\":"<<scans
        <<",\"seconds\":"<<seconds<<",\"format\":\"uint32 little endian, includes zero\"}\n";
    meta.close();
    if(!meta) throw std::runtime_error("metadata write failed");
    std::cerr<<"complete count="<<count<<" last="<<last<<" seconds="<<seconds<<'\n';
    return 0;
} catch(const std::exception&e) { std::cerr<<e.what()<<'\n'; return 1; }
