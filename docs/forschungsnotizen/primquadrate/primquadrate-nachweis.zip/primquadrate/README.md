# Primquadrate und erste Primvielfache in der kanonischen Greedy-Folge

Fassung 1, 28. November 2026. Alle Befehle laufen nach dem Entpacken im Ordner mit dieser Datei. Der Ordner enthält die Quellen und Resultatprotokolle. Die großen, aus den Quellen erzeugbaren Offsetlisten sind ausgelassen.

## Kurztest, etwa eine Sekunde

    python3 -B pruefen.py kurz

Python 3.9 oder neuer mit Standardbibliothek genügt. Der Test baut das kanonische Präfix bis 282 direkt nach Definition auf, prüft die Sättigungszeiten und alle 1728 Einheiten modulo 2405. Er prüft die Phasen und die Produktdichte des Vier-Modul-Beweises, zählt die 368306 Primzahlen und rechnet den Grenzzeugen arithmetisch nach. Die großen Mitgliedschaftsaussagen sind Gegenstand der nachfolgenden Prüfungen.

## Ketten und kleine Kontrolle der beiden Großverfahren

Benötigt werden C++20, OpenSSL mit Entwicklungs-Headern und libcrypto, Python mit NumPy (getestet mit Python 3.12 und NumPy 2.3). Die C++-Programme stammen aus dem öffentlichen Beilagenpaket zur Vierseitennotiz. Die Vorzeichenkonvention, das Offsetformat und die Befehle sind mit diesem Paket kompatibel. Generator und unabhängiger Prüfer arbeiten verschieden. Der Prüfer weist eine fehlende Klasse für jede relevante Primzahl und eine zum Entscheidungszeitpunkt wirksame Sperre für jeden ausgelassenen geraden Kandidaten nach.

    mkdir -p work
    c++ -O3 -std=c++20 -Wall -Wextra -Werror generator.cpp -o work/generator
    c++ -O3 -std=c++20 -Wall -Wextra -Werror verify_prefix.cpp -lcrypto -o work/verify_prefix
    c++ -O3 -std=c++20 -Wall -Wextra -Werror saturation_chronology.cpp -o work/saturation
    work/generator 1000000 work/g-1m
    work/verify_prefix 1000000 work/g-1m.u32 work/g-1m-frozen.csv work/ok-1m.json work/miss-1m.csv
    work/saturation derive 1000000 work/g-1m.u32 work/catalogue-1m.csv
    work/saturation verify 1000000 work/g-1m.u32 work/catalogue-1m.csv
    python3 -B pruefen.py dichte work/g-1m.u32 work/catalogue-1m.csv --klein
    python3 -B pruefen.py vielfache work/g-1m.u32 --klein
    work/generator 40000000 work/g-40m
    work/verify_prefix 40000000 work/g-40m.u32 work/g-40m-frozen.csv work/ok-40m.json work/miss-40m.csv
    python3 -B pruefen.py potenzen work/g-40m.u32

Der Millionenlauf ergibt 339 gesättigte quadratische Sperren und einen Ausschlussanteil von rund 0,7832503. Alle 509 Primzahlen 1 mod 4 unter 8171 haben einen ersten Kofaktor höchstens 37. Der 40-Millionen-Lauf ergab 2.338.323 Elemente, letzte Aufnahme 39.999.996. Der SHA-256-Wert der little-endian uint32-Datei ist 53adcd10bd06776a1f97cb3e6b60668844028b359834b5e3aa982238890c392f. Das hier frisch geprüfte 40-Millionen-Präfix bestätigt alle vier Sperren für die vollständigen Ketten. Der Prüfer bestätigt außerdem mit fünf Sperren den gesamten Quadrierungsorbit des konkreten Primzahlstarts 191160287.

## Vollständige Wiederholung der 82,60-Prozent-Rechnung

Die folgenden Großläufe sind für eine Workstation mit mehreren GB RAM und erheblicher Rechenzeit vorgesehen. Das veröffentlichte Protokoll für die 500-Millionen-Rechnung ist square-gap-density-500m.json. Beim Erstellen dieser Beilage wurden die kurzen Läufe wiederholt. Die historischen Großläufe stammen aus dem Projekt.

    work/generator 500000000 work/g-500m
    work/verify_prefix 500000000 work/g-500m.u32 work/g-500m-frozen.csv work/ok-500m.json work/miss-500m.csv
    work/saturation derive 500000000 work/g-500m.u32 work/catalogue-500m.csv
    work/saturation verify 500000000 work/g-500m.u32 work/catalogue-500m.csv
    python3 -B pruefen.py dichte work/g-500m.u32 work/catalogue-500m.csv
    python3 -B check_power_orbits.py work/catalogue-500m.csv --check power-orbits-500m.json

Der Dichteprüfer vergleicht die SHA-256-Werte der beiden Eingaben mit den historischen Werten, bestimmt alle gesättigten quadratischen Normlücken sowie alle erzwungenen quadratischen Normlücken der ungesättigten Primmoduln 1 mod 4 bis 2.300.000. Die SHA-256-Summe der 641 Lückenlisten, die Anzahl sämtlicher Moduln und das mit ganzen Zahlen geprüfte Dezimalintervall müssen übereinstimmen.

Der zweite Python-Aufruf vergleicht die historische schärfere Kettendichte mit ihrem Protokoll. Acht Regeln füllen alle Phasen eines zwölfstufigen Zyklus. Die noch offenen Anfangsstufen werden mit anderen Quadratregeln und Inklusion–Exklusion gezählt. Der Prüfer rundet die Produkte nach außen.

## Vollständige Wiederholung der ersten Vielfachen

Im historischen Projektlauf wurde das kanonische 500-Millionen-Präfix durch chronologische Einzelentscheidungen erweitert (split-factor-support-500m.json, split-factor-witness.json). Hier ist ein anderer, vom ersten bis zum letzten Offset durchlaufender Weg angegeben. Er braucht nur den Generator, den unabhängigen Präfixprüfer und den Python-Vielfachentest.

    work/generator 832200536 work/g-voll
    work/verify_prefix 832200536 work/g-voll.u32 work/g-voll-frozen.csv work/ok-voll.json work/miss-voll.csv
    python3 -B pruefen.py vielfache work/g-voll.u32

Für jede Primzahl q werden die Kofaktoren 1,5,9,…,181 der Reihe nach gegen die kanonische Offsetliste geprüft. Alle beliebigen übrigen positiven Kofaktoren sind bereits modulo 4 ausgeschlossen. Der letzte Befehl verlangt für jede der 368.306 Primzahlen mindestens einen Treffer und die exakte Schranke 5m ≤ q, sowie m=149 für 11.170.477 und Maximum 181 über alle kleinsten Kofaktoren.
