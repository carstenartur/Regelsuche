// Compute or audit the first accepted offset at which p-1 distinct residues
// have occurred for every relevant prime p. C++20, no external dependencies.
// Usage: saturation_chronology {derive|verify} CUTOFF TERMS.u32 CATALOGUE.csv
// TERMS must be the complete, independently certified prefix through CUTOFF.
#include <algorithm>
#include <bit>
#include <charconv>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace {
constexpr char header[] = "prime,missing_residue,saturation_g";

uint32_t integer(std::string_view text) {
    uint32_t result = 0;
    const auto [end, error] = std::from_chars(text.data(), text.data() + text.size(), result);
    if (error != std::errc{} || end != text.data() + text.size())
        throw std::invalid_argument("invalid uint32: " + std::string(text));
    return result;
}

struct Prefix {
    uint32_t cutoff;
    std::vector<uint32_t> terms;
    std::vector<bool> composite;
};

Prefix read_prefix(uint32_t cutoff, const std::string& filename) {
    Prefix prefix{cutoff, {}, {}};
    std::ifstream input(filename, std::ios::binary);
    if (!input) throw std::runtime_error("cannot open term input");
    unsigned char bytes[4];
    while (input.read(reinterpret_cast<char*>(bytes), sizeof(bytes))) {
        const uint32_t g = uint32_t(bytes[0]) | (uint32_t(bytes[1]) << 8)
            | (uint32_t(bytes[2]) << 16) | (uint32_t(bytes[3]) << 24);
        if (g > cutoff || g % 2 || (!prefix.terms.empty() && g <= prefix.terms.back()))
            throw std::runtime_error("terms must be strictly increasing even offsets within the cutoff");
        prefix.terms.push_back(g);
    }
    if (input.bad() || input.gcount() != 0 || prefix.terms.empty() || prefix.terms.front() != 0)
        throw std::runtime_error("truncated term input or missing initial zero");
    // A saturation requires p-1 terms. Every other prime is automatically unsaturated.
    const auto limit = uint32_t(prefix.terms.size() + 1);
    prefix.composite.resize(size_t(limit) + 1);
    for (uint32_t p = 2; uint64_t(p)*p <= limit; ++p) {
        if (!prefix.composite[p])
            for (uint64_t m = uint64_t(p)*p; m <= limit; m += p) prefix.composite[m] = true;
    }
    return prefix;
}

struct Claim {
    uint32_t residue = 0;
    uint32_t offset = 0;
    bool present = false;
};

uint64_t low_mask64(unsigned width) {
    return width == 64 ? UINT64_MAX : (uint64_t(1) << width) - 1;
}

Claim last_first_hit(uint32_t p, const std::vector<uint64_t>& terms, uint32_t half_cutoff) {
    // Work in g/2; multiplication by 2 permutes residues modulo this odd p.
    uint32_t last = 0, omitted = 0, absent_count = 0;
    for (uint32_t group = 0; group < p && absent_count < 2; group += 64) {
        const auto wanted = low_mask64(std::min(64u, p - group));
        uint64_t seen = ~wanted, last_base = 0, last_new = 0;
        for (uint64_t base = group; base <= half_cutoff; base += p) {
            const unsigned shift = base % 64;
            uint64_t block = terms[base / 64] >> shift;
            if (shift) block |= terms[base / 64 + 1] << (64 - shift);
            // Bits after the cutoff are zero and bits outside this group are pre-marked.
            const uint64_t added = block & ~seen;
            if (added) {
                last_base = base;
                last_new = added;
                seen |= added;
                if (seen == UINT64_MAX) break;
            }
        }
        if (last_new) {
            const auto group_last = uint32_t(last_base + 63 - std::countl_zero(last_new));
            last = std::max(last, group_last);
        }
        if (seen != UINT64_MAX) {
            absent_count += std::popcount(~seen);
            omitted = group + std::countr_zero(~seen);
        }
    }
    if (!absent_count) throw std::runtime_error("input is not admissible");
    return {uint32_t((uint64_t(2)*omitted) % p), 2*last, absent_count == 1};
}

void derive(const Prefix& prefix, const std::string& filename) {
    const uint32_t half = prefix.cutoff / 2;
    std::vector<uint64_t> packed(size_t(half) / 64 + 2);
    for (auto g : prefix.terms) {
        const auto h = g / 2;
        packed[h / 64] |= uint64_t(1) << (h % 64);
    }
    std::ofstream out(filename, std::ios::binary);
    if (!out) throw std::runtime_error("cannot write catalogue");
    out << header << "\n2,1,0\n";
    uint32_t saturated = 1;
    for (uint32_t p = 3; p < prefix.composite.size(); p += 2) {
        if (prefix.composite[p]) continue;
        const auto claim = last_first_hit(p, packed, half);
        if (claim.present) {
            out << p << ',' << claim.residue << ',' << claim.offset << '\n';
            ++saturated;
        }
    }
    out.close();
    if (!out) throw std::runtime_error("catalogue write failed");
    std::cout << "saturated_primes=" << saturated << '\n';
}

std::vector<Claim> read_catalogue(const Prefix& prefix, const std::string& filename) {
    std::ifstream input(filename);
    std::string line;
    if (!std::getline(input, line) || line != header) throw std::runtime_error("bad CSV header");
    std::vector<Claim> claims(prefix.composite.size());
    uint32_t previous = 1;
    while (std::getline(input, line)) {
        const auto first = line.find(',');
        const auto second = first == std::string::npos ? first : line.find(',', first + 1);
        if (second == std::string::npos) throw std::runtime_error("invalid CSV row");
        const auto row = std::string_view(line);
        const uint32_t p = integer(row.substr(0, first));
        const uint32_t r = integer(row.substr(first + 1, second - first - 1));
        const uint32_t g = integer(row.substr(second + 1));
        if (p <= previous || p >= claims.size() || prefix.composite[p] ||
            r >= p || g > prefix.cutoff || g % 2)
            throw std::runtime_error("invalid, unordered or duplicate prime claim");
        claims[p] = {r, g, true};
        previous = p;
    }
    if (input.bad() || !claims[2].present || claims[2].residue != 1 || claims[2].offset != 0)
        throw std::runtime_error("catalogue read failure or invalid claim for two");
    return claims;
}

class Coverage {
    // Separate byte-indexed representation. Audit 32 progressions at once using an
    // explicit five-byte little-endian window; the producer uses aligned 64-bit words.
    std::vector<uint8_t> bytes;

public:
    explicit Coverage(const Prefix& prefix) : bytes(size_t(prefix.cutoff) / 16 + 6) {
        for (auto g : prefix.terms) {
            const auto h = g / 2;
            bytes[h / 8] |= uint8_t(1u << (h % 8));
        }
    }

    bool contains(uint32_t h) const {
        return (bytes[h / 8] >> (h % 8)) & 1;
    }

    bool absent(uint32_t residue, uint32_t p, uint32_t through) const {
        for (uint64_t h = residue; h <= through; h += p)
            if (contains(uint32_t(h))) return false;
        return true;
    }

    static uint32_t mask(unsigned width) {
        return width == 32 ? UINT32_MAX : (uint32_t(1) << width) - 1;
    }

    uint32_t covered(uint32_t start, uint32_t p, uint32_t through, uint32_t wanted) const {
        uint32_t seen = 0;
        for (uint64_t h = start; h <= through && (seen & wanted) != wanted; h += p) {
            const auto* ptr = bytes.data() + h / 8;
            const uint64_t word = uint64_t(ptr[0]) | (uint64_t(ptr[1]) << 8)
                | (uint64_t(ptr[2]) << 16) | (uint64_t(ptr[3]) << 24) | (uint64_t(ptr[4]) << 32);
            const uint32_t valid = mask(unsigned(std::min<uint64_t>(32, 1 + through - h)));
            seen |= uint32_t(word >> (h % 8)) & valid;
        }
        return seen;
    }
};

void verify_saturated(const Coverage& coverage, uint32_t p, Claim claim, uint32_t half) {
    const auto time = claim.offset / 2;
    const uint32_t omitted = (uint64_t(claim.residue) * ((p + 1) / 2)) % p;
    // t must occur, its class must be new there, and the exceptional class absent even at N.
    if (!time || !coverage.contains(time) || time % p == omitted ||
        !coverage.absent(omitted, p, half) || !coverage.absent(time % p, p, time - 1))
        throw std::runtime_error("invalid missing or last residue at prime " + std::to_string(p));
    for (uint32_t start = 0; start < p; start += 32) {
        uint32_t wanted = Coverage::mask(std::min(32u, p - start));
        if (omitted >= start && omitted - start < 32) wanted &= ~(uint32_t(1) << (omitted - start));
        if ((coverage.covered(start, p, time, wanted) & wanted) != wanted)
            throw std::runtime_error("premature saturation at prime " + std::to_string(p));
    }
}

void verify_unsaturated(const Coverage& coverage, uint32_t p, uint32_t half) {
    unsigned missing = 0;
    for (uint32_t start = 0; start < p && missing < 2; start += 32) {
        const uint32_t wanted = Coverage::mask(std::min(32u, p - start));
        auto absent = ~coverage.covered(start, p, half, wanted) & wanted;
        while (absent && missing < 2) {
            if (!coverage.absent(start + std::countr_zero(absent), p, half))
                throw std::runtime_error("invalid missing-residue witness");
            ++missing;
            absent &= absent - 1;
        }
    }
    if (missing < 2) throw std::runtime_error("missing saturated prime " + std::to_string(p));
}

void verify(const Prefix& prefix, const std::string& filename) {
    const auto claims = read_catalogue(prefix, filename);
    const Coverage coverage(prefix);
    uint32_t saturated = 1, unsaturated = 0;
    uint64_t historical_classes = 0;
    for (uint32_t p = 3; p < claims.size(); p += 2) {
        if (prefix.composite[p]) continue;
        if (claims[p].present) {
            verify_saturated(coverage, p, claims[p], prefix.cutoff / 2);
            ++saturated;
            historical_classes += p - 1;
        } else {
            verify_unsaturated(coverage, p, prefix.cutoff / 2);
            ++unsaturated;
        }
    }
    std::cout << "verified_saturated=" << saturated << " verified_unsaturated=" << unsaturated
              << " historical_classes=" << historical_classes << '\n';
}
} // namespace

int main(int argc, char** argv) try {
    if (argc != 5 || (std::string_view(argv[1]) != "derive" && std::string_view(argv[1]) != "verify"))
        throw std::invalid_argument("usage: saturation_chronology {derive|verify} CUTOFF TERMS.u32 CATALOGUE.csv");
    const auto prefix = read_prefix(integer(argv[2]), argv[3]);
    if (std::string_view(argv[1]) == "derive") derive(prefix, argv[4]);
    else verify(prefix, argv[4]);
    return 0;
} catch (const std::exception& error) {
    std::cerr << "ERROR: " << error.what() << '\n';
    return 1;
}
