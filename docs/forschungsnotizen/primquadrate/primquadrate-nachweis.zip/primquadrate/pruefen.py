"""Finite checks for the research note on squares in the canonical greedy norms."""
import argparse
import csv
from fractions import Fraction
import hashlib
import json
from math import gcd, isqrt, prod
from pathlib import Path


HERE = Path(__file__).resolve().parent
RULES = {5: 4, 13: 3, 37: 30}
TOWER = ((13, 3, 3), (281, 59, 59), (120569, 67518, 79620), (91393, 37671, 45130))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def primes(n):
    sieve = bytearray(b"\x01") * (n + 1)
    sieve[:2] = b"\0\0"
    for p in range(2, isqrt(n) + 1):
        if sieve[p]:
            sieve[p*p::p] = bytes((n-p*p)//p + 1)
    return [i for i, bit in enumerate(sieve) if bit]


def elementary():
    accepted = [0]
    saturation = {}
    ps = primes(283)
    for g in range(1, 283):
        candidate = accepted + [g]
        if any(len({h % p for h in candidate}) == p for p in ps if p <= len(candidate)):
            continue
        accepted.append(g)
        for p, banned in RULES.items():
            seen = {(2*h + 1) % p for h in accepted}
            if len(seen) == p - 1:
                require(banned not in seen, "wrong forbidden class")
                saturation.setdefault(p, g)
    require(36 in accepted and saturation == {5: 8, 13: 50, 37: 282}, "wrong prefix")
    modulus = prod(RULES)
    units = [u for u in range(modulus) if gcd(u, modulus) == 1]
    def blocked(u):
        return any(u*u % p == b for p, b in RULES.items())
    hits = [u for u in units if blocked(u) and blocked(73*u)]
    require(tuple(73**2 % p for p in RULES) == (4, 12, 1), "wrong multiplier")
    require((len(hits),len(units)) == (368,1728), "wrong orbit count")
    phases = set()
    for p, b, z in TOWER:
        require(pow(z,(p-1)//2,p) == 1 and pow(z,21,p) == 1, "bad tower phase")
        phases.update(t for t in range(21) if pow(z,t,p) == b)
    require({1,2,4,8,16,11} <= phases and len(phases) == 12, "tower not covered")
    require(Fraction(16,prod(p-1 for p,_,_ in TOWER)) == Fraction(1,2313979637760),
            "tower density")
    ref = json.loads((HERE / "split-factor-witness.json").read_text())
    q = ref["prime"]
    split = [p for p in primes(q) if p % 4 == 1]
    require(len(split) == 368306 and split[-1] == q, "range of split primes")
    require(q * ref["least_multiplier"] == 2 * ref["first_offset"] + 1 == ref["first_norm"],
            "endpoint witness arithmetic")
    print("Saturations", saturation, "| classes 368/1728 = 23/108 | tower cycle verified")
    print("368306 primes counted | endpoint witness arithmetic verified")


def digest(path):
    result = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1048576), b""):
            result.update(block)
    return result.hexdigest()


def tower(terms_file):
    import numpy as np
    terms = np.memmap(terms_file, dtype="<u4", mode="r")
    rules = {q:b for q,b,_ in TOWER}
    rules.update({53: 10, 181: 9})
    for q,b in rules.items():
        seen = np.zeros(q, dtype=bool)
        for start in range(0, len(terms), 1000000):
            chunk = terms[start:start+1000000]
            seen[((2*chunk + 1) % q)] = True
        require(np.flatnonzero(~seen).tolist() == [b], f"need a longer prefix for {q} or wrong gap")
    seed = 191160287
    require(seed % 4 == 3 and all(seed % d for d in range(2,isqrt(seed)+1)), "seed not prime")
    five = (13,281,91393,53,181)
    orbit = tuple(seed*seed % q for q in five)
    seen_orbits = set()
    while orbit not in seen_orbits:
        seen_orbits.add(orbit)
        require(any(v == rules[q] for v,q in zip(orbit,five)), "unblocked square in cycle")
        orbit = tuple(v*v % q for v,q in zip(orbit,five))
    print("All four rectangle classes and the full orbit of prime 191160287 verified")


def density(terms_file, catalogue_file, small):
    import numpy as np
    ref = json.loads((HERE / "square-gap-density-500m.json").read_text())
    if not small:
        require(digest(terms_file) == ref["terms_sha256"], "wrong 500M prefix")
        require(digest(catalogue_file) == ref["catalogue_sha256"], "wrong 500M catalogue")
    terms = np.memmap(terms_file, dtype="<u4", mode="r")
    with open(catalogue_file) as stream:
        occupied = {int(row["prime"]): int(row["missing_residue"]) for row in csv.DictReader(stream)}
    active = [p for p,r in occupied.items() if p % 4 == 1 and pow((2*r+1) % p,(p-1)//2,p) == 1]
    bits = np.zeros(int(terms[-1])//2 + 1, dtype=bool)
    bits[terms//2] = True
    packed = np.packbits(bits,bitorder="little")
    del bits
    # Unpack after combining byte blocks of length p: each one spans 8p bit positions.
    saturated_count = len(active)
    lines = []
    examined = 0
    limit = 8000 if small else ref["unsaturated_split_prime_search_limit"]
    for p in primes(limit):
        if p in occupied or p % 4 != 1:
            continue
        examined += 1
        padded = np.pad(packed, (0,(-len(packed)) % p))
        folded = np.bitwise_or.reduce(padded.reshape(-1,p), axis=0)
        seen = np.unpackbits(folded, bitorder="little").reshape(8,p).any(axis=0)
        gaps = sorted(map(int, (4*np.flatnonzero(~seen) + 1) % p))
        if small:
            direct = set((2*terms+1) % p)
            require(gaps == [r for r in range(p) if r not in direct], f"folding mismatch at {p}")
        require(len(gaps) >= 2, f"incomplete catalogue at {p}")
        if all(pow(b,(p-1)//2,p) == 1 for b in gaps):
            active.append(p)
            lines.append(f"{p}:" + ",".join(map(str,gaps)))
    D = Fraction(prod(p-3 for p in active), prod(p-1 for p in active))
    if not small:
        require((saturated_count,len(lines),examined) == (40589,641,3631), "wrong counts")
        require(hashlib.sha256(("\n".join(lines)+"\n").encode()).hexdigest()
                == ref["all_gap_lists_sha256"], "wrong gap lists")
        lo, hi = map(Fraction, ref["certified_density_lower_bound_strict_interval"])
        require(lo < 1-D < hi, "wrong product")
    print("Saturated:", saturated_count, "additional:", len(lines),
          "guaranteed proportion (rounded):", float(1-D))


def first(terms_file, small):
    import numpy as np
    stream = np.memmap(terms_file, dtype="<u4", mode="r")
    bound = 8170 if small else 11170477
    if not small:
        require(int(stream[-1]) >= 832200536, "prefix ends below the last target")
    limit = int(stream[-1]) * 2 + 1
    bits = np.zeros(int(stream[-1])//2+1, dtype=bool)
    bits[stream//2] = True
    qs = np.array([q for q in primes(bound) if q % 4 == 1], dtype=np.int64)
    least = np.zeros_like(qs)
    todo = np.arange(len(qs))
    for m in range(1,182,4):
        norms = m*qs[todo]
        inside = norms <= limit
        indices = todo[inside]
        hit = bits[(norms[inside]-1)//4]
        least[indices[hit]] = m
        todo = indices[~hit]
    require((least > 0).all() and (5*least <= qs).all(), "missing multiple or square bound")
    if not small:
        require((len(qs), int(least[-1]), int(least.max())) == (368306,149,181),
                "range or largest cofactor differs")
    print("First multiples:", len(qs), "largest cofactor:", int(least.max()))


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cmd = cli.add_subparsers(dest="mode", required=True)
    cmd.add_parser("kurz")
    for name in ("potenzen","dichte","vielfache"):
        sub = cmd.add_parser(name)
        sub.add_argument("terms", type=Path)
        if name == "dichte":
            sub.add_argument("catalogue", type=Path)
        if name != "potenzen":
            sub.add_argument("--klein", action="store_true")
    args = cli.parse_args()
    if args.mode == "kurz":
        elementary()
    elif args.mode == "potenzen":
        tower(args.terms)
    elif args.mode == "dichte":
        density(args.terms,args.catalogue,args.klein)
    else:
        first(args.terms,args.klein)
