// Independent finite proof checker. No generator queue or witness updates.
// Verify full admissibility, and a chronological obstruction for every gap.
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <vector>
#include <memory>
#include <openssl/evp.h>

// Hash exactly the bytes consumed by the independent verifier, not a later
// re-opened filename. OpenSSL supplies the standard digest implementation.
class Sha256 {
    std::unique_ptr<EVP_MD_CTX, decltype(&EVP_MD_CTX_free)> ctx;
public:
    Sha256() : ctx(EVP_MD_CTX_new(), EVP_MD_CTX_free) {
        if(!ctx || EVP_DigestInit_ex(ctx.get(), EVP_sha256(), nullptr)!=1)
            throw std::runtime_error("cannot initialize SHA-256");
    }
    void update(const char* bytes, size_t length) {
        if(EVP_DigestUpdate(ctx.get(),bytes,length)!=1)
            throw std::runtime_error("SHA-256 input failure");
    }
    std::string finish() {
        unsigned char bytes[EVP_MAX_MD_SIZE]; unsigned length=0;
        if(EVP_DigestFinal_ex(ctx.get(),bytes,&length)!=1 || length!=32)
            throw std::runtime_error("SHA-256 finalization failure");
        constexpr char hex[]="0123456789abcdef";
        std::string result; result.reserve(64);
        for(unsigned i=0;i<length;++i) {
            result+=hex[bytes[i]>>4]; result+=hex[bytes[i]&15];
        }
        return result;
    }
};
static bool hashed_line(std::ifstream& input, std::string& line, Sha256& hash) {
    if(!std::getline(input,line)) return false;
    hash.update(line.data(),line.size());
    if(!input.eof()) hash.update("\n",1);
    return true;
}

static uint64_t decimal(const std::string& s) {
    if(s.empty() || s.find_first_not_of("0123456789")!=std::string::npos)
        throw std::runtime_error("invalid unsigned integer");
    return std::stoull(s);
}
static std::string quote(const std::string& s) {
    std::string out="\"";
    for(char c:s) { if(c=='\\'||c=='\"') out+='\\'; if(c=='\n') out+="\\n"; else out+=c; }
    return out+'\"';
}
static uint64_t mask(unsigned n) { return n==64 ? UINT64_MAX : (uint64_t(1)<<n)-1; }

int main(int argc,char**argv) {
    std::string result_path;
    uint64_t X=0,count=0;
    const auto start=std::chrono::steady_clock::now();
    try {
        if(argc!=6) throw std::runtime_error("usage: verify_prefix X TERMS.u32 FROZEN.csv RESULT.json MISSING.csv");
        result_path=argv[4]; X=decimal(argv[1]);
        if(X>UINT32_MAX) throw std::runtime_error("cutoff exceeds uint32 format");
        const uint64_t H=X/2;
        std::ifstream input(argv[2],std::ios::binary);
        if(!input) throw std::runtime_error("cannot read term file");
        std::vector<uint32_t> terms;
        Sha256 terms_hash, frozen_hash;
        char raw[4];
        while(input.read(raw,4)) {
            terms_hash.update(raw,4);
            const uint32_t g=uint32_t(uint8_t(raw[0]))|(uint32_t(uint8_t(raw[1]))<<8)
                |(uint32_t(uint8_t(raw[2]))<<16)|(uint32_t(uint8_t(raw[3]))<<24);
            if(g>X || g%2 || (!terms.empty() && g<=terms.back()))
                throw std::runtime_error("terms must be strictly increasing even integers within the cutoff");
            terms.push_back(g);
        }
        if(input.bad()) throw std::runtime_error("term input read failed");
        if(input.gcount()!=0) throw std::runtime_error("truncated uint32 term file");
        if(terms.empty() || terms.front()!=0) throw std::runtime_error("term list must begin at zero");
        count=terms.size();
        std::vector<uint64_t> bits((H+64)/64+1,0);
        for(uint32_t g:terms) bits[(g/2)/64]|=uint64_t(1)<<((g/2)%64);
        auto member=[&](uint64_t h) { return (bits[h/64]>>(h%64))&1; };
        auto window=[&](uint64_t h,uint64_t upto) {
            const unsigned shift=h%64;
            uint64_t value=bits[h/64]>>shift;
            if(shift) value|=bits[h/64+1]<<(64-shift);
            const uint64_t length=upto-h+1;
            if(length<64) value&=mask(unsigned(length));
            return value;
        };
        // OR adjacent groups of 64 arithmetic progressions at once. Each
        // bit remains exactly the indicator for one residue modulo p.
        auto residues=[&](uint32_t p,uint32_t first,uint64_t upto,uint64_t wanted) {
            uint64_t seen=0;
            for(uint64_t h=first;h<=upto;h+=p) {
                seen|=window(h,upto);
                if((seen&wanted)==wanted) break;
            }
            return seen;
        };
        const uint32_t limit=uint32_t(count+1);
        std::vector<bool> composite(uint64_t(limit)+1,false),used(uint64_t(limit)+1,false);
        composite[0]=true;
        if(limit>=1) composite[1]=true;
        for(uint64_t p=2;p*p<=limit;++p) if(!composite[p])
            for(uint64_t m=p*p;m<=limit;m+=p) composite[m]=true;
        std::vector<uint8_t> blocked(H+1,0);
        std::ifstream frozen(argv[3]);
        if(!frozen) throw std::runtime_error("cannot read frozen-prime file");
        std::string line;
        if(!hashed_line(frozen,line,frozen_hash) || line!="prime,forbidden_g_residue,first_rejected_g,count_before")
            throw std::runtime_error("unexpected frozen CSV header");
        std::ofstream witness(argv[5]);
        if(!witness) throw std::runtime_error("cannot write missing residue certificates");
        witness<<"prime,missing_g_residue\n2,1\n";
        uint64_t frozen_count=0,covered_residues=0,certified_primes=1;
        while(hashed_line(frozen,line,frozen_hash)) {
            if(line.empty()) continue;
            std::vector<uint64_t> fields;
            std::istringstream row(line); std::string token;
            while(std::getline(row,token,',')) fields.push_back(decimal(token));
            if(fields.size()!=4) throw std::runtime_error("invalid frozen CSV row");
            const auto p64=fields[0],b64=fields[1],reject=fields[2],prior=fields[3];
            if(p64<3 || p64>limit || composite[p64] || used[p64] || b64>=p64)
                throw std::runtime_error("invalid or repeated frozen prime");
            const uint32_t p=p64,b=b64;
            if(reject==0 || reject>X || reject%2 || reject%p!=b || member(reject/2))
                throw std::runtime_error("invalid rejection witness");
            if(uint64_t(std::lower_bound(terms.begin(),terms.end(),reject)-terms.begin())!=prior)
                throw std::runtime_error("incorrect count before rejection");
            const uint32_t r=(uint64_t(b)*((uint64_t(p)+1)/2))%p;
            for(uint64_t h=r;h<=H;h+=p) if(member(h))
                throw std::runtime_error("frozen forbidden residue contains an accepted term");
            const uint64_t upto=reject/2-1;
            for(uint32_t first=0;first<p;first+=64) {
                uint64_t wanted=mask(std::min<uint32_t>(64,p-first));
                if(r>=first && r<uint64_t(first)+64) wanted&=~(uint64_t(1)<<(r-first));
                if((residues(p,first,upto,wanted)&wanted)!=wanted)
                    throw std::runtime_error("rejection occurs before all other residues were occupied");
            }
            for(uint64_t h=reject/2;h<=H;h+=p) blocked[h]=1;
            used[p]=true; ++frozen_count; ++certified_primes; covered_residues+=p-1;
            witness<<p<<','<<b<<'\n';
        }
        if(frozen.bad()) throw std::runtime_error("frozen input read failed");
        uint64_t omissions=0;
        for(uint64_t h=0;h<=H;++h) if(!member(h)) {
            ++omissions;
            if(!blocked[h]) throw std::runtime_error("omitted even integer has no verified earlier obstruction: "+std::to_string(2*h));
        }
        // One absent residue for every other relevant prime certifies every
        // accepted prefix; primes above count cannot possibly be covered.
        uint64_t deferred=0;
        for(uint32_t p=3;p<=limit;p+=2) if(!composite[p] && !used[p]) {
            bool found=false;
            for(uint32_t first=0;first<p;first+=64) {
                const uint64_t wanted=mask(std::min<uint32_t>(64,p-first));
                const uint64_t absent=wanted&~residues(p,first,H,wanted);
                if(absent) {
                    const uint32_t r=first+__builtin_ctzll(absent);
                    witness<<p<<','<<(uint64_t(2)*r)%p<<'\n';
                    found=true; ++deferred; ++certified_primes; break;
                }
            }
            if(!found) throw std::runtime_error("accepted set covers every residue modulo "+std::to_string(p));
        }
        witness.close();
        if(!witness) throw std::runtime_error("missing certificate write failed");
        const double seconds=std::chrono::duration<double>(std::chrono::steady_clock::now()-start).count();
        const std::string terms_digest=terms_hash.finish(), frozen_digest=frozen_hash.finish();
        std::ofstream result(result_path);
        result<<"{\"valid\":true,\"cutoff\":"<<X<<",\"count\":"<<count
            <<",\"last\":"<<terms.back()<<",\"frozen_primes_verified\":"<<frozen_count
            <<",\"historical_occupied_residues_verified\":"<<covered_residues
            <<",\"deferred_primes_verified\":"<<deferred
            <<",\"total_missing_residue_certificates\":"<<certified_primes
            <<",\"omitted_even_candidates_verified\":"<<omissions
            <<",\"terms_sha256\":\""<<terms_digest<<"\",\"frozen_sha256\":\""<<frozen_digest<<"\""
            <<",\"seconds\":"<<seconds
            <<",\"method\":\"independent arithmetic-progression certificates; full admissibility plus chronological rejection witnesses; no generator queue logic\"}\n";
        result.close(); if(!result) throw std::runtime_error("JSON result write failed");
        std::cerr<<"VERIFIED count="<<count<<" cutoff="<<X<<" seconds="<<seconds<<'\n';
        return 0;
    } catch(const std::exception& e) {
        if(!result_path.empty()) {
            std::ofstream result(result_path);
            result<<"{\"valid\":false,\"cutoff\":"<<X<<",\"count\":"<<count<<",\"error\":"<<quote(e.what())<<"}\n";
        }
        std::cerr<<"INVALID: "<<e.what()<<'\n'; return 1;
    }
}
