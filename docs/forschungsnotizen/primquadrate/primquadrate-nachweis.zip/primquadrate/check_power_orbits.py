#!/usr/bin/env python3
"""Certify successive square exclusions using the authenticated 500M rule catalogue."""
import argparse
import csv
import hashlib
import io
import json
import math
from collections import Counter
from fractions import Fraction
from pathlib import Path

HASH = "846d4b50b31de2079b835f7c68c0c2e7434132028d1756cf737808ebc17bb02e"
PERIODIC = (13, 281, 91393, 53, 181, 120569, 983557, 29017)
RECTANGLE = ((13, 3), (281, 59), (120569, 79620), (91393, 45130))
BASELINE, PERIOD = 7, 12
PRECISION = 10**40


def load_rules(path):
    data = path.read_bytes()
    if hashlib.sha256(data).hexdigest() != HASH:
        raise ValueError("unexpected catalogue digest")
    return {int(row["prime"]): (2*int(row["missing_residue"])+1) % int(row["prime"])
            for row in csv.DictReader(io.StringIO(data.decode()))}


def v2(n):
    return (n & -n).bit_length()-1


def cycle_length(q, b, limit):
    u = b
    for r in range(1, limit+1):
        u = u*u % q
        if u == b:
            return r
    return limit+1


def profiles(q, b, size, period):
    """Count square residues by the exact stages at which they hit b."""
    h = (q-1)//2
    v = v2(h)
    r = cycle_length(q, b, period)
    assert period % r == 0 and pow(b, h >> v, q) == 1
    masks = Counter()
    for phase in range(r):
        for delay in range(v+1):
            mask = sum(1 << n for n in range(phase, size, r) if n >= delay)
            masks[mask] += 1 if delay == 0 else 2**(delay-1)
    masks[0] += h-sum(masks.values())
    assert min(masks.values()) >= 0
    return masks


def cyclic_counts(primes, rules):
    delay = max(v2((q-1)//2) for q in primes)
    period = math.lcm(*(cycle_length(q, rules[q], PERIOD) for q in primes))
    size = delay+period
    full = (1 << size)-1
    joint = {0: 1}
    for q in primes:
        updated = Counter()
        local = profiles(q, rules[q], size, period)
        for mask, n in joint.items():
            for hit, count in local.items():
                updated[mask | hit] += n*count
        joint = updated
    denominator = math.prod((q-1)//2 for q in primes)
    assert sum(joint.values()) == denominator
    # Once past delay, the final complete period suffices forever.
    missing = {full ^ mask: count for mask, count in joint.items()
               if mask >> delay == full >> delay}
    return missing, denominator


def supplemented_density(missing, denominator, rules):
    """Cover finite gaps with the unused rules; enclose the CRT products by integers."""
    coeff = Counter()
    for mask, n in missing.items():
        sub = mask
        while True:
            coeff[sub] += (-1)**sub.bit_count()*n
            if sub == 0:
                break
            sub = (sub-1) & mask
    stages = {s: tuple(n for n in range(s.bit_length()) if s >> n & 1)
              for s in coeff if s}
    products = {s: (PRECISION, PRECISION) for s in stages}
    used = 0
    for q, b in rules.items():
        if q % 4 != 1 or q in PERIODIC or not b:
            continue
        h = (q-1)//2
        if pow(b, h, q) != 1:
            continue
        used += 1
        r = cycle_length(q, b, BASELINE-1)
        hit = []
        for n in range(BASELINE):
            k = math.gcd(1 << n, h)
            hit.append(k if pow(b, h//k, q) == 1 else 0)
        for sub, ns in stages.items():
            # In the same cyclic phase the last event contains its predecessors.
            # Different phases have disjoint events. r=BASELINE makes all distinct.
            latest = {n % r: n for n in ns}
            avoid = h-sum(hit[n] for n in latest.values())
            if avoid != h:
                lo, hi = products[sub]
                products[sub] = lo*avoid//h, (hi*avoid+h-1)//h
    assert used == 40581
    lo = hi = coeff[0]*PRECISION
    for sub, (low, high) in products.items():
        weight = coeff[sub]
        lo += weight*(low if weight >= 0 else high)
        hi += weight*(high if weight >= 0 else low)
    scale = 10**24
    lower = lo*scale//(denominator*PRECISION)
    upper = (hi*scale+denominator*PRECISION-1)//(denominator*PRECISION)
    assert upper == lower+1
    return [f"{x//scale}.{x%scale:024d}" for x in (lower, upper)]


def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, math.isqrt(n)+1))


def record(path):
    rules = load_rules(path)
    exponent_residues = [t for t in range(21)
                         if any(pow(root, t, q) == rules[q] for q, root in RECTANGLE)]
    assert exponent_residues == [1, 2, 4, 7, 8, 9, 10, 11, 13, 15, 16, 19]
    assert {pow(2,n,21) for n in range(6)} <= set(exponent_residues)
    cyclic_units = {t for t in range(21) if math.gcd(t,21)==1 and t%7 in (1,2,4)}
    assert cyclic_units == {pow(2,n,21) for n in range(6)}
    assert sum(math.gcd(t,21)==1 for t in exponent_residues) == 9
    assert all(pow(root,21,q) == 1 and pow(root,(q-1)//2,q)==1 for q,root in RECTANGLE)
    rectangle_prime = 64068746789051
    assert (rectangle_prime % 4 == 3 and is_prime(rectangle_prime) and
            all(rectangle_prime**2 % q == z for q,z in RECTANGLE))
    p = 191160287
    assert is_prime(p) and p % 4 == 3
    demo = {}
    for q in PERIODIC[:5]:
        u = p*p % q
        stages = []
        for n in range(BASELINE+PERIOD):
            if u == rules[q]:
                stages.append(n)
            u = u*u % q
        assert pow(p,2**(BASELINE+1),q) == u
        demo[q] = stages
    assert set().union(*map(set,demo.values())) == set(range(BASELINE+PERIOD))
    five, d5 = cyclic_counts(PERIODIC[:5], rules)
    eight, d8 = cyclic_counts(PERIODIC, rules)
    assert max(eight).bit_length() <= BASELINE
    return {
        "catalogue_sha256": HASH,
        "four_rule_rectangle": {"input_square_residues": RECTANGLE,
            "inert_prime_density": str(Fraction(1,math.prod((q-1)//2 for q,_ in RECTANGLE))),
            "half_exponent_residues_mod_21": exponent_residues, "prime_example": rectangle_prime},
        "eight_cyclic_rules": [(q, rules[q], cycle_length(q,rules[q],PERIOD)) for q in PERIODIC],
        "density_exclusion_from_stage_zero_five_rules": str(Fraction(five[0],d5)),
        "density_exclusion_from_stage_zero_eight_rules": str(Fraction(eight[0],d8)),
        "density_exclusion_from_stage_seven_eight_rules": str(Fraction(sum(eight.values()),d8)),
        "density_from_stage_zero_with_finite_supplement_interval": supplemented_density(eight,d8,rules),
        "five_rule_example": {"prime": p, "hit_stages_0_through_18": demo},
    }


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("catalogue", type=Path)
    cli.add_argument("--check", type=Path)
    args = cli.parse_args()
    result = json.dumps(record(args.catalogue), indent=2)
    if args.check and json.loads(args.check.read_text()) != json.loads(result):
        raise ValueError("result differs from reference")
    print(result)
