# How growth of the offset count constrains saturation

Let G be OEIS A135311, let C(X) count its terms up to X including zero, and let T(p) be the first accepted offset at which p−1 residues modulo p are occupied. Put T(p)=∞ if this never happens. The two sample counts in the note establish finite values of C(X). A separate argument in the project gives the following implication for its possible growth:

$$
\limsup_{X\to\infty}\frac{C(X)\log X}{X}>0
\quad\Longrightarrow\quad
\sum_{p:\,T(p)=\infty}\frac{1}{p}<\infty.
$$

To see this, take z=X^(1/20). At each prime p≤z select one residue absent from the prefix through X. Select a second one whenever T(p)>X. At p=2 only one residue is selected. Write ν(p) for the number selected, one or two. The elements of G through X must avoid the selected classes. For a squarefree d supported on these primes, the Chinese remainder theorem gives ν(d)=∏ν(p) residue classes that hit a selected class at every p dividing d. Their count in [0,X] is (⌊X⌋+1)ν(d)/d + O(ν(d)).

Apply the fundamental lemma of sieve theory with dimension at most two and D=X^(1/2). The dimension bound follows from ν(p)≤2 and Mertens' product estimate (absorb p=2 into the constant). The sum of the remainder bounds up to D is O(D log(2D)), since ν(d)≤τ(d). At z=D^(1/10) the upper bound therefore gives, with an absolute implied constant,

$$
C(X)\ll X\prod_{p\le z}\left(1-\frac{\nu(p)}p\right)
\ll \frac X{\log X}
\prod_{p\le z:\,T(p)>X}\left(1-\frac1{p-1}\right).
$$

Here the extra factor is the ratio of the local factors with two omissions and one. If the limsup is positive, take a sequence of X tending to infinity along which the left-hand normalized count is bounded below. The product on the right is then bounded away from zero along that sequence. Every prime that never saturates contributes an extra factor whenever it is ≤z. Taking logarithms and using −log(1−t)≥t bounds the increasing partial sums of their reciprocals. This proves the implication. It gives no asymptotic value for C(X) and does not force saturation at any specified prime.

Reference: D. Koukoulopoulos, *The Distribution of Prime Numbers*, Theorem 18.11. [Author's text](https://dms.umontreal.ca/~koukoulo/documents/publications/primes.pdf)
