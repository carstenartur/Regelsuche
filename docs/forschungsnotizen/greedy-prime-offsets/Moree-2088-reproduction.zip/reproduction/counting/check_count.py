#!/usr/bin/env python3
"""Cross-check an independently verified Greedy count and the actual terms file."""
import argparse
import hashlib
import json
from pathlib import Path


def check(report_path, terms_path):
    reference_path = Path(__file__).with_name("count-reference.json")
    expected = {row["cutoff"]: row for row in json.loads(reference_path.read_text(encoding="utf-8"))["checks"]}
    report = json.loads(report_path.read_text(encoding="utf-8"))
    row = expected.get(report.get("cutoff"))
    if report.get("valid") is not True or row is None:
        raise ValueError("unknown cutoff or unsuccessful independent verifier")
    for key in ("count", "last", "terms_sha256"):
        if row[key] != report.get(key):
            raise ValueError(f"different {key} in the verifier report")
    if terms_path.stat().st_size != row["bytes"] or row["bytes"] != 4 * row["count"]:
        raise ValueError("different terms file size")
    digest = hashlib.sha256()
    with terms_path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    if digest.hexdigest() != row["terms_sha256"]:
        raise ValueError("different terms file contents")
    print(f"Verified C({row['cutoff']}) = {row['count']} including zero; "
          f"{row['positive_count']} positive offsets; last offset {row['last']}.")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("verified_json", type=Path)
    cli.add_argument("terms_u32", type=Path)
    args = cli.parse_args()
    try:
        check(args.verified_json, args.terms_u32)
    except (OSError, ValueError) as exc:
        cli.exit(1, f"{cli.prog}: {exc}\n")
