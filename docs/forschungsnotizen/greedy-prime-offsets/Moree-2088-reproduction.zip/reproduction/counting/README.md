# Two exact counts of the greedy prime offsets

Let $C(X)$ count the terms of OEIS A135311 at most $X$, including its initial zero. The second count column gives the convention that includes positive offsets only.

| Upper bound $X$ | $C(X)$ | Positive offsets | Largest offset |
|---:|---:|---:|---:|
| 1,000,000 | 76,064 | 76,063 | 999,990 |
| 500,000,000 | 25,148,955 | 25,148,954 | 499,999,980 |

The term stream through 500 million occupies 100,595,820 bytes. Its SHA-256 digest is `fe5556cc601182c5e08d4df58750a35e380b34194339416fd5ed1bf7801661f5`. Both hashes and the integer encoding are specified in `count-reference.json`. The two observations are finite and do not determine an asymptotic for $C(X)$.

## Reproduce a count

The attachment contains the original C++ generator and independent verifier, with no source changes. The generator writes the accepted offsets and the residue classes responsible for rejections. The verifier independently checks admissibility of the accepted set and earlier witnesses for every omitted even candidate. Its algorithm uses arithmetic progressions. Building it requires OpenSSL development headers and libcrypto. The comparison step uses only the Python 3 standard library.

Run the following commands from the directory containing this README. The small example normally takes a few seconds including compilation.

~~~sh
mkdir -p work
c++ -O3 -std=c++20 -Wall -Wextra -Werror generator.cpp -o work/generator
c++ -O3 -std=c++20 -Wall -Wextra -Werror verify_prefix.cpp -lcrypto -o work/verify_prefix
work/generator 1000000 work/g-1m
work/verify_prefix 1000000 work/g-1m.u32 work/g-1m-frozen.csv work/verified-1m.json work/missing-1m.csv
python3 check_count.py work/verified-1m.json work/g-1m.u32
~~~

To repeat the full count on a machine with sufficient memory, run the same two programs with the larger cutoff. The standard distribution omits the generated files. The optional full run writes more than 100 MB of terms and certificates and takes substantially longer.

~~~sh
work/generator 500000000 work/g-500m
work/verify_prefix 500000000 work/g-500m.u32 work/g-500m-frozen.csv work/verified-500m.json work/missing-500m.csv
python3 check_count.py work/verified-500m.json work/g-500m.u32
~~~
