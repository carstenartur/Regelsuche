# Prime divisors of 2g + 1 for the canonical greedy offsets

Let G be A135311 starting at zero. For every odd prime p < 2,300,003 the following finite classification holds: p divides some 2g + 1 with g in G if and only if p is 1 modulo 4. The table concerns 84,832 primes in the class 3 modulo 4 and 84,678 primes in the class 1 modulo 4.

The file `factor-witnesses.csv.gz` has one row `prime,witness_offset` per prime, in increasing order.

- For p = 3 modulo 4, the offset is the first accepted g for which the prefix occupies p−1 distinct residues modulo p. The unique missing residue is (p−1)/2. Every later term must avoid it by admissibility. Consequently p never divides any accepted norm 2g + 1.
- For p = 1 modulo 4, the offset is the first accepted g for which p divides 2g + 1. For every listed p this witness satisfies 2g + 1 ≤ p²/5.
- Every saturation witness in the first case satisfies 2g + 1 < p². The latest such offset is 839,638,976. The latest positive divisibility witness is 158,498,702.

## Quick table and arithmetic checks

Run the following in this directory. Python 3.8 or later with its standard library is sufficient for the quick check.

~~~sh
python3 check_support.py
~~~

It regenerates the complete prime list, compares every table row, checks the square deadlines and verifies divisibility of each positive witness. Establishing that a witness really is a term of the greedy sequence, or the first saturation, also requires checking against the canonical sequence, as in the next section.

The checker also verifies the following implication. If every prime 3 modulo 4 below 2,300,003 is excluded as a norm factor, any first composite norm with such a factor up through 2,300,003 × 2,300,087 must be a product of exactly two unprotected primes 3 modulo 4. This follows because all norms are 1 modulo 4 and the endpoint is below twice the square of 2,300,003. The checker enumerates the five possible products. For the first four, the offset (product−1)/2 hits a known permanently missing class at 5, 2,333, 5 and 1,801, respectively. The missing classes at those primes are checked in the small replay below. Thus every accepted g ≤ 2,645,103,500,129 has only prime factors 1 modulo 4 in 2g + 1. The next offset is the first left open by this proof. Its membership in G is unresolved here.

## Direct replay for a small prefix

Start with the million-offset calculation in `../counting/README.md`. Use a C++20 compiler. Run the following in the directory containing this README.

~~~sh
mkdir -p work
c++ -std=c++20 -O3 -Wall -Wextra -Werror saturation_chronology.cpp -o work/saturation
work/saturation derive 1000000 ../counting/work/g-1m.u32 work/catalogue-1m.csv
work/saturation verify 1000000 ../counting/work/g-1m.u32 work/catalogue-1m.csv
python3 check_support.py --small --terms ../counting/work/g-1m.u32 --catalogue work/catalogue-1m.csv
~~~

The two native commands independently derive and check the times when only one residue remains. The Python comparison reproduces every saturation or first divisor witness for all 1,024 odd primes below 8,171, including 515 primes 3 modulo 4 and 509 primes 1 modulo 4. This range and all three small blocking primes were reproduced from the million-offset stream when preparing this attachment.

## Optional complete sequential replay

The following alternative recomputes a complete canonical prefix through the last needed saturation. It uses the generator and independent canonical-prefix verifier built in `../counting/`, and the chronology program built above. It operates entirely from the source included with the attachment. This large route requires a workstation and substantial time, memory and disk space.

~~~sh
../counting/work/generator 839638976 work/g-full
../counting/work/verify_prefix 839638976 work/g-full.u32 work/g-full-frozen.csv work/verified-full.json work/missing-full.csv
work/saturation derive 839638976 work/g-full.u32 work/catalogue-full.csv
work/saturation verify 839638976 work/g-full.u32 work/catalogue-full.csv
python3 check_support.py --terms work/g-full.u32 --catalogue work/catalogue-full.csv
~~~

The reported project result used the pre-existing independently verified prefix through 500,000,000 together with chronological decisions beyond it. In preparing the attachment we checked the SHA-256 digests of the source prefix, its saturation catalogue and the 7,700-row search record. We then reconstructed *all* positive first witnesses directly from the sorted 500-million prefix, and matched negative witnesses to its audited catalogue, the 7,697 later saturations and the three last individually audited cases. The optional full sequential replay to 839,638,976 was not repeated for this attachment.

The `reports` directory contains copies of the project’s machine-readable reports from revision `409f835d51d9ebca83e661525a4dc7c3dc4f1943`, originally under `docs/research/greedy-counting/validation/`. The project’s expositions are `factor-support-law.md`, `three-remaining-factors.md` and `split-factor-support.md` in the parent research directory. The reports record the input hashes, search ranges and final exceptional cases.
