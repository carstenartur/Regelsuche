#!/usr/bin/env python3
"""Check the mod-four factor classification for the canonical greedy offsets."""
import argparse
from array import array
from bisect import bisect_left
import csv
import gzip
import json
from math import isqrt
from pathlib import Path
import sys

FIRST_UNCLASSIFIED = 2_300_003
SMALL_LIMIT = 8171
ROOT = Path(__file__).resolve().parent


def require(condition, message):
    if not condition:
        raise ValueError(message)


def primes_up_to(limit):
    sieve = bytearray([1]) * (limit + 1)
    sieve[:2] = b'\0\0'
    for p in range(2, isqrt(limit) + 1):
        if sieve[p]:
            sieve[p*p::p] = bytes((limit-p*p)//p+1)
    return [p for p in range(3, limit+1, 2) if sieve[p]]


def read_terms(path):
    terms = array('I')
    require(terms.itemsize == 4, 'requires a four-byte unsigned int')
    byte_count = path.stat().st_size
    require(byte_count > 0 and byte_count % 4 == 0, 'invalid term stream')
    with path.open('rb') as f:
        terms.fromfile(f, byte_count//4)
    if sys.byteorder != 'little':
        terms.byteswap()
    require(terms[0] == 0, 'missing initial zero')
    return terms


def read_catalogue(path):
    with path.open() as f:
        return {int(row['prime']): (int(row['missing_residue']), int(row['saturation_g']))
                for row in csv.DictReader(f)}


def first_multiple(terms, p):
    # If p*m=2*g+1, both p and m are 1 modulo 4 for a split prime.
    last_multiplier = min(p//5, (2*terms[-1]+1)//p)
    for m in range(1, last_multiplier + 1, 4):
        g = (m*p - 1)//2
        pos = bisect_left(terms, g)
        if pos < len(terms) and terms[pos] == g:
            return g
    raise ValueError(f'no timely factor witness for {p}')


def frontier_proof():
    # Assume all inert primes below FIRST_UNCLASSIFIED are already excluded.
    # Norms are 1 mod 4, so the number of inert factors, with multiplicity, is even.
    # Below twice the square of the smallest possible one, only a pair can occur.
    first = FIRST_UNCLASSIFIED
    end = first * 2_300_087
    require(end < 2*first**2, 'unexpected norm range')
    possible = [p for p in primes_up_to(end//first) if p >= first and p % 4 == 3]
    # Each rule is independently witnessed by the one-million-offset check.
    rules = {5:4, 1801:515, 2333:2082}
    pairs = []
    for i,p in enumerate(possible):
        for q in possible[i:]:
            if p*q > end:
                break
            g = (p*q-1)//2
            hits = [r for r,a in rules.items() if g % r == a]
            pairs.append((p*q, hits))
    pairs.sort()
    require(len(pairs) == 5 and pairs[-1] == (end, []) and
            all(hits for _, hits in pairs[:-1]), 'pair scan differs')
    return rules


def verify(limit, terms, catalogue):
    with gzip.open(ROOT/'factor-witnesses.csv.gz','rt',encoding='ascii') as stream:
        rows = list(csv.reader(stream))
    require(rows.pop(0) == ['prime', 'witness_offset'], 'wrong evidence header')
    primes = primes_up_to(FIRST_UNCLASSIFIED-1)
    require([int(row[0]) for row in rows] == primes, 'incomplete list of primes')
    inert = split = 0
    for p, (_, raw) in zip(primes, rows):
        g = int(raw)
        require(g >= 0 and g % 2 == 0 and 2*g+1 < p*p, f'invalid deadline at {p}')
        if p % 4 == 1:
            require((2*g+1) % p == 0 and 5*(2*g+1) <= p*p, f'invalid cofactor at {p}')
        if p >= limit:
            continue
        if p % 4 == 3:
            inert += 1
            if catalogue is not None:
                require(catalogue.get(p) == ((p-1)//2, g), f'half-class or date differs at {p}')
        else:
            split += 1
            if terms is not None:
                require(first_multiple(terms, p) == g, f'first norm witness differs at {p}')
    rules = frontier_proof()
    if catalogue is not None:
        require(all(p in catalogue and catalogue[p][0] == a for p,a in rules.items()),
                'pair obstruction differs from the observed saturated classes')
    return {'prime_bound_exclusive':limit, 'inert_primes':inert, 'split_primes':split,
            'last_offset_from_pair_check_if_full_classification_holds':(2_300_003*2_300_087-1)//2-1,
            'compared_source_for_primes_below_requested_bound':terms is not None}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--terms', type=Path, help='certified increasing little-endian unsigned 32-bit words')
    parser.add_argument('--catalogue', type=Path, help='chronology CSV, produced by saturation_chronology')
    parser.add_argument('--small',action='store_true',help='compare primes < 8171 instead of < 2300003')
    args = parser.parse_args()
    if (args.terms is None) != (args.catalogue is None):
        parser.error('provide --terms and --catalogue together')
    print(json.dumps(verify(SMALL_LIMIT if args.small else FIRST_UNCLASSIFIED,
                            read_terms(args.terms) if args.terms else None,
                            read_catalogue(args.catalogue) if args.catalogue else None),indent=2))
