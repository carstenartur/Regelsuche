#!/usr/bin/env python3
"""Exclude every remaining wheel representative below 10**273 for Moree's tuple.

Place this file beside verify_moree_2088.py. Uses the Python standard library.
"""
import argparse
from bisect import bisect_left
import json
from math import prod
from pathlib import Path

from verify_moree_2088 import SIZE, crt, greedy_prefix, local_conditions, primes_through, require, small_exclusions


POWER = 273


def allowed_indices(offsets, primes, a, modulus):
    """For t = a + modulus*k, return the allowed k residues at each new prime."""
    conditions = []
    for p in primes:
        if modulus % p == 0:
            continue
        missing = set(range(p)).difference(g % p for g in offsets)
        inverse = pow(modulus, -1, p)
        residues = sorted(((-pow(r, -1, p) - a) * inverse) % p for r in missing)
        conditions.append((p, residues))
    return conditions


def project_and_split(conditions):
    period = prod(p for p, _ in conditions)
    halves = [[], []]
    sizes = [1, 1]
    for p, residues in sorted(conditions, key=lambda row: (len(row[1]), row[0]), reverse=True):
        part = period // p
        projector = part * pow(part, -1, p)
        side = 0 if sizes[0] <= sizes[1] else 1
        halves[side].append([r * projector % period for r in residues])
        sizes[side] *= len(residues)
    if sizes[0] > sizes[1]:
        halves.reverse()
        sizes.reverse()
    return period, halves, sizes


def sums(components, period):
    """Generate one modular sum per tuple; the order is irrelevant."""
    if not components:
        yield 0
        return
    last = components[-1]
    for prefix in sums(components[:-1], period):
        for term in last:
            value = prefix + term
            yield value - period if value >= period else value


def short_residues(conditions, limit):
    """Enumerate every k in [0, limit) satisfying the given congruences."""
    period, halves, _ = project_and_split(conditions)
    require(0 <= limit <= period, "the requested interval exceeds one wheel period")
    if not limit:
        return
    table = sorted(sums(halves[0], period))
    for x in sums(halves[1], period):
        start = period - x if x else 0
        end = start + limit
        i = bisect_left(table, start)
        while i < len(table) and table[i] < end:
            yield table[i] - start
            i += 1
        if end > period:
            i = 0
            stop = end - period
            while i < len(table) and table[i] < stop:
                yield period - start + table[i]
                i += 1


def test_intervals():
    conditions = [(3, [0, 1]), (5, [1, 3, 4]), (7, [2, 4])]
    period = prod(p for p, _ in conditions)
    for limit in range(period + 1):
        direct = [k for k in range(limit) if all(k % p in rs for p, rs in conditions)]
        require(sorted(short_residues(conditions, limit)) == direct, "short-interval CRT check failed")


def calculate():
    primes = primes_through(SIZE + 1)
    offsets = greedy_prefix(SIZE, primes)
    fixed = local_conditions(offsets, primes)
    small_exclusions(offsets, primes, fixed[-1][0])
    a, modulus = crt(fixed)
    conditions = allowed_indices(offsets, primes, a, modulus)
    wheel = [(p, rs) for p, rs in conditions if len(rs) <= 6]
    require(len(wheel) == 24, "unexpected set of primes with at most six missing classes")
    period, _, sizes = project_and_split(wheel)
    # k<limit is equivalent to a+modulus*k<10**POWER for k>=0.
    limit = (10**POWER - a + modulus - 1)//modulus
    per_prime = dict(conditions)
    # Filter in a fixed order. Keep the one survivor of these first four
    # tests as an independent witness that their own lower bound is sharp.
    filter_primes = (631, 659, 719, 683)
    ok0, ok1, ok2, ok3 = (frozenset(per_prime[p]) for p in filter_primes)
    excluded = [0, 0, 0, 0]
    checkpoint_limit = (10**272 - a + modulus - 1)//modulus
    checkpoint_count = 0
    count = 0
    least = limit
    survivors = []
    for k in short_residues(wheel, limit):
        count += 1
        if k < checkpoint_limit:
            checkpoint_count += 1
        least = min(least, k)
        if k % 631 not in ok0:
            excluded[0] += 1
        elif k % 659 not in ok1:
            excluded[1] += 1
        elif k % 719 not in ok2:
            excluded[2] += 1
        elif k % 683 not in ok3:
            excluded[3] += 1
        else:
            survivors.append(k)
    require(len(survivors) == 1 and count == sum(excluded) + 1, "unexpected survivors")
    last = a + modulus*survivors[0]
    require(last >= 10**272, "unexpected survivor below the previous checkpoint")
    obstruction = 1 + 938*last
    require(938 in offsets and 673 in primes and obstruction % 673 == 0 and obstruction > 673,
            "the final composite witness is invalid")
    return {
        "prime_parameter_excluded_below_power_of_ten": POWER,
        "period_in_index_k": str(period),
        "index_limit_exclusive": str(limit),
        "wheel_primes": [p for p, _ in wheel],
        "classes_in_full_period": prod(sizes),
        "half_list_sizes": sizes,
        "wheel_candidates_below_threshold": count,
        "checkpoint_power_of_ten": 272,
        "checkpoint_wheel_candidates": checkpoint_count,
        "checkpoint_survivors_after_four_filters": 0,
        "smallest_wheel_index": str(least),
        "smallest_wheel_parameter": str(a + modulus*least),
        "first_failing_prime_counts": [[p, n] for p, n in zip(filter_primes, excluded)],
        "sole_survivor_of_first_four_filters": str(last),
        "final_witness": {"offset": 938, "proper_prime_divisor": 673},
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", type=Path)
    args = parser.parse_args()
    test_intervals()
    result = calculate()
    if args.check is not None:
        require(result == json.loads(args.check.read_text(encoding="utf-8")), "certificate mismatch")
        print(f"Verified every candidate less than 10**{POWER}.")
    else:
        print(json.dumps(result, indent=2))
