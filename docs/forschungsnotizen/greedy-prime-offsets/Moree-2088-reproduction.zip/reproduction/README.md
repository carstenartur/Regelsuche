# Which primes divide twice a greedy offset plus one?

Companion to the note of 28 November 2026. For the application to Ford, Luca and Moree the input is indices 1 through 2,089 of [OEIS A135311](https://oeis.org/A135311), including zero. Both verifiers of the interval calculation generate their own offsets. The main calculations work offline with Python 3.8 or newer and its standard library. Extract the archive, open the reproduction directory and run the commands in the directory containing this file.

## Contributions and review status

Carsten Hammer initiated the project. Generative AI contributed substantially to the mathematical investigation, the arguments, the verification code and the writing. OpenAI Codex prepared this public edition. Independent peer review is pending.

## Start with the factor law

The [factor-law supplement](factor-support/README.md) contains one witness for each of the 169,510 odd primes below 2,300,003, the original verification summaries, and a full, independent replay recipe. Its short table check validates the arithmetic of every row. Its small direct replay verifies the classification against the canonical sequence for all odd primes below 8,171. Its longer replay reconstructs the full prefix needed to check every witness. Run the quick table check from the archive root:

~~~sh
python3 factor-support/check_support.py
~~~

The [sieve argument for the counting function](counting/saturation-and-growth.md) proves the conditional implication stated on page 2 of the note.

## The transfer to the 2,088-offset prefix

~~~sh
python3 verify_project_bridge.py --check project_bridge_certificate.json
~~~

This identifies the 48 single missing half-classes, checks the resulting 104-digit bound and small-prime exceptions, and computes exactly which weights remain modulo 3. It also checks the two permissible residues for the parameter modulo 467 and the offset that subsequently fills one gap.

## The fixed tuple and the weighted filter

~~~sh
python3 verify_moree_2088.py --check moree_2088_certificate.json
python3 verify_languasco_sieve.py --check languasco_sieve_certificate.json --residues retained.txt
~~~

The first command recomputes both reciprocal sums, all 97 primes with a unique missing residue, their exact CRT modulus and representative, and small-prime witnesses. To compare every input row with a locally saved [OEIS b-file](https://oeis.org/A135311/b135311.txt), append `--oeis-file b135311.txt`.

The second command verifies all class counts for the threshold 6/5 and checks the parameter values printed in Languasco’s Tables 2–5. It writes the 15,594 retained classes modulo 510,510 to `retained.txt`, one integer per line. For a prime q > 17, look up q modulo 510,510. If its class is absent, v(q) ≤ 6/5. A present class requires further testing. This reduces the number of classes to examine. No runtime speedup is claimed.

## Verify the 274-digit bound twice

~~~sh
python3 verify_moree_interval.py --check moree_interval_certificate.json
python3 verify_moree_independent.py moree_interval_certificate.json
~~~

The first command uses CRT projectors and a search in a cyclic interval. The second program is self-contained. It marks the forbidden residues directly from the linear forms, merges two groups of congruences separately and enumerates the short interval using the quotient in k = u + Uj. Either command can take about a minute on a modern workstation. Allow several hundred megabytes of memory. The independent verifier also accepts `--oeis-file b135311.txt`.

In the full interval, each implementation obtains 70,011,044 candidates after the first 121 constraints. Four further primes eliminate all but one. The certificate stores that last candidate as a decimal integer. Its offset 938 has the proper factor 673. Both calculations also verify that there are 7,002,012 candidates in the preceding interval below 10^272 and that the four additional primes eliminate them all.

## Counting the offsets

The optional [counting supplement](counting/README.md) gives the source, instructions and reference digests for C(1,000,000) and C(500,000,000), with zero included. This is a separate, larger computation. Building its generator and verifier requires a C++20 compiler and OpenSSL development libraries. Neither is needed for the Python checks above.

## Files and references

- `Moree-2088-note.html` is an offline, printable edition of the four-page note.
- The JSON certificate files contain exact residues, counters, witnesses or hashes relevant to their respective checks. All large parameters in the interval certificate are decimal strings to preserve precision in JSON readers.

The reference numbers match the accompanying paper.

[1] R. Michael Perry, *A Number Sequence Relating to the Closepacking of Primes*, University of Colorado technical report CU-CS-253-83 (July 1983). Figure 2 and its discussion describe the forbidden residues. [Report](https://oeis.org/A274260/a274260.pdf)

[2] Kevin Ford, Florian Luca and Pieter Moree, *Values of the Euler φ-function not divisible by a given odd prime, and the distribution of Euler–Kronecker constants for cyclotomic fields*, Mathematics of Computation 83 (2014), 1447–1476. Proposition 4 concerns all 2,088 positive offsets. [DOI](https://doi.org/10.1090/S0025-5718-2013-02749-4) · [Proposition 4 in the preprint](https://arxiv.org/pdf/1108.3805#page=8)

[3] Alessandro Languasco, *Efficient computation of the Euler–Kronecker constants of prime cyclotomic fields*, Research in Number Theory 7 (2021), article 2, published online 25 December 2020. Section 4.5, equation (28), defines the score. The following paragraph points to the list of primes with a score above 1.2. [DOI](https://doi.org/10.1007/s40993-020-00213-1) · [Published article, page 14](https://d-nb.info/1226072259/34#page=14)

[4] OEIS Foundation, [A135311, Greedy sequence of prime offsets](https://oeis.org/A135311).
