#!/usr/bin/env python3
"""Independently cross-check the short-interval certificate for Moree's tuple.

With no OEIS b-file supplied, generate the offsets directly. This verifier uses
no project imports. Work with two separately merged CRT systems, then intersect
ordinary quotient intervals. Python 3.8 or newer, standard library only.
"""
import argparse
from bisect import bisect_left, bisect_right
import json
from math import isqrt, prod
from pathlib import Path


def require(cond, reason):
    if not cond:
        raise ValueError(reason)


def prime(p):
    return p >= 2 and all(p % d for d in range(2, isqrt(p) + 1))


def direct_offsets(primes):
    selected = []
    seen = {p: set() for p in primes}
    candidate = 0
    while len(selected) < 2089:
        if all(len(rs) < p-1 or candidate % p in rs for p, rs in seen.items()):
            selected.append(candidate)
            for p, rs in seen.items():
                rs.add(candidate % p)
        candidate += 1
    return selected


def compare_oeis(path, offsets):
    index = 0
    with path.open(encoding="utf-8") as stream:
        for line in stream:
            items = line.partition("#")[0].split()
            if items:
                require(tuple(map(int, items)) == (index + 1, offsets[index]), "OEIS row differs")
                index += 1
                if index == len(offsets):
                    return
    raise ValueError("OEIS file ended prematurely")


def residues(conditions):
    """Ordinary incremental CRT, generating representatives in [0, product)."""
    if not conditions:
        yield 0
        return
    p, choices = conditions[-1]
    previous = conditions[:-1]
    modulus = prod(q for q, _ in previous)
    inverse = pow(modulus, -1, p)
    for v in residues(previous):
        for r in choices:
            yield v + modulus * ((r-v)*inverse % p)


def candidates(wheel, K):
    """Write k=u+U*j. Use the second CRT projection to bound j directly."""
    halves, sizes = [[], []], [1, 1]
    for p, choices in sorted(wheel, key=lambda item: (-len(item[1]), item[0])):
        side = int(sizes[0] > sizes[1])
        halves[side].append((p, choices))
        sizes[side] *= len(choices)
    if sizes[0] < sizes[1]:
        halves.reverse()
    left, right = halves
    U = prod(p for p, _ in left)
    V = prod(p for p, _ in right)
    require(0 <= K <= U*V, "invalid quotient interval")
    inverse = pow(U, -1, V)
    table = sorted(v*inverse % V for v in residues(right))
    for u in residues(left):
        if u >= K:
            continue
        jmax = (K-1-u)//U
        start = u*inverse % V
        stop = start + jmax
        for i in range(bisect_left(table, start), bisect_right(table, min(stop, V-1))):
            yield u + U*(table[i]-start)
        if stop >= V:
            for i in range(bisect_right(table, stop-V)):
                yield u + U*(V + table[i]-start)


def verify(certificate, oeis_file):
    for K in range(106):
        example = [(3, [0, 2]), (5, [3]), (7, [1, 3, 4, 5])]
        direct = [k for k in range(K) if all(k % p in s for p, s in example)]
        require(sorted(candidates(example, K)) == direct, "small quotient check differs")

    primes = [n for n in range(2, 2091) if prime(n)]
    g = direct_offsets(primes)
    require(g[-1] == 18932, "unexpected last offset")
    if oeis_file:
        compare_oeis(oeis_file, g)

    # Mark t=0 and all t for which some nonconstant form is divisible by p.
    allowed_t = {}
    for p in primes:
        forbidden = {0} | {-pow(x, -1, p) % p for x in {b % p for b in g} if x}
        allowed_t[p] = set(range(p)) - forbidden
    fixed = [(p, list(s)) for p, s in allowed_t.items() if len(s) == 1]
    a = next(residues(fixed))
    M = prod(p for p, _ in fixed)
    require(len(fixed) == 97 and a > max(primes), "invalid base progression")
    for t in primes:
        if t <= max(p for p, _ in fixed):
            require(any(not prime(1+b*t) for b in g[1:]), "small admissible prime parameter")
    by_prime = {p: [k for k in range(p) if (a+M*k) % p in rs]
                for p, rs in allowed_t.items() if len(rs) > 1}
    wheel = [(p, rs) for p, rs in by_prime.items() if len(rs) <= 6]
    ps = (631, 659, 719, 683)
    mask0, mask1, mask2, mask3 = (set(by_prime[p]) for p in ps)
    counts = [0, 0, 0, 0]
    lo = (10**272-a+M-1)//M
    hi = (10**273-a+M-1)//M
    early, total, least, survivors = 0, 0, hi, []
    for k in candidates(wheel, hi):
        total += 1
        if k < lo:
            early += 1
        if k < least:
            least = k
        if k % 631 not in mask0:
            counts[0] += 1
        elif k % 659 not in mask1:
            counts[1] += 1
        elif k % 719 not in mask2:
            counts[2] += 1
        elif k % 683 not in mask3:
            counts[3] += 1
        else:
            survivors.append(a+M*k)

    require(early == certificate["checkpoint_wheel_candidates"], "checkpoint count differs")
    require(total == certificate["wheel_candidates_below_threshold"], "interval count differs")
    require(str(least) == certificate["smallest_wheel_index"], "first wheel index differs")
    require(str(a+M*least) == certificate["smallest_wheel_parameter"], "first parameter differs")
    require([list(row) for row in zip(ps, counts)] == certificate["first_failing_prime_counts"],
            "factor buckets differ")
    require(survivors == [int(certificate["sole_survivor_of_first_four_filters"])],
            "surviving parameters differ")
    require(survivors[0] >= 10**272 and 938 in g and (1+938*survivors[0]) % 673 == 0,
            "final witness invalid")


if __name__ == "__main__":
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument("certificate", type=Path)
    cli.add_argument("--oeis-file", type=Path)
    args = cli.parse_args()
    verify(json.loads(args.certificate.read_text(encoding="utf-8")), args.oeis_file)
    print("Independent quotient-interval check passed.")
