#!/usr/bin/env python3
"""Reproduce the simultaneous-primality obstruction for Moree's 2,088 offsets.

Uses only the Python standard library (Python 3.8+). With no arguments, print
the certificate as JSON. With --check, reproduce and compare the certificate.
An optional --oeis-file is a local copy of the OEIS A135311 b-file.
"""

import argparse
from fractions import Fraction
import hashlib
import itertools
import json
from math import floor, gcd, isqrt, prod
from pathlib import Path


POSITIVE_COUNT = 2088
SIZE = POSITIVE_COUNT + 1  # Include the defining first offset 0.


def require(condition, message):
    if not condition:
        raise ValueError(message)


def primes_through(limit):
    prime = bytearray([1]) * (limit + 1)
    prime[:2] = bytes(2)
    for p in range(2, isqrt(limit) + 1):
        if prime[p]:
            prime[p*p::p] = bytes((limit - p*p) // p + 1)
    return [p for p in range(2, limit + 1) if prime[p]]


def greedy_prefix(size, primes):
    """A proposal is forbidden iff it fills the last gap at a saturated prime."""
    offsets = []
    seen = {p: bytearray(p) for p in primes}
    gaps = {p: p for p in primes}
    forbidden = {}
    for g in itertools.count():
        if any(g % p == r for p, r in forbidden.items()):
            continue
        offsets.append(g)
        if len(offsets) == size:
            return offsets
        for p, mask in seen.items():
            r = g % p
            if not mask[r]:
                mask[r] = 1
                gaps[p] -= 1
                if gaps[p] == 1:
                    forbidden[p] = mask.index(0)


def check_oeis(path, offsets):
    """Compare the first required index/value rows. Later rows are immaterial."""
    index = 0
    with path.open(encoding="utf-8") as stream:
        for line_number, line in enumerate(stream, 1):
            data = line.partition("#")[0].split()
            if not data:
                continue
            require(len(data) == 2, f"invalid OEIS record on line {line_number}")
            i, value = map(int, data)
            require((i, value) == (index + 1, offsets[index]),
                    f"OEIS mismatch on line {line_number}, expected {index+1} {offsets[index]}")
            index += 1
            if index == len(offsets):
                return
    raise ValueError(f"OEIS file ended after {index} records, need {len(offsets)}")


def local_conditions(offsets, primes):
    """Reconstruct the projections directly from the completed prefix."""
    conditions = []
    for p in primes:
        missing = set(range(p)).difference(g % p for g in offsets)
        require(missing, f"prefix covers all residues modulo {p}")
        if len(missing) == 1:
            r = missing.pop()
            require(r != 0, "the prefix includes zero")
            # If t > p is prime, the forbidden offset residue is -1/t.
            conditions.append((p, r, (-pow(r, -1, p)) % p))
    return conditions


def crt(conditions):
    """Compare successive merging with the direct idempotent form of CRT."""
    residue, modulus = 0, 1
    for p, _, a in conditions:
        require(gcd(modulus, p) == 1, "moduli must be pairwise coprime")
        residue += modulus * ((a - residue) * pow(modulus, -1, p) % p)
        modulus *= p
    direct = 0
    for p, _, a in conditions:
        other = modulus // p
        direct += a * other * pow(other, -1, p)
    require(0 < residue < modulus and direct % modulus == residue,
            "the two CRT computations disagree")
    return residue, modulus


def small_exclusions(offsets, primes, bound):
    """For each possible small prime t give g,d with 1<d<1+gt and d | 1+gt."""
    witnesses = []
    for t in (p for p in primes if p <= bound):
        for g in offsets[1:]:
            n = 1 + g*t
            factor = next((d for d in range(2, isqrt(n) + 1) if n % d == 0), None)
            if factor is not None:
                witnesses.append([t, g, factor])
                break
        else:
            raise ValueError(f"the small prime {t} survives")
    return witnesses


def make_certificate(offsets, primes):
    rows = local_conditions(offsets, primes)
    residue, modulus = crt(rows)
    inert = [(p, r, a) for p, r, a in rows if p % 4 == 3]
    require(all(2*r + 1 == p and a == 2 for p, r, a in inert),
            "the half-residue condition fails")
    inert_product = prod(p for p, _, _ in inert)
    require(crt(inert) == (2, inert_product), "inert CRT does not give 2")
    witnesses = small_exclusions(offsets, primes, rows[-1][0])
    total = sum(Fraction(1, g) for g in offsets[1:])
    previous = total - Fraction(1, offsets[-1])
    require(previous < 2 < total, "the reciprocal sum does not first cross 2 at this prefix")
    # For a positive rational s, floor(10^12 s) certifies a decimal interval
    # with integer endpoints after scaling. The threshold comparison above is exact.
    scale = 10**12
    normalized = "".join(f"{i} {g}\n" for i, g in enumerate(offsets, 1)).encode("ascii")
    return {
        "sequence": "OEIS A135311",
        "positive_offsets": len(offsets) - 1,
        "first_offset": offsets[0],
        "last_offset": offsets[-1],
        "offset_rows_encoding": "ASCII; one-based index, one space, decimal offset, LF, including offset 0",
        "offset_rows_sha256": hashlib.sha256(normalized).hexdigest(),
        "reciprocal_sum_floors": {
            "scale": scale,
            "before_last": floor(previous * scale),
            "with_last": floor(total * scale),
        },
        "condition_columns": ["prime", "unique_missing_offset_residue", "necessary_parameter_residue"],
        "conditions": [list(row) for row in rows],
        "inert_prime_count": len(inert),
        "inert_modulus": str(inert_product),
        "inert_first_representative_above_two": str(inert_product + 2),
        "inert_first_parameter_digits": len(str(inert_product + 2)),
        "saturated_prime_count": len(rows),
        "full_modulus": str(modulus),
        "full_least_positive_representative": str(residue),
        "full_first_parameter_digits": len(str(residue)),
        "small_exclusion_columns": ["prime_parameter", "positive_offset", "proper_divisor_of_one_plus_product"],
        "small_exclusions": witnesses,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--oeis-file", type=Path, help="compare the first 2,089 rows with a local b-file")
    parser.add_argument("--check", type=Path, help="compare the computation with this reference JSON")
    args = parser.parse_args()
    try:
        # At most SIZE residues occur. A saturated prime satisfies p-1 <= SIZE.
        primes = primes_through(SIZE + 1)
        offsets = greedy_prefix(SIZE, primes)
        if args.oeis_file:
            check_oeis(args.oeis_file, offsets)
        certificate = make_certificate(offsets, primes)
        if args.check:
            expected = json.loads(args.check.read_text(encoding="utf-8"))
            require(expected == certificate, "reference certificate differs")
            print(f"Verified {certificate['positive_offsets']:,} positive offsets, "
                  f"{certificate['saturated_prime_count']} saturated primes and a "
                  f"{certificate['full_first_parameter_digits']}-digit lower bound.")
        else:
            print(json.dumps(certificate, indent=2))
    except (ValueError, OSError) as exc:
        parser.exit(1, f"{parser.prog}: {exc}\n")


if __name__ == "__main__":
    main()
