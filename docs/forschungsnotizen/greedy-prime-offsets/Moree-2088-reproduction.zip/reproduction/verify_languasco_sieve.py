#!/usr/bin/env python3
"""Certify a residue-class presieve for v(q)>6/5, for primes q>17.

Run alongside verify_moree_2088.py (stdlib, Python 3.8+).
With no arguments, print the certificate. --check FILE compares a saved JSON.
--residues FILE also writes the usable classes modulo 510510, one per line.
"""
import argparse
from fractions import Fraction
import hashlib
import json
from math import gcd
from pathlib import Path

from verify_moree_2088 import SIZE, greedy_prefix, primes_through, require


SCALE = 10**10
THRESHOLD = 6 * SCALE // 5
PRIMES = (2, 3, 5, 7, 11, 13, 17)
REPORT_MODULI = (210, 30030, 510510)
# A. Languasco, Res. Number Theory 7 (2021), art. 2, Eq. (28), Tables 2–5.
TABLE_2 = tuple(q for q in primes_through(300) if q > 2)
TABLE_3 = (1009, 2003, 3001, 4001, 5003, 6007, 7001, 8009, 9001, 10007, 20011, 30011)
TABLE_4 = (10007, 20011, 30011, 40009, 42611, 50021, 60013, 70001, 80021,
           90001, 100003, 305741, 1000003, 4178771, 6766811, 10000019,
           28227761, 75743411)
TABLE_5 = (193894451, 212634221, 251160191, 538906601, 964477901, 1139803271,
           1217434451, 1806830951, 2488788101, 2830676081, 2918643191,
           7079770931, 9109334831, 9854964401)


def admissible_classes(offsets):
    """Recursively split classes a mod W; the allowable weight can only fall."""
    results = {m: set() for m in REPORT_MODULI}
    weights = {b: SCALE // b for b in offsets}

    def extend(a, modulus, depth, eligible, parent_lower):
        p = PRIMES[depth]
        new_modulus = modulus * p
        # If b ≡ 0 mod p it never blocks q. Use slot zero for those b:
        # only local parameter residues 1,...,p-1 are visited below.
        blocks = [0] + [(-pow(r, -1, p)) % p for r in range(1, p)]
        lost_weight = [0] * p
        lost_count = [0] * p
        for b in eligible:
            slot = blocks[b % p]
            lost_weight[slot] += weights[b]
            lost_count[slot] += 1
        for child in range(a, new_modulus, modulus):
            r = child % p
            if r == 0:
                continue
            lower = parent_lower - lost_weight[r]
            count = len(eligible) - lost_count[r]
            # lower/SCALE <= U(child) <= (lower+count)/SCALE.
            if lower + count <= THRESHOLD:
                continue
            require(lower > THRESHOLD, f"rounding interval straddles 6/5 for {child} mod {new_modulus}")
            if new_modulus in results:
                results[new_modulus].add(child)
            if depth + 1 < len(PRIMES):
                kept = [b for b in eligible if blocks[b % p] != r]
                extend(child, new_modulus, depth + 1, kept, lower)

    extend(0, 1, 0, offsets, sum(weights.values()))
    return results


def is_prime(n):
    """Seven prime Miller-Rabin bases are deterministic below Jaeschke's bound."""
    require(2 <= n < 341550071728321, "primality test outside its proven range")
    for p in PRIMES:
        if n % p == 0:
            return n == p
    odd, twos = n - 1, 0
    while odd % 2 == 0:
        odd //= 2
        twos += 1
    for p in PRIMES:
        x = pow(p, odd, n)
        if x in (1, n - 1):
            continue
        for _ in range(twos - 1):
            x = x * x % n
            if x == n - 1:
                break
        else:
            return False
    return True


def residue_lines(residues):
    return ''.join(f'{a}\n' for a in sorted(residues)).encode('ascii')


def certificate(offsets, results):
    # Independent, direct verification of every class of the smallest wheel.
    direct = {a for a in range(210) if gcd(a, 210) == 1 and
              sum(Fraction(1, b) for b in offsets if gcd(1 + a*b, 210) == 1) > Fraction(6, 5)}
    require(direct == results[210], 'exact rational enumeration modulo 210 disagrees')
    wheels = []
    for modulus, survivors in results.items():
        units = sum(gcd(a, modulus) == 1 for a in range(modulus))
        wheels.append({'modulus': modulus, 'unit_classes': units, 'retained': len(survivors),
                       'excluded': units - len(survivors),
                       'retained_lines_sha256': hashlib.sha256(residue_lines(survivors)).hexdigest()})
    checked, small = [], []
    table_of = {q: table for table, parameters in enumerate((TABLE_2, TABLE_3, TABLE_4, TABLE_5), 2)
                for q in parameters}
    for q, table in sorted(table_of.items()):
        require(is_prime(q), f'composite table parameter {q}')
        v = sum(Fraction(1, b) for b in offsets if is_prime(1 + b*q))
        if v <= Fraction(6, 5):
            continue
        row = {'table': table, 'q': q, 'v_times_10m_floor': int(v * 10**7)}
        if q <= PRIMES[-1]:
            small.append(row)
        else:
            require(all(q % m in rows for m, rows in results.items()), f'false exclusion at {q}')
            row['class_mod_510510'] = q % 510510
            checked.append(row)
    return {'threshold': '6/5 (strict)', 'domain': 'prime q > 17', 'weights_scale': SCALE,
            'offset_source': 'A135311, one-based entries 2 to 2089 inclusive',
            'class_digest_encoding': 'sorted decimal residue, one per line, ASCII, LF',
            'wheels': wheels, 'retained_classes_mod_210': sorted(direct),
            'source_of_parameters': 'Languasco, doi:10.1007/s40993-020-00213-1, Tables 2-5',
            'distinct_odd_prime_parameters_tested_in_tables_2_to_5': len(table_of),
            'direct_small_odd_parameters_with_v_above_threshold': small,
            'table_parameters_in_sieve_domain_with_v_above_threshold': checked}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check', type=Path, help='recompute and compare with this JSON')
    parser.add_argument('--residues', type=Path, help='write classes mod 510510, sorted ASCII with LF')
    args = parser.parse_args()
    offsets = greedy_prefix(SIZE, primes_through(SIZE + 1))[1:]
    results = admissible_classes(offsets)
    output = certificate(offsets, results)
    if args.check:
        require(output == json.loads(args.check.read_text(encoding='utf-8')), 'certificate differs')
        print('Verified all three wheels and all parameters in Tables 2 to 5.')
    else:
        print(json.dumps(output, indent=2))
    if args.residues:
        args.residues.write_bytes(residue_lines(results[510510]))


if __name__ == '__main__':
    main()
