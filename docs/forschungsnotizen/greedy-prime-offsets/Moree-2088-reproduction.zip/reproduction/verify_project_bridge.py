#!/usr/bin/env python3
"""Check the transfer of the half-residue observation to the two FLM score bounds."""
import argparse
from fractions import Fraction
import json
from math import gcd, prod
from pathlib import Path

from verify_moree_2088 import SIZE, greedy_prefix, primes_through


def certificate():
    primes = primes_through(SIZE + 1)
    offsets = greedy_prefix(SIZE, primes)
    positive = offsets[1:]
    singleton = {}
    for p in primes:
        missing = set(range(p)).difference(b % p for b in offsets)
        if len(missing) == 1:
            singleton[p] = missing.pop()
    half = [p for p, r in singleton.items() if p > 2 and 2*r == p-1]
    if half != [p for p in singleton if p % 4 == 3]:
        raise ValueError("half residue and inert prime classes differ in the prefix")
    modulus = prod(half)
    if any((-pow(singleton[p], -1, p) - 2) % p for p in half):
        raise ValueError("a transferred congruence differs")
    # The local argument assumes q>p. First use only 3,7,11,19 for q>19.
    # Then q=2 mod 4389, so every such q is already above the largest p in half.
    bootstrap = [3, 7, 11, 19]
    if not set(bootstrap).issubset(half) or prod(bootstrap) + 2 <= max(half):
        raise ValueError("small-prime bootstrap does not reach the full modulus set")
    small_witnesses = [(2, 12, 5), (3, 8, 5), (5, 18, 7), (7, 2, 3),
                       (11, 12, 7), (13, 2, 3), (17, 2, 5), (19, 2, 3)]
    if [q for q, b, d in small_witnesses] != primes_through(max(bootstrap)):
        raise ValueError("incomplete list of small prime parameters")
    for q, b, d in small_witnesses:
        value = 1 + b*q
        if b not in positive or value % d or not 1 < d < value:
            raise ValueError("invalid small-parameter witness")
    # At 467 the FLM prefix has two gaps. Reproduce when the second gap
    # disappears, rather than using the eventual forbidden class retroactively.
    gaps_467 = set(range(467)).difference(b % 467 for b in offsets)
    later = greedy_prefix(2395, primes_through(2396))
    if later[:SIZE] != offsets or gaps_467 != {37, 233}:
        raise ValueError("unexpected residue history at 467")
    first_fill = next(b for b in later[SIZE:] if b % 467 in gaps_467)
    if first_fill != 21986 or first_fill % 467 != 37:
        raise ValueError("unexpected first later occupation at 467")
    threshold = Fraction(6, 5)
    retained_231 = []
    full_231 = []
    for a in range(231):
        if gcd(a, 231) != 1:
            continue
        eligible = [b for b in positive if gcd(1 + a*b, 231) == 1]
        score = sum(Fraction(1, b) for b in eligible)
        if score > threshold:
            retained_231.append(a)
        if len(eligible) == len(positive):
            full_231.append(a)
    eligible_1_mod_3 = [b for b in positive if (1+b) % 3]
    if eligible_1_mod_3 != [b for b in positive if b % 3 == 0]:
        raise ValueError("unexpected eligible offset for q congruent to 1 modulo 3")
    upper = sum(Fraction(1, b) for b in eligible_1_mod_3)
    return {
        "saturated_prime_count": len(singleton),
        "half_class_primes": half,
        "p467_prefix_gaps": sorted(gaps_467),
        "p467_prefix_parameter_classes": sorted(-pow(r, -1, 467) % 467 for r in gaps_467),
        "p467_next_gap_filling_offset": first_fill,
        "half_class_modulus": str(modulus),
        "first_representative_above_2": str(modulus + 2),
        "bootstrap_primes": bootstrap,
        "bootstrap_modulus": prod(bootstrap),
        "small_exclusion_columns": ["prime_q", "offset_b", "proper_divisor_of_1_plus_bq"],
        "small_exclusions": [list(row) for row in small_witnesses],
        "decimal_digits": len(str(modulus + 2)),
        "eligible_offsets_for_q_1_mod_3": len(eligible_1_mod_3),
        "upper_weight_for_q_1_mod_3_floor_times_10_to_12": int(upper*10**12),
        "unit_classes_mod_231": sum(gcd(a, 231) == 1 for a in range(231)),
        "classes_mod_231_with_upper_weight_above_6_over_5": retained_231,
        "classes_mod_231_preserving_all_offsets": full_231,
    }


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--check", type=Path, help="recompute and compare with this JSON")
    args = parser.parse_args()
    result = certificate()
    if args.check:
        if result != json.loads(args.check.read_text(encoding="utf-8")):
            parser.exit(1, "Certificate mismatch.\n")
        print("Verified the half-class transfer and both weighted examples.")
    else:
        print(json.dumps(result, indent=2))
