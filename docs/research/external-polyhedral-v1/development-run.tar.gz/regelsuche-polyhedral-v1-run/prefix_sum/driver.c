#include <stdio.h>
#include <stdlib.h>
void prefix_sum(long,long*,long*);
int main(int argc,char**argv){if(argc!=3)return 2;long n=strtol(argv[1],0,10),s=strtol(argv[2],0,10);if(n<2||n>20||s<0||s>2)return 3;if(sizeof(long)!=8)return 4;long x[20],y[20]={0};for(long i=0;i<n;i++)x[i]=(i*17+s*7)%19-9;prefix_sum(n-1,x,y);for(long i=0;i<n;i++)printf("%ld\n",y[i]);return 0;}
