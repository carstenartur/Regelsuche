// This code was auto-generated with AlphaZ.

#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Macros
#define ceild(n,d) ((int)ceil(((double)(n))/((double)(d))))
#define floord(n,d) ((int)floor(((double)(n))/((double)(d))))
#define div(a,b) (ceild((a),(b)))
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define mallocCheck(v,s) if ((v) == NULL) { printf("Failed to allocate memory for variable: %s\n", (s)); exit(-1); }

// Global Variables
static long N;
static long* X;
static long** Y;
static char* _flag_Y;

// Memory Macros
#define X(k) X[k]
#define Y(i,j) Y[i][j]
#define _flag_Y(i,j) _flag_Y[((-1 - N + i == 0 && N >= 0 && 1 + 3*N - 2*j >= 0 && -3 + j >= 0) ? (((((-4 + 7 * N + 3 * N*N) + 4 * j) - 2 * floord(1 + N, 2)))/4) : (-1 + i >= 0 && N - i >= 0 && -1 - N + i + j >= 0 && 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((-4 * N + 5 * i + 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : ((-N + i + j == 0 && -1 + i >= 0 && N - i >= 0) || (-2 + j == 0 && -1 - N + i == 0 && -1 + N >= 0)) ? ((((i + 3 * i*i) - 2 * floord(i, 2)))/4) : (-2 - N + i >= 0 && -1 + 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? ((((((2 * N - 6 * N*N) + (-1 + 12 * N) * i - 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : (2*N - 2*i + j == 0 && -2 - N + i >= 0 && 2*N - i >= 0) ? (((((-6 * N - 6 * N*N) + (7 + 12 * N) * i - 3 * i*i) - 2 * floord(i, 2)))/4) : 0)]

// Function Declarations
static long reduce0(long N, long ip, long jp);
static long eval_Y(long i, long j);
void example_3d_max(long _local_N, long* _local_X, long** _local_Y);

static long reduce0(long N, long ip, long jp) {
	long reduceVar;
	long k;
	
	reduceVar = LONG_MIN;
	#define RP0(i,j,k) X(((k)))
	#define R0(i,j,k) reduceVar = max(reduceVar, RP0((i),(j),(k)))
	for (k = 0; k <= min(min(-N + ip + jp, 2 * N - 2 * ip + jp), 2 * N + ip - 2 * jp); k += 1) {
		R0(ip, jp, k);
	}
	#undef RP0
	#undef R0
	return reduceVar;
}

static long eval_Y(long i, long j) {
	
	// Check the flags.
	if ((_flag_Y(i,j)) == ('N')) {
		_flag_Y(i,j) = 'I';
		Y(i,j) = reduce0(N,i,j);
		_flag_Y(i,j) = 'F';
	}
	else if ((_flag_Y(i,j)) == ('I')) {
		printf("There is a self dependence on Y at (%ld,%ld)\n",i,j);
		exit(-1);
	}
	
	return Y(i,j);
}

void example_3d_max(long _local_N, long* _local_X, long** _local_Y) {
	long i;
	long j;
	
	// Copy arguments to the global variables.
	N = _local_N;
	X = _local_X;
	Y = _local_Y;
	
	// Check parameter validity.
	if (!((-1 + N) >= (0))) {
		printf("The value of the parameters are invalid.\n");
		exit(-1);
	}
	
	// Allocate memory for local storage.
	
	// Allocate and initialize flag variables.
	_flag_Y = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (((2 + 3 * N + 3 * N*N))/2) : 0))));
	mallocCheck(_flag_Y,"_flag_Y");
	memset(_flag_Y,'N',((-1 + N >= 0) ? (((2 + 3 * N + 3 * N*N))/2) : 0));
	
	// Evaluate all non fractal reduction outputs.
	#define S0(i,j) eval_Y(i,j)
	for (i = 0; i <= 2 * N; i += 1) {
		for (j = max(-2 * N + 2 * i, N - i); j <= N + i / 2; j += 1) {
			S0(i, j);
		}
	}
	#undef S0
	
	// Free all allocated memory.
	free(_flag_Y);
}


// Undefine the Memory and Function Macros
#undef X
#undef Y
#undef _flag_Y
#undef ceild
#undef floord
#undef div
#undef max
#undef min
#undef mallocCheck
