// This code was auto-generated with AlphaZ.

#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Macros
#define ceild(n,d) ((int)ceil(((double)(n))/((double)(d))))
#define floord(n,d) ((int)floor(((double)(n))/((double)(d))))
#define div(a,b) (ceild((a),(b)))
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define mallocCheck(v,s) if ((v) == NULL) { printf("Failed to allocate memory for variable: %s\n", (s)); exit(-1); }

// Global Variables
static long N;
static long* X;
static long** Y;
static long* Y_NR;
static long* Y_NR2;
static long* Y_NR_pos;
static long* Y_NR2_pos;
static char* _flag_Y;
static char* _flag_Y_NR;
static char* _flag_Y_NR2;
static char* _flag_Y_NR_pos;
static char* _flag_Y_NR2_pos;

// Memory Macros
#define X(k) X[k]
#define Y(i,j) Y[i][j]
#define Y_NR(i,j) Y_NR[((-1 - N + i >= 0 && -1 + 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((((N - 9 * N*N) + (-1 + 12 * N) * i - 3 * i*i) + 4 * j) + 2 * floord(N, 2)) - 2 * floord(i, 2)))/4) : (2*N - 2*i + j == 0 && -1 - N + i >= 0 && 2*N - i >= 0) ? ((((((-7 * N - 9 * N*N) + (7 + 12 * N) * i - 3 * i*i) + 2 * floord(N, 2)) - 2 * floord(i, 2)))/4) : (-N + i == 0 && 3*N - 2*j >= 0 && -1 + j >= 0) ? (((2 * N - 2 * i) + j)) : 0)]
#define Y_NR2(i,j) Y_NR2[((-1 + i >= 0 && -1 + N - i >= 0 && -1 - N + i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((-4 * N + 5 * i + 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : (-N + i + j == 0 && -1 + i >= 0 && -1 + N - i >= 0) ? ((((i + 3 * i*i) - 2 * floord(i, 2)))/4) : 0)]
#define Y_NR_pos(i0,i1) Y_NR_pos[((-1 - N + i0 >= 0 && -1 + 2*N - 2*i0 + i1 >= 0 && i0 - i1 >= 0) ? (((((N - 3 * N*N) + (-1 + 4 * N) * i0 - i0*i0) + 2 * i1))/2) : (2*N - 2*i0 + i1 == 0 && -1 - N + i0 >= 0 && 2*N - i0 >= 0) ? ((((-3 * N - 3 * N*N) + (3 + 4 * N) * i0 - i0*i0))/2) : (-N + i0 == 0 && N - i1 >= 0 && -1 + i1 >= 0) ? (((2 * N - 2 * i0) + i1)) : 0)]
#define Y_NR2_pos(i0,i1) Y_NR2_pos[((-1 + i0 >= 0 && -1 + N - i0 >= 0 && -1 - N + i0 + i1 >= 0 && N - i1 >= 0) ? ((((-2 * N + 3 * i0 + i0*i0) + 2 * i1))/2) : (-N + i0 + i1 == 0 && -1 + i0 >= 0 && -1 + N - i0 >= 0) ? (((i0 + i0*i0))/2) : 0)]
#define _flag_Y(i,j) _flag_Y[((-1 - N + i == 0 && N >= 0 && 1 + 3*N - 2*j >= 0 && -3 + j >= 0) ? (((((-4 + 7 * N + 3 * N*N) + 4 * j) - 2 * floord(1 + N, 2)))/4) : (-1 + i >= 0 && N - i >= 0 && -1 - N + i + j >= 0 && 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((-4 * N + 5 * i + 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : ((-N + i + j == 0 && -1 + i >= 0 && N - i >= 0) || (-2 + j == 0 && -1 - N + i == 0 && -1 + N >= 0)) ? ((((i + 3 * i*i) - 2 * floord(i, 2)))/4) : (-2 - N + i >= 0 && -1 + 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? ((((((2 * N - 6 * N*N) + (-1 + 12 * N) * i - 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : (2*N - 2*i + j == 0 && -2 - N + i >= 0 && 2*N - i >= 0) ? (((((-6 * N - 6 * N*N) + (7 + 12 * N) * i - 3 * i*i) - 2 * floord(i, 2)))/4) : 0)]
#define _flag_Y_NR(i,j) _flag_Y_NR[((-1 - N + i >= 0 && -1 + 2*N - 2*i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((((N - 9 * N*N) + (-1 + 12 * N) * i - 3 * i*i) + 4 * j) + 2 * floord(N, 2)) - 2 * floord(i, 2)))/4) : (2*N - 2*i + j == 0 && -1 - N + i >= 0 && 2*N - i >= 0) ? ((((((-7 * N - 9 * N*N) + (7 + 12 * N) * i - 3 * i*i) + 2 * floord(N, 2)) - 2 * floord(i, 2)))/4) : (-N + i == 0 && 3*N - 2*j >= 0 && -1 + j >= 0) ? (((2 * N - 2 * i) + j)) : 0)]
#define _flag_Y_NR2(i,j) _flag_Y_NR2[((-1 + i >= 0 && -1 + N - i >= 0 && -1 - N + i + j >= 0 && 2*N + i - 2*j >= 0) ? (((((-4 * N + 5 * i + 3 * i*i) + 4 * j) - 2 * floord(i, 2)))/4) : (-N + i + j == 0 && -1 + i >= 0 && -1 + N - i >= 0) ? ((((i + 3 * i*i) - 2 * floord(i, 2)))/4) : 0)]
#define _flag_Y_NR_pos(i0,i1) _flag_Y_NR_pos[((-1 - N + i0 >= 0 && -1 + 2*N - 2*i0 + i1 >= 0 && i0 - i1 >= 0) ? (((((N - 3 * N*N) + (-1 + 4 * N) * i0 - i0*i0) + 2 * i1))/2) : (2*N - 2*i0 + i1 == 0 && -1 - N + i0 >= 0 && 2*N - i0 >= 0) ? ((((-3 * N - 3 * N*N) + (3 + 4 * N) * i0 - i0*i0))/2) : (-N + i0 == 0 && N - i1 >= 0 && -1 + i1 >= 0) ? (((2 * N - 2 * i0) + i1)) : 0)]
#define _flag_Y_NR2_pos(i0,i1) _flag_Y_NR2_pos[((-1 + i0 >= 0 && -1 + N - i0 >= 0 && -1 - N + i0 + i1 >= 0 && N - i1 >= 0) ? ((((-2 * N + 3 * i0 + i0*i0) + 2 * i1))/2) : (-N + i0 + i1 == 0 && -1 + i0 >= 0 && -1 + N - i0 >= 0) ? (((i0 + i0*i0))/2) : 0)]

// Function Declarations
static long eval_Y(long i, long j);
static long eval_Y_NR(long i, long j);
static long eval_Y_NR2(long i, long j);
static long reduce0(long N, long i0p, long i1p);
static long eval_Y_NR_pos(long i0, long i1);
static long reduce1(long N, long i0p, long i1p);
static long eval_Y_NR2_pos(long i0, long i1);
void example_3d_max(long _local_N, long* _local_X, long** _local_Y);

static long eval_Y(long i, long j) {
	
	// Check the flags.
	if ((_flag_Y(i,j)) == ('N')) {
		_flag_Y(i,j) = 'I';
		Y(i,j) = (((((-1 + N) >= (0)) && ((-N + i) >= (0))) && ((2*N - 2*i + j) >= (0))) && ((2*N + i - 2*j) >= (0))) ? (eval_Y_NR(i,j)) : (eval_Y_NR2(i,j));
		_flag_Y(i,j) = 'F';
	}
	else if ((_flag_Y(i,j)) == ('I')) {
		printf("There is a self dependence on Y at (%ld,%ld)\n",i,j);
		exit(-1);
	}
	
	return Y(i,j);
}

static long eval_Y_NR(long i, long j) {
	
	// Check the flags.
	if ((_flag_Y_NR(i,j)) == ('N')) {
		_flag_Y_NR(i,j) = 'I';
		Y_NR(i,j) = ((((((-1 + N) >= (0)) && ((-N + i) >= (0))) && ((2*N - 2*i + j) >= (0))) && ((2 - 2*N + 2*i - j) >= (0))) && ((i - j) >= (0))) ? (eval_Y_NR_pos(i,j)) : (((((-N + i) >= (0)) && ((-1 - i + j) >= (0))) && ((2*N + i - 2*j) >= (0))) ? (eval_Y_NR((2 + (i)),(1 + (j)))) : (max(eval_Y_NR_pos(i,j), eval_Y_NR((2 + (i)),(1 + (j))))));
		_flag_Y_NR(i,j) = 'F';
	}
	else if ((_flag_Y_NR(i,j)) == ('I')) {
		printf("There is a self dependence on Y_NR at (%ld,%ld)\n",i,j);
		exit(-1);
	}
	
	return Y_NR(i,j);
}

static long eval_Y_NR2(long i, long j) {
	
	// Check the flags.
	if ((_flag_Y_NR2(i,j)) == ('N')) {
		_flag_Y_NR2(i,j) = 'I';
		Y_NR2(i,j) = (((((-1 + N - i) >= (0)) && ((-N + i + j) >= (0))) && ((2 + N - i - j) >= (0))) && ((N - j) >= (0))) ? (eval_Y_NR2_pos(i,j)) : (((((-1 + N - i) >= (0)) && ((-1 - N + j) >= (0))) && ((2*N + i - 2*j) >= (0))) ? (eval_Y_NR2((-2 + (i)),(-1 + (j)))) : (max(eval_Y_NR2_pos(i,j), eval_Y_NR2((-2 + (i)),(-1 + (j))))));
		_flag_Y_NR2(i,j) = 'F';
	}
	else if ((_flag_Y_NR2(i,j)) == ('I')) {
		printf("There is a self dependence on Y_NR2 at (%ld,%ld)\n",i,j);
		exit(-1);
	}
	
	return Y_NR2(i,j);
}

static long reduce0(long N, long i0p, long i1p) {
	long reduceVar;
	long k;
	
	reduceVar = LONG_MIN;
	#define RP0(i0,i1,k) X(((k)))
	#define R0(i0,i1,k) reduceVar = max(reduceVar, RP0((i0),(i1),(k)))
	for (k = max(0, 2 * N - 2 * i0p + i1p - 2); k <= 2 * N - 2 * i0p + i1p; k += 1) {
		R0(i0p, i1p, k);
	}
	#undef RP0
	#undef R0
	return reduceVar;
}

static long eval_Y_NR_pos(long i0, long i1) {
	
	// Check the flags.
	if ((_flag_Y_NR_pos(i0,i1)) == ('N')) {
		_flag_Y_NR_pos(i0,i1) = 'I';
		Y_NR_pos(i0,i1) = reduce0(N,i0,i1);
		_flag_Y_NR_pos(i0,i1) = 'F';
	}
	else if ((_flag_Y_NR_pos(i0,i1)) == ('I')) {
		printf("There is a self dependence on Y_NR_pos at (%ld,%ld)\n",i0,i1);
		exit(-1);
	}
	
	return Y_NR_pos(i0,i1);
}

static long reduce1(long N, long i0p, long i1p) {
	long reduceVar;
	long k;
	
	reduceVar = LONG_MIN;
	#define RP1(i0,i1,k) X(((k)))
	#define R1(i0,i1,k) reduceVar = max(reduceVar, RP1((i0),(i1),(k)))
	for (k = max(0, -N + i0p + i1p - 2); k <= -N + i0p + i1p; k += 1) {
		R1(i0p, i1p, k);
	}
	#undef RP1
	#undef R1
	return reduceVar;
}

static long eval_Y_NR2_pos(long i0, long i1) {
	
	// Check the flags.
	if ((_flag_Y_NR2_pos(i0,i1)) == ('N')) {
		_flag_Y_NR2_pos(i0,i1) = 'I';
		Y_NR2_pos(i0,i1) = reduce1(N,i0,i1);
		_flag_Y_NR2_pos(i0,i1) = 'F';
	}
	else if ((_flag_Y_NR2_pos(i0,i1)) == ('I')) {
		printf("There is a self dependence on Y_NR2_pos at (%ld,%ld)\n",i0,i1);
		exit(-1);
	}
	
	return Y_NR2_pos(i0,i1);
}

void example_3d_max(long _local_N, long* _local_X, long** _local_Y) {
	long i;
	long j;
	
	// Copy arguments to the global variables.
	N = _local_N;
	X = _local_X;
	Y = _local_Y;
	
	// Check parameter validity.
	if (!((-1 + N) >= (0))) {
		printf("The value of the parameters are invalid.\n");
		exit(-1);
	}
	
	// Allocate memory for local storage.
	Y_NR = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? ((((4 + 5 * N + 3 * N*N) + 2 * floord(N, 2)))/4) : 0))));
	mallocCheck(Y_NR,"Y_NR");
	Y_NR2 = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? ((((N + 3 * N*N) - 2 * floord(N, 2)))/4) : 0))));
	mallocCheck(Y_NR2,"Y_NR2");
	Y_NR_pos = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (((2 + 3 * N + N*N))/2) : 0))));
	mallocCheck(Y_NR_pos,"Y_NR_pos");
	Y_NR2_pos = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (((N + N*N))/2) : 0))));
	mallocCheck(Y_NR2_pos,"Y_NR2_pos");
	
	// Allocate and initialize flag variables.
	_flag_Y = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (((2 + 3 * N + 3 * N*N))/2) : 0))));
	mallocCheck(_flag_Y,"_flag_Y");
	memset(_flag_Y,'N',((-1 + N >= 0) ? (((2 + 3 * N + 3 * N*N))/2) : 0));
	_flag_Y_NR = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((((4 + 5 * N + 3 * N*N) + 2 * floord(N, 2)))/4) : 0))));
	mallocCheck(_flag_Y_NR,"_flag_Y_NR");
	memset(_flag_Y_NR,'N',((-1 + N >= 0) ? ((((4 + 5 * N + 3 * N*N) + 2 * floord(N, 2)))/4) : 0));
	_flag_Y_NR2 = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((((N + 3 * N*N) - 2 * floord(N, 2)))/4) : 0))));
	mallocCheck(_flag_Y_NR2,"_flag_Y_NR2");
	memset(_flag_Y_NR2,'N',((-1 + N >= 0) ? ((((N + 3 * N*N) - 2 * floord(N, 2)))/4) : 0));
	_flag_Y_NR_pos = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (((2 + 3 * N + N*N))/2) : 0))));
	mallocCheck(_flag_Y_NR_pos,"_flag_Y_NR_pos");
	memset(_flag_Y_NR_pos,'N',((-1 + N >= 0) ? (((2 + 3 * N + N*N))/2) : 0));
	_flag_Y_NR2_pos = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (((N + N*N))/2) : 0))));
	mallocCheck(_flag_Y_NR2_pos,"_flag_Y_NR2_pos");
	memset(_flag_Y_NR2_pos,'N',((-1 + N >= 0) ? (((N + N*N))/2) : 0));
	
	// Evaluate all non fractal reduction outputs.
	#define S0(i,j) eval_Y(i,j)
	for (i = 0; i <= 2 * N; i += 1) {
		for (j = max(-2 * N + 2 * i, N - i); j <= N + i / 2; j += 1) {
			S0(i, j);
		}
	}
	#undef S0
	
	// Free all allocated memory.
	free(Y_NR);
	free(Y_NR2);
	free(Y_NR_pos);
	free(Y_NR2_pos);
	free(_flag_Y);
	free(_flag_Y_NR);
	free(_flag_Y_NR2);
	free(_flag_Y_NR_pos);
	free(_flag_Y_NR2_pos);
}


// Undefine the Memory and Function Macros
#undef X
#undef Y
#undef Y_NR
#undef Y_NR2
#undef Y_NR_pos
#undef Y_NR2_pos
#undef _flag_Y
#undef _flag_Y_NR
#undef _flag_Y_NR2
#undef _flag_Y_NR_pos
#undef _flag_Y_NR2_pos
#undef ceild
#undef floord
#undef div
#undef max
#undef min
#undef mallocCheck
