// This file is generated from test alphabets program by code generator in alphaz
// To compile this code, use -lm option for math library.

// Includes
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <string.h>
#include <limits.h>
#include <float.h>
#include <time.h>
#include <sys/time.h>
#include <sys/errno.h>


// Common Macros
#define max(x, y)   ((x)>(y) ? (x) : (y))
#define MAX(x, y)	((x)>(y) ? (x) : (y))
#define min(x, y)   ((x)>(y) ? (y) : (x))
#define MIN(x, y)	((x)>(y) ? (y) : (x))
#define CEILD(n,d)  (int)ceil(((double)(n))/((double)(d)))
#define ceild(n,d)  (int)ceil(((double)(n))/((double)(d)))
#define FLOORD(n,d) (int)floor(((double)(n))/((double)(d)))
#define floord(n,d) (int)floor(((double)(n))/((double)(d)))
#define CDIV(x,y)    CEILD((x),(y))
#define div(x,y)    CDIV((x),(y))
#define FDIV(x,y)    FLOORD((x),(y))
#define LB_SHIFT(b,s)  ((int)ceild(b,s) * s)
#define MOD(i,j)   ((i)%(j))
#define mallocCheck(v,s,d) if ((v) == NULL) { printf("Failed to allocate memory for %s : size=%lu\n", "sizeof(d)*(s)", sizeof(d)*(s)); exit(-1); }
#define EPSILON 1.0E-4







//Memory Macros
#define X(k) X[k]
#define Y(i,j) Y[i][j]

#define Y_verify(i,j) Y_verify[i][j]
#define var_Y(i,j) Y(i,j)
#define var_Y_verify(i,j) Y_verify(i,j)

//function prototypes
void example_3d_sum(long, long*, long**);
void example_3d_sum_verify(long, long*, long**);

//main
int main(int argc, char** argv) {
	//Check number of args
	if (argc <= 1) {
		printf("Number of argument is smaller than expected.\n");
		printf("Expecting N\n");
		exit(0);
	}
	
	char *end = 0;
	char *val = 0;
	//Read Parameters
	//Initialisation of N
	errno = 0;
	end = 0;
	val = argv[1];
	long N = strtol(val,&end,10);
	if ((errno == ERANGE && (N == LONG_MAX || N == LONG_MIN)) || (errno != 0 && N == 0)) {
		perror("strtol");
		exit(EXIT_FAILURE);
	}
	if (end == val) {
		fprintf(stderr, "No digits were found for N\n");
		exit(EXIT_FAILURE);
	}
	if (*end != '\0'){
		printf("For parameter N: Converted part: %ld, non-convertible part: %s\n", N, end);
		exit(EXIT_FAILURE);
	}
	
	
	///Parameter checking
	if (!((N >= 1))) {
		printf("The value of parameters are not valid.\n");
		exit(-1);
	}
	
	
	//Memory Allocation
	int mz1, mz2;
	long* X = (long*)malloc(sizeof(long)*(N+1));
	mallocCheck(X, (N+1), long);
	long* _lin_Y = (long*)malloc(sizeof(long)*((2*N+1) * (2*N+1)));
	mallocCheck(_lin_Y, ((2*N+1) * (2*N+1)), long);
	long** Y = (long**)malloc(sizeof(long*)*(2*N+1));
	mallocCheck(Y, (2*N+1), long*);
	for (mz1=0;mz1 < 2*N+1; mz1++) {
		Y[mz1] = &_lin_Y[(mz1*(2*N+1))];
	}
	#ifdef VERIFY
		long* _lin_Y_verify = (long*)malloc(sizeof(long)*((2*N+1) * (2*N+1)));
		mallocCheck(_lin_Y_verify, ((2*N+1) * (2*N+1)), long);
		long** Y_verify = (long**)malloc(sizeof(long*)*(2*N+1));
		mallocCheck(Y_verify, (2*N+1), long*);
		for (mz1=0;mz1 < 2*N+1; mz1++) {
			Y_verify[mz1] = &_lin_Y_verify[(mz1*(2*N+1))];
		}
	#endif

	//Initialization of rand
	srand((unsigned)time(NULL));
	 
	//Input Initialization
	{
		#if defined (RANDOM)
			#define S0(k) (X(k) = rand()) 
		#elif defined (CHECKING) || defined (VERIFY)
			#ifdef NO_PROMPT
				#define S0(k) scanf("%ld", &X(k))
			#else
				#define S0(k) printf("X(%ld)=",(long) k); scanf("%ld", &X(k))
			#endif
		#else
			#define S0(k) (X(k) = 1)   //Default value
		#endif
		
		
		int c1;
		for(c1=0;c1 <= N;c1+=1)
		 {
		 	S0((c1));
		 }
		#undef S0
	}
	
	//Timing
	struct timeval time;
	double elapsed_time;
	
	//Call the main computation
	gettimeofday(&time, NULL);
	elapsed_time = (((double) time.tv_sec) + ((double) time.tv_usec)/1000000);
	
	example_3d_sum(N, X, Y);

	gettimeofday(&time, NULL);
	elapsed_time = (((double) time.tv_sec) + ((double) time.tv_usec)/1000000) - elapsed_time;

	// timing information
	printf("Execution time : %lf sec.\n", elapsed_time);
	
	#ifdef TIMING
		FILE * fp = fopen( "trace.dat","a+");
		if (fp == NULL) {
				printf("I couldn't open trace.dat for writing.\n");
				exit(EXIT_FAILURE);
		}
		fprintf(fp, "%ld\t%lf\n",N,elapsed_time);
		fclose(fp);
	#endif
	
	//Verification Run
	#ifdef VERIFY
		#ifdef TIMING
			gettimeofday(&time, NULL);
			elapsed_time = (((double) time.tv_sec) + ((double) time.tv_usec)/1000000);
		#endif
    	example_3d_sum_verify(N, X, Y_verify);
    	#ifdef TIMING
    		gettimeofday(&time, NULL);
			elapsed_time = (((double) time.tv_sec) + ((double) time.tv_usec)/1000000) - elapsed_time;
			
			FILE * fp_verify = fopen( "trace_verify.dat","a+");
			if (fp_verify == NULL) {
					printf("I couldn't open trace_verify.dat for writing.\n");
					exit(EXIT_FAILURE);
			}
			fprintf(fp_verify, "%ld\t%lf\n",N,elapsed_time);
			fclose(fp_verify);
		#endif
	#endif
    	
	#ifdef CHECKING
    	//Print Outputs
		
		{
			#ifdef NO_PROMPT
				#define S0(i,j) printf("%ld\n",var_Y(i,j))
			#else
				#define S0(i,j) printf("Y(%ld,%ld)=",(long) i,(long) j);printf("%E\n",var_Y(i,j))
			#endif
			int c1,c2;
			for(c1=0;c1 <= 2*N;c1+=1)
			 {
			 	for(c2=max(-c1+N,2*c1-2*N);c2 <= (N) * 1 + (c1) / 2;c2+=1)
			 	 {
			 	 	S0((c1),(c2));
			 	 }
			 }
			#undef S0
		}
	#elif VERIFY
		//Compare outputs for verification
		{
			//Error Counter
			int _errors_ = 0;
			#define S0(i,j) if (var_Y_verify(i,j)!=var_Y(i,j)) _errors_++;
			int c1,c2;
			for(c1=0;c1 <= 2*N;c1+=1)
			 {
			 	for(c2=max(-c1+N,2*c1-2*N);c2 <= (N) * 1 + (c1) / 2;c2+=1)
			 	 {
			 	 	S0((c1),(c2));
			 	 }
			 }
			#undef S0
			if(_errors_ == 0){
				printf("TEST for Y PASSED\n");
			}else{
				printf("TEST for Y FAILED. #Errors: %d\n", _errors_);
			}
		}
    #endif
    
	//Memory Free
	free(X);
	free(_lin_Y);
	free(Y);
	#ifdef VERIFY
		free(_lin_Y_verify);
		free(Y_verify);
	#endif
	
	return EXIT_SUCCESS;
}

//Memory Macros
#undef X
#undef Y


//Common Macro undefs
#undef max
#undef MAX
#undef min
#undef MIN
#undef CEILD
#undef ceild
#undef FLOORD
#undef floord
#undef CDIV
#undef FDIV
#undef LB_SHIFT
#undef MOD
#undef EPSILON
