// This code was auto-generated with AlphaZ.

#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Macros
#define ceild(n,d) ((int)ceil(((double)(n))/((double)(d))))
#define floord(n,d) ((int)floor(((double)(n))/((double)(d))))
#define div(a,b) (ceild((a),(b)))
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define mallocCheck(v,s) if ((v) == NULL) { printf("Failed to allocate memory for variable: %s\n", (s)); exit(-1); }

// Global Variables
static long N;
static long* X;
static long* Y;
static char* _flag_Y;

// Memory Macros
#define X(k) X[k]
#define Y(i) Y[i]
#define _flag_Y(i) _flag_Y[((N - i >= 0 && -1 + i >= 0) ? (i) : 0)]

// Function Declarations
static long reduce0(long N, long ip);
static long eval_Y(long i);
void working_example(long _local_N, long* _local_X, long* _local_Y);

static long reduce0(long N, long ip) {
	long reduceVar;
	long j;
	long k;
	
	reduceVar = 0L;
	#define RP0(i,j,k) X(((k)))
	#define R0(i,j,k) reduceVar = (reduceVar) + (RP0((i),(j),(k)))
	for (j = 0; j <= ip; j += 1) {
		for (k = 0; k <= ip - j; k += 1) {
			R0(ip, j, k);
		}
	}
	#undef RP0
	#undef R0
	return reduceVar;
}

static long eval_Y(long i) {
	
	// Check the flags.
	if ((_flag_Y(i)) == ('N')) {
		_flag_Y(i) = 'I';
		Y(i) = reduce0(N,i);
		_flag_Y(i) = 'F';
	}
	else if ((_flag_Y(i)) == ('I')) {
		printf("There is a self dependence on Y at (%ld)\n",i);
		exit(-1);
	}
	
	return Y(i);
}

void working_example(long _local_N, long* _local_X, long* _local_Y) {
	long i;
	
	// Copy arguments to the global variables.
	N = _local_N;
	X = _local_X;
	Y = _local_Y;
	
	// Check parameter validity.
	if (!((-1 + N) >= (0))) {
		printf("The value of the parameters are invalid.\n");
		exit(-1);
	}
	
	// Allocate memory for local storage.
	
	// Allocate and initialize flag variables.
	_flag_Y = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(_flag_Y,"_flag_Y");
	memset(_flag_Y,'N',((-1 + N >= 0) ? ((1 + N)) : 0));
	
	// Evaluate all non fractal reduction outputs.
	#define S0(i) eval_Y(i)
	for (i = 0; i <= N; i += 1) {
		S0(i);
	}
	#undef S0
	
	// Free all allocated memory.
	free(_flag_Y);
}


// Undefine the Memory and Function Macros
#undef X
#undef Y
#undef _flag_Y
#undef ceild
#undef floord
#undef div
#undef max
#undef min
#undef mallocCheck
