// This code was auto-generated with AlphaZ.

#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Macros
#define ceild(n,d) ((int)ceil(((double)(n))/((double)(d))))
#define floord(n,d) ((int)floor(((double)(n))/((double)(d))))
#define div(a,b) (ceild((a),(b)))
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define mallocCheck(v,s) if ((v) == NULL) { printf("Failed to allocate memory for variable: %s\n", (s)); exit(-1); }

// Global Variables
static long N;
static long* X;
static long* Y;
static long* Y_pos;
static long* Y_neg;
static long* Y_pos_NR;
static long* Y_neg_pos;
static long* Y_neg_neg;
static long* Y_neg_pos_NR;
static char* _flag_Y;
static char* _flag_Y_pos;
static char* _flag_Y_neg;
static char* _flag_Y_pos_NR;
static char* _flag_Y_neg_pos;
static char* _flag_Y_neg_neg;
static char* _flag_Y_neg_pos_NR;

// Memory Macros
#define X(k) X[k]
#define Y(i) Y[i]
#define Y_pos(i0) Y_pos[(0)]
#define Y_neg(i0) Y_neg[((-1 + N - i0 >= 0 && -1 + i0 >= 0) ? (i0) : 0)]
#define Y_pos_NR(i0,i1) Y_pos_NR[((-N + i0 == 0 && N - i1 >= 0 && -1 + i1 >= 0) ? (i1) : 0)]
#define Y_neg_pos(i0) Y_neg_pos[(0)]
#define Y_neg_neg(i0) Y_neg_neg[((-2 + N - i0 >= 0 && -1 + i0 >= 0) ? (i0) : 0)]
#define Y_neg_pos_NR(i0,i1) Y_neg_pos_NR[(0)]
#define _flag_Y(i) _flag_Y[((N - i >= 0 && -1 + i >= 0) ? (i) : 0)]
#define _flag_Y_pos(i0) _flag_Y_pos[(0)]
#define _flag_Y_neg(i0) _flag_Y_neg[((-1 + N - i0 >= 0 && -1 + i0 >= 0) ? (i0) : 0)]
#define _flag_Y_pos_NR(i0,i1) _flag_Y_pos_NR[((-N + i0 == 0 && N - i1 >= 0 && -1 + i1 >= 0) ? (i1) : 0)]
#define _flag_Y_neg_pos(i0) _flag_Y_neg_pos[(0)]
#define _flag_Y_neg_neg(i0) _flag_Y_neg_neg[((-2 + N - i0 >= 0 && -1 + i0 >= 0) ? (i0) : 0)]
#define _flag_Y_neg_pos_NR(i0,i1) _flag_Y_neg_pos_NR[(0)]

// Function Declarations
static long eval_Y(long i);
static long reduce0(long N, long i0p);
static long eval_Y_pos(long i0);
static long eval_Y_neg(long i0);
static long reduce1(long N, long i0p, long i1p);
static long eval_Y_pos_NR(long i0, long i1);
static long reduce2(long N, long i0p);
static long eval_Y_neg_pos(long i0);
static long eval_Y_neg_neg(long i0);
static long reduce3(long N, long i0p, long i1p);
static long eval_Y_neg_pos_NR(long i0, long i1);
void working_example(long _local_N, long* _local_X, long* _local_Y);

static long eval_Y(long i) {
	
	// Check the flags.
	if ((_flag_Y(i)) == ('N')) {
		_flag_Y(i) = 'I';
		Y(i) = (((-N + i) == (0)) && ((-1 + N) >= (0))) ? (eval_Y_pos(i)) : ((eval_Y((1 + (i)))) - (eval_Y_neg(i)));
		_flag_Y(i) = 'F';
	}
	else if ((_flag_Y(i)) == ('I')) {
		printf("There is a self dependence on Y at (%ld)\n",i);
		exit(-1);
	}
	
	return Y(i);
}

static long reduce0(long N, long i0p) {
	long reduceVar;
	long i1;
	
	reduceVar = 0L;
	#define RP0(i0,i1) eval_Y_pos_NR(i0,i1)
	#define R0(i0,i1) reduceVar = (reduceVar) + (RP0((i0),(i1)))
	for (i1 = 0; i1 <= N; i1 += 1) {
		R0(N, i1);
	}
	#undef RP0
	#undef R0
	return reduceVar;
}

static long eval_Y_pos(long i0) {
	
	// Check the flags.
	if ((_flag_Y_pos(i0)) == ('N')) {
		_flag_Y_pos(i0) = 'I';
		Y_pos(i0) = reduce0(N,i0);
		_flag_Y_pos(i0) = 'F';
	}
	else if ((_flag_Y_pos(i0)) == ('I')) {
		printf("There is a self dependence on Y_pos at (%ld)\n",i0);
		exit(-1);
	}
	
	return Y_pos(i0);
}

static long eval_Y_neg(long i0) {
	
	// Check the flags.
	if ((_flag_Y_neg(i0)) == ('N')) {
		_flag_Y_neg(i0) = 'I';
		Y_neg(i0) = (((1 - N + i0) == (0)) && ((-1 + N) >= (0))) ? (eval_Y_neg_pos(i0)) : ((eval_Y_neg((1 + (i0)))) - (eval_Y_neg_neg(i0)));
		_flag_Y_neg(i0) = 'F';
	}
	else if ((_flag_Y_neg(i0)) == ('I')) {
		printf("There is a self dependence on Y_neg at (%ld)\n",i0);
		exit(-1);
	}
	
	return Y_neg(i0);
}

static long reduce1(long N, long i0p, long i1p) {
	long reduceVar;
	long i1;
	
	reduceVar = 0L;
	#define RP1(i0,i1,k) X(((k)))
	#define R1(i0,i1,k) reduceVar = (reduceVar) + (RP1((i0),(i1),(k)))
	for (i1 = 0; i1 <= i1p; i1 += 1) {
		R1(N, i1, i1p - i1);
	}
	#undef RP1
	#undef R1
	return reduceVar;
}

static long eval_Y_pos_NR(long i0, long i1) {
	
	// Check the flags.
	if ((_flag_Y_pos_NR(i0,i1)) == ('N')) {
		_flag_Y_pos_NR(i0,i1) = 'I';
		Y_pos_NR(i0,i1) = reduce1(N,i0,i1);
		_flag_Y_pos_NR(i0,i1) = 'F';
	}
	else if ((_flag_Y_pos_NR(i0,i1)) == ('I')) {
		printf("There is a self dependence on Y_pos_NR at (%ld,%ld)\n",i0,i1);
		exit(-1);
	}
	
	return Y_pos_NR(i0,i1);
}

static long reduce2(long N, long i0p) {
	long reduceVar;
	
	reduceVar = 0L;
	#define RP2(i0,i1) eval_Y_neg_pos_NR(i0,i1)
	#define R2(i0,i1) reduceVar = (reduceVar) + (RP2((i0),(i1)))
	R2(-1, N - 1);
	#undef RP2
	#undef R2
	return reduceVar;
}

static long eval_Y_neg_pos(long i0) {
	
	// Check the flags.
	if ((_flag_Y_neg_pos(i0)) == ('N')) {
		_flag_Y_neg_pos(i0) = 'I';
		Y_neg_pos(i0) = reduce2(N,i0);
		_flag_Y_neg_pos(i0) = 'F';
	}
	else if ((_flag_Y_neg_pos(i0)) == ('I')) {
		printf("There is a self dependence on Y_neg_pos at (%ld)\n",i0);
		exit(-1);
	}
	
	return Y_neg_pos(i0);
}

static long eval_Y_neg_neg(long i0) {
	
	// Check the flags.
	if ((_flag_Y_neg_neg(i0)) == ('N')) {
		_flag_Y_neg_neg(i0) = 'I';
		Y_neg_neg(i0) = X((2 + (i0)));
		_flag_Y_neg_neg(i0) = 'F';
	}
	else if ((_flag_Y_neg_neg(i0)) == ('I')) {
		printf("There is a self dependence on Y_neg_neg at (%ld)\n",i0);
		exit(-1);
	}
	
	return Y_neg_neg(i0);
}

static long reduce3(long N, long i0p, long i1p) {
	long reduceVar;
	long k;
	
	reduceVar = 0L;
	#define RP3(i0,i1,k) X(((k)))
	#define R3(i0,i1,k) reduceVar = (reduceVar) + (RP3((i0),(i1),(k)))
	for (k = 0; k <= N; k += 1) {
		R3(N - 1, -1, k);
	}
	#undef RP3
	#undef R3
	return reduceVar;
}

static long eval_Y_neg_pos_NR(long i0, long i1) {
	
	// Check the flags.
	if ((_flag_Y_neg_pos_NR(i0,i1)) == ('N')) {
		_flag_Y_neg_pos_NR(i0,i1) = 'I';
		Y_neg_pos_NR(i0,i1) = reduce3(N,i0,i1);
		_flag_Y_neg_pos_NR(i0,i1) = 'F';
	}
	else if ((_flag_Y_neg_pos_NR(i0,i1)) == ('I')) {
		printf("There is a self dependence on Y_neg_pos_NR at (%ld,%ld)\n",i0,i1);
		exit(-1);
	}
	
	return Y_neg_pos_NR(i0,i1);
}

void working_example(long _local_N, long* _local_X, long* _local_Y) {
	long i;
	
	// Copy arguments to the global variables.
	N = _local_N;
	X = _local_X;
	Y = _local_Y;
	
	// Check parameter validity.
	if (!((-1 + N) >= (0))) {
		printf("The value of the parameters are invalid.\n");
		exit(-1);
	}
	
	// Allocate memory for local storage.
	Y_pos = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(Y_pos,"Y_pos");
	Y_neg = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (N) : 0))));
	mallocCheck(Y_neg,"Y_neg");
	Y_pos_NR = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(Y_pos_NR,"Y_pos_NR");
	Y_neg_pos = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(Y_neg_pos,"Y_neg_pos");
	Y_neg_neg = (long*)(malloc((sizeof(long)) * (((-2 + N >= 0) ? ((-1 + N)) : 0))));
	mallocCheck(Y_neg_neg,"Y_neg_neg");
	Y_neg_pos_NR = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(Y_neg_pos_NR,"Y_neg_pos_NR");
	
	// Allocate and initialize flag variables.
	_flag_Y = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(_flag_Y,"_flag_Y");
	memset(_flag_Y,'N',((-1 + N >= 0) ? ((1 + N)) : 0));
	_flag_Y_pos = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(_flag_Y_pos,"_flag_Y_pos");
	memset(_flag_Y_pos,'N',((-1 + N >= 0) ? (1) : 0));
	_flag_Y_neg = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (N) : 0))));
	mallocCheck(_flag_Y_neg,"_flag_Y_neg");
	memset(_flag_Y_neg,'N',((-1 + N >= 0) ? (N) : 0));
	_flag_Y_pos_NR = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(_flag_Y_pos_NR,"_flag_Y_pos_NR");
	memset(_flag_Y_pos_NR,'N',((-1 + N >= 0) ? ((1 + N)) : 0));
	_flag_Y_neg_pos = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(_flag_Y_neg_pos,"_flag_Y_neg_pos");
	memset(_flag_Y_neg_pos,'N',((-1 + N >= 0) ? (1) : 0));
	_flag_Y_neg_neg = (char*)(malloc((sizeof(char)) * (((-2 + N >= 0) ? ((-1 + N)) : 0))));
	mallocCheck(_flag_Y_neg_neg,"_flag_Y_neg_neg");
	memset(_flag_Y_neg_neg,'N',((-2 + N >= 0) ? ((-1 + N)) : 0));
	_flag_Y_neg_pos_NR = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? (1) : 0))));
	mallocCheck(_flag_Y_neg_pos_NR,"_flag_Y_neg_pos_NR");
	memset(_flag_Y_neg_pos_NR,'N',((-1 + N >= 0) ? (1) : 0));
	
	// Evaluate all non fractal reduction outputs.
	#define S0(i) eval_Y(i)
	for (i = 0; i <= N; i += 1) {
		S0(i);
	}
	#undef S0
	
	// Free all allocated memory.
	free(Y_pos);
	free(Y_neg);
	free(Y_pos_NR);
	free(Y_neg_pos);
	free(Y_neg_neg);
	free(Y_neg_pos_NR);
	free(_flag_Y);
	free(_flag_Y_pos);
	free(_flag_Y_neg);
	free(_flag_Y_pos_NR);
	free(_flag_Y_neg_pos);
	free(_flag_Y_neg_neg);
	free(_flag_Y_neg_pos_NR);
}


// Undefine the Memory and Function Macros
#undef X
#undef Y
#undef Y_pos
#undef Y_neg
#undef Y_pos_NR
#undef Y_neg_pos
#undef Y_neg_neg
#undef Y_neg_pos_NR
#undef _flag_Y
#undef _flag_Y_pos
#undef _flag_Y_neg
#undef _flag_Y_pos_NR
#undef _flag_Y_neg_pos
#undef _flag_Y_neg_neg
#undef _flag_Y_neg_pos_NR
#undef ceild
#undef floord
#undef div
#undef max
#undef min
#undef mallocCheck
