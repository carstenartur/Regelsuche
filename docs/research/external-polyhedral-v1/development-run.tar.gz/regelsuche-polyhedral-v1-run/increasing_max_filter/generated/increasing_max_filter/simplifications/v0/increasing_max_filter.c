// This code was auto-generated with AlphaZ.

#include <float.h>
#include <limits.h>
#include <math.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function Macros
#define ceild(n,d) ((int)ceil(((double)(n))/((double)(d))))
#define floord(n,d) ((int)floor(((double)(n))/((double)(d))))
#define div(a,b) (ceild((a),(b)))
#define max(a,b) (((a)>(b))?(a):(b))
#define min(a,b) (((a)<(b))?(a):(b))
#define mallocCheck(v,s) if ((v) == NULL) { printf("Failed to allocate memory for variable: %s\n", (s)); exit(-1); }

// Global Variables
static long N;
static long* X;
static long* Y;
static long* Y_copy;
static char* _flag_Y;

// Memory Macros
#define X(i) X[i]
#define Y(i) Y[i]
#define Y_copy(i) Y_copy[((N - i >= 0 && -1 + i >= 0) ? (i) : 0)]
#define _flag_Y(i) _flag_Y[((N - i >= 0 && -1 + i >= 0) ? (i) : 0)]

// Function Declarations
static void freduce_Y(long N, long* Y, long* Y_copy, long* X);
void increasing_max_filter(long _local_N, long* _local_X, long* _local_Y);

static void freduce_Y(long N, long* Y, long* Y_copy, long* X) {
	
	// base case
	if (N<10) {
		#define S0(i,j) Y(((i))) = max(Y(((i))),X(((j))))
	    for (int c0 = 0; c0 <= N; c0 += 1)
	      for (int c1 = c0; c1 <= 2 * c0; c1 += 1)
	        S0(c0, c1);
	    #undef S0
	    return;
	  }
	
	// flatten (thick) faces
	#define S0_flatten_top(i,j) Y(((i))) = max(Y(((i))),X(((j))))
	#define S0_flatten_bottom(i,j) Y_copy(((i))) = max(Y_copy(((i))),X(((j))))
	{
	  for (int c0 = (N + 1) / 2; c0 <= N; c0 += 1)
	    for (int c1 = max(N, 2 * c0 - 1); c1 <= 2 * c0; c1 += 1)
	      S0_flatten_top(c0, c1);
	  for (int c0 = N / 2; c0 < N; c0 += 1)
	    S0_flatten_bottom(c0, c0);
	}
	#undef S0_flatten_top
	#undef S0_flatten_bottom
	
	// forward scan
	#define S0_forward_acc(i) Y(((i))) = max(Y(((i))),Y((-1 + (i))))
	for (int c0 = (N + 1) / 2 + 1; c0 <= N; c0 += 1)
	  S0_forward_acc(c0);
	#undef S0_forward_acc
	
	// backward scan
	#define S0_backward_acc(i) Y_copy(((i))) = max(Y_copy(((i))),Y_copy((1 + (i))))
	for (int c0 = 2; c0 <= (N + 1) / 2; c0 += 1)
	  S0_backward_acc(N - c0);
	#undef S0_backward_acc
	
	// combine forward and backward scan results
	#define S0_combine(i) Y(((i))) = max(Y(((i))),Y_copy(((i))))
	for (int c0 = N / 2; c0 <= N; c0 += 1)
	  S0_combine(c0);
	#undef S0_combine
	
	// recursive call
	freduce_Y((N/2)-1, Y, Y_copy, X);
	
	#undef S
}

void increasing_max_filter(long _local_N, long* _local_X, long* _local_Y) {
	
	// Copy arguments to the global variables.
	N = _local_N;
	X = _local_X;
	Y = _local_Y;
	
	// Check parameter validity.
	if (!((-1 + N) >= (0))) {
		printf("The value of the parameters are invalid.\n");
		exit(-1);
	}
	
	// Allocate memory for local storage.
	Y_copy = (long*)(malloc((sizeof(long)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(Y_copy,"Y_copy");
	
	// Allocate and initialize flag variables.
	_flag_Y = (char*)(malloc((sizeof(char)) * (((-1 + N >= 0) ? ((1 + N)) : 0))));
	mallocCheck(_flag_Y,"_flag_Y");
	memset(_flag_Y,'N',((-1 + N >= 0) ? ((1 + N)) : 0));
	
	// Evaluate fractal reduction outputs
	freduce_Y(N,Y,Y_copy,X);
	
	// Free all allocated memory.
	free(Y_copy);
	free(_flag_Y);
}


// Undefine the Memory and Function Macros
#undef X
#undef Y
#undef Y_copy
#undef _flag_Y
#undef ceild
#undef floord
#undef div
#undef max
#undef min
#undef mallocCheck
