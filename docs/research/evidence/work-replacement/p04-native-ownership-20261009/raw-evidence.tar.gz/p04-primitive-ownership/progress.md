# P04 primitive ownership progress

The new tests were run before any production edit. `red.log` and `red-xml/`
retain all ten failures: seven DoubleTerm failures and three Prepared assembly
failures, with no compilation errors. The real native DoubleTerm route rejected
its unsupported rule payload; direct rule calls neither charged nor exposed the
attempted temporary objects. Prepared assembly lost the original assumption
list/copy overlap and replaced an injected primary failure with Java's
self-suppression exception during cleanup.

After RED, the completed-Step debit injection was made explicitly one-shot so
the observer does not also re-inject at the test-owned outer scope's final close.
The independently configured same-Throwable cleanup injection remains active.
The retained original RED record is not rewritten.

Production changes are restricted to AstRewriteTransformationEngine's registered
final DoubleTermRule and PreparedAstRewriteTransformationEngine. They preserve
the mathematical rewrite, duplicate ordering, assumptions, limits, candidate
deduplication and both descriptor calls. Actual RewriteResult allocation work
has moved ahead of insertion; the original unit is removed from the later
charge. New copy/selection/observer work is additional paid execution, not a new
mathematical primitive charge.

Prepared's expression and Step-set comparisons deliberately remain at the same
call sites; the parent is integrating the existing iterative identity contract
centrally. Other built-in MetadataRule implementations have not been admitted
by this slice. Historical hash production is unchanged. V6/PARTIAL/INCONCLUSIVE
remain unchanged, and this does not complete P04 or prove an economic gain.

Focused GREEN verification is pending the serialized Gradle slot. The parent
owns final combined module, native public P03, independent review and CI gates.

## Final local result

The slot was granted and the final fresh-output run passed all 59 focused tests,
zero failures/errors/skips. Two intermediate stale-bytecode runs are preserved;
the final run removed only this worktree's core build output and disabled build
reuse. `javap` confirms the current test's one-shot instruction. No source
patch was made to compensate for stale compilation. See README.md for the full
qualification boundary and source-binding.json for source/class/evidence hashes.

Scoped commit: `f70c4b4db8aeda7c14f560ecd0d2c929bf32fc98`; tree
`331b3c926f08394b20f401de65d79f30893f4a2d`. Worktree clean. Gradle slot released
to the parent. Full P04 and combined verification remain pending.
