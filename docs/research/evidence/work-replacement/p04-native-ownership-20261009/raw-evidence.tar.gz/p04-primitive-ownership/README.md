# P04 primitive ownership slice

Commit: `f70c4b4db8aeda7c14f560ecd0d2c929bf32fc98`.
Tree: `331b3c926f08394b20f401de65d79f30893f4a2d`.
Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`.

The actual registered `ast_double_term` retains its recursive flattening lists,
selected duplicate indices (also when discarded by `matches`), mutable rewrite
copy, numeric/product intermediates and rebuilt additions. Its final private
rule class explicitly exposes its sole reference field, inherited RewriteKind;
other MetadataRule subclasses receive no blanket retention admission.

The Prepared native path now observes the rule's assumptions while the
RewriteResult copies them; mapped assumption text while Step normalizes it;
both original descriptor calls; the actual Step before deduplication; and the
immutable result batch while its source set remains owned. The duplicate-pair
choice, result order, raw comparison call sites, assumptions, metadata calls,
primitive mathematics and generation bounds are unchanged. Constructing a Step
still grants no mathematical proof authority.

The previous RewriteResult allocation unit is settled before result insertion,
then removed from the later charge. Actual additional copy and observer work is
paid separately. Existing immutable assumption lists do not acquire a fictitious
copy charge. New ownership transitions preserve the same primary Throwable,
including an identical exception raised again during cleanup.

## Verification

- RED, before production edits: all 10 new tests failed for the concrete missing
  owner/debit/cleanup behavior; `red.log`, `red-results.json`, `red-xml/`.
- The one-shot completed-Step debit injection was narrowed after RED so it does
  not re-inject at the test-owned outer scope's final close. The separate
  same-instance cleanup injection remains. Observer classification avoids
  re-entering the parent's forthcoming paid Expr equality path.
- Two intermediate runs reported the old version of that test. Actual `javap`
  output and class timestamps showed stale RED bytecode: missing one-shot reset
  and source line 157 rather than current line 159. Even the Gradle `clean` task
  alone left that bytecode intact. Both failed logs/XML and the actual stale
  class files are preserved. No production change was made for these failures.
- Final fresh verification physically removed **only this worktree's** core
  build output, then used `--no-build-cache --rerun-tasks --no-configuration-cache`
  with one worker. `green-fresh-output.log`: all **59 tests passed**, zero failures,
  errors or skips. `fresh-prepared-observer-javap.txt` confirms the current reset
  instruction. Source, test, actual-class and evidence hashes are bound in
  `source-binding.json`.
- `git diff --check` and staged diff checks passed before the scoped commit;
  the worktree was clean after commit.

The 59 tests comprise 56 core tests (10 new cases plus 18 existing rewrite
ownership cases, 18 prepared/historical parity cases, and existing assumption,
occurrence, lineage and retention cases) and three search primitive tests for
paid verification, replay premises and candidate retention.

The focused command selected the exact classes listed in `green-results.json`
using `:regelsuche-core:test` and `:regelsuche-search:test`, the existing JDK 25
runner, `JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2`, and the shared serialized
Gradle home. All 14 final tasks executed. Existing unrelated compile warnings
about deprecated/unchecked code and NativeMoveProof/NativeVerification varargs
remain in the retained log.

## Remaining boundaries

This is matrix item 3's scoped ownership correction, **not P04 completion**.
The parent owns central paid Expr/Step-key comparisons, metadata internals,
other remaining atomic regions, combined Core/Search/Learning tests, native
public P03 differential qualification, independent review and exact-head CI.
Other built-in MetadataRule internals and historical string/hash generation are
unchanged. V6, PARTIAL_ATOMIC_INVENTORY, INCONCLUSIVE, complete=false and
withinBudget=false remain unchanged. These are logical work/ownership tests,
not a JVM heap measurement or an economic/learning-benefit claim.
