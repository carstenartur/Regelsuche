# P04 primitive temporary ownership

Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`.
Worktree: `/workspace/scratch/4e87c3dfd845/Regelsuche-p04-primitive-ownership`.

This is a scoped continuation of matrix item 3, not complete P04 qualification.
The parent owns the shared Expr identity implementation and the final combined
Core/Search/Learning and native public P03 qualification gates. Local Gradle is
serialized with the other independently owned P04 slices.

1. Reproduce the actual registered DoubleTerm rule's missing intermediate
   ownership and its unsupported rule payload in the native transport.
2. Retain its existing flattening lists, selected index arrays, mutable term
   copies, numeric/product intermediates and left-folded result, keeping exactly
   the existing duplicate-pair choice, ordered semantics and rule metadata.
3. Retain Prepared engine assumption copies, metadata descriptors, newly
   assembled steps (including rejected duplicates), and batch copy handoffs.
4. Pay completed work only after publishing the real owner. Retain failed work,
   observe allocations at failed debits, release all frames, preserve the same
   primary Throwable even when cleanup throws that identical instance.
5. Run the new tests RED before changing production code. Then run focused
   primitive/rewrite/retention and historical parity tests GREEN, report exact
   counts and concrete remaining limits, and produce one scoped commit.

Regression changes that must fail these tests: removing a temporary's retained
edge; charging an allocation before owner publication; skipping observation of
the duplicate discarded by the existing step set; replacing a primary budget
failure with a cleanup failure; changing first duplicate choice or term order.

No new search, enumeration algorithm, blanket custom-rule admission or alternative
expression identity implementation is introduced. Other uninstrumented built-in
MetadataRules remain unsupported by the explicit retention graph. V6 partial
coverage flags remain unchanged.
