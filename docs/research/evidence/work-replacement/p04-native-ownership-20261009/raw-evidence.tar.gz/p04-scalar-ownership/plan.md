# P04 ExactRational scalar ownership slice

Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`. Scope is only ExactRational and focused ownership regressions.

Existing arithmetic remains the same: normalized arbitrary-precision rational components, denominator gcd before add, cross cancellation before multiply/divide, unchanged canonical constant identities. Add only lexical ownership of Java-owned intermediate BigIntegers and the completed record. Existing outer arithmetic units remain authoritative; new debits describe observer acquisition, publication and release, not a second mathematical account. No JDK internals, physical heap claims, equality/hash rewrite, second arithmetic implementation or P04 completion flag.

RED: 15 tests run; four historical cross-cancellation tests pass and 11 focused native ownership/debit tests fail behaviorally. Exact logs and XML are retained under red.log and red-xml/.

GREEN pending. Final combined module suite, native P03 differential, independent review and final-head CI remain parent gates.

## Intermediate run and bounded follow-up

The second run executed 59 tests: the 11 original new ownership cases, 4 existing cross-cancellation cases, 14 existing domain cases, 7 existing canonicalizer ownership cases and 20 existing polynomial ownership cases passed, as did a new isolated first-load regression. Exactly two additional regressions failed as intended: `sqrtExact` did not own its returned root/remainder arrays, and repeated identical cleanup throwables triggered Java self-suppression and replaced the primary failure. Raw sources are retained in `second-red-src`, raw XML in `second-red-xml`, and complete output in `second-red.log`.

The follow-up uses the same scalar scratch slots for the two `BigInteger[]` arrays, canonical root and Optional handoff. Guarded reverse-order release replaces automatic multi-resource suppression so the original RuntimeException/Error survives even when cleanup rethrows that same instance. The all-debit sweep also covers successful, non-square and negative square-root paths.

## Measurement and initialization boundary

`Arithmetic.observe` creates its fixed scratch owner only when RetainedOperation already has an active native observer. Retention acquisition/publication/release is additional observer work. There is no second charge for the enclosing declared arithmetic operation and no instrumentation of BigInteger internals. Observer scratch slots are reused only after the former value's mathematical last use. Shared result/operand objects remain identity-deduplicated by the existing retention graph.

The pre-existing three shared rational constants are class initialization, not a query allocation. A blank final bootstrap flag is assigned only after their construction; it prevents a query's exhausted budget from poisoning value-type initialization. A fresh isolated value-type loader test arms the native sink before class initialization, observes zero query debits for those constants, and then verifies that the next actual constructor is rejected by the armed budget while ZERO, ONE and NEGATIVE_ONE remain usable. This does not claim to measure class loading, JDK internal allocations, global constant footprint or physical JVM bytes. Constants reached by ordinary query inputs/results are still part of the ordinary graph.

## Remaining scope boundary

This closes only the audited arithmetic-owned Java intermediates. Scalar import/conversion/export (`fromCanonicalText`, `fromDecimal`, `toBigDecimal`, canonical rendering) and noncached arbitrary-long `equalsInteger` guard temporaries are not newly qualified here. Existing caller-owned arithmetic units and limits remain authoritative. Parent identity work owns any equality/hash charging. Full native accounting, combined module suites, P03 differential and final-head review/CI remain outstanding parent gates.

## Final outcome

Final RED: 61 tests, exactly two failures for shared fast-result handoff and a replaced absolute operand missing during gcd publication. Both were fixed using existing result slots and retaining the old slot value through its replacement checkpoint. Final GREEN: all 61 tests pass, zero errors/failures/skips. Commit `d83a666ed7785e4d3f2c17e3c697b6c7bddc9602`. The build slot was handed directly to the assembly agent after process exit. No further scope expansion or additional builds.
