# P04: Exact rational arithmetic ownership

**Scoped change committed and focused tests GREEN. Not a P04 completion claim.**

- Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`
- Commit: `d83a666ed7785e4d3f2c17e3c697b6c7bddc9602`
- Tree: `0d494758aa688d7f4b6c7a8d342a40d8e7c7f3e5`
- Branch: `codex/p04-scalar-ownership-20261009`
- Source changes: only `ExactRational.java` and `ExactRationalOwnershipTest.java`.

The existing arithmetic formulas and record API are retained. Constructor normalization, addition, multiplication, division, subtraction, negation, reciprocal, power, comparison and exact square-root paths publish their actual Java-owned scalar temporaries under the existing native observer. Fixed scratch slots keep replaced values through publication of their successors, and fast paths expose their canonical shared results. Nested cleanup preserves the first throwable even when a sink rethrows that same instance. No extra mathematical-operation debit is added: new work is observer acquisition, scratch publication and release. No JDK internal allocation or physical heap measurement is claimed.

The pre-existing rational constants initialize independently of a query budget; the isolated-loader regression proves that the next query construction can abort without poisoning their value type. Ordinary query roots still account for reached constants. Historical calls without an active observer allocate no new arithmetic scratch owner and use the same formulas.

## Recorded runs

| Run | Tests | Result |
| --- | ---: | --- |
| Initial RED | 15 | 11 ownership/debit failures; 4 existing cross-cancellation tests pass |
| Second RED | 59 | Exactly 2 failures: root/remainder arrays and repeated-primary cleanup |
| Final RED | 61 | Exactly 2 failures: shared fast result publication and abs-to-gcd replacement overlap |
| Final GREEN | 61 | 61 pass, 0 failures/errors/skips |

Final GREEN contains 16 focused ownership tests, 4 existing cross-cancellation tests, 14 domain tests, 7 canonicalizer ownership tests and 20 polynomial ownership tests. The debit sweep injects failure at every observed arithmetic debit across 12 successful/rejected arithmetic cases. This is a correctness/ownership gate, not a measured speed or learning gain.

Raw output, XML and source snapshots remain alongside this report. The initial RED test source was reconstructed by reversing only the subsequently recorded test patches, as explicitly recorded in `red-source-binding.json`; its original log and XML were retained unchanged. Later source snapshots were saved directly before their runs. Both final runs disabled build-cache reuse and incremental Java compilation after another agent demonstrated a stale-bytecode risk. Compiled production class snapshots and hashes are retained under `green-classes/`.

## Reproduction

Run from the scalar worktree with the shared Gradle slot held exclusively:

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=2' \
node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs \
--no-daemon --no-configuration-cache --no-build-cache --rerun-tasks --max-workers=1 \
-I /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-scalar-ownership/fresh-compile.init.gradle \
:regelsuche-core:test \
--tests de.regelsuche.scalar.ExactRationalOwnershipTest \
--tests de.regelsuche.scalar.ExactRationalCrossCancellationTest \
--tests de.regelsuche.scalar.ExactRationalDomainTest \
--tests de.regelsuche.canonical.CanonicalizerTemporaryOwnershipTest \
--tests de.regelsuche.canonical.PolynomialTemporaryOwnershipTest
```

## Remaining boundary

Conversion/import/export helpers (`fromCanonicalText`, `fromDecimal`, `toBigDecimal`, canonical rendering) and arbitrary noncached-long `equalsInteger` temporaries are not newly qualified here. Equality/hash accounting belongs to the parent's identity slice. No measurement revision, P04 checkbox, completeness flag, historical result or budget limit changed. Combined Core/Search/Learning suites, the public native P03 differential, independent final review and exact-head CI remain parent gates.
