# P04 result export handoffs

Commit `0e9c83f780e6b3e5a231bf3a3150c8cbda104c8a`, tree `19283622312af3a2284b9ff0ff217257cf8395b4`, base `9b2709fad3d395435c3e89c77413cc3e9bfd6da1`. Worktree clean.

Production scope is limited to `NativeMoveSearch.Result.projectLegacy` and its State/Assessment export helpers. Result constructors, search execution, frontier, verification authority and policy are unchanged.

The projection now owns completed states, moves, receipts and output records while later component exports can fail. State and assessment helpers transfer their completed output into the caller's owned buffer before local cleanup. The encoded state expression remains owned while `MoveState` normalizes assumptions. An existing `SearchExecution` cleanup helper preserves the primary exception even if cleanup throws that identical object.

Completed container allocations and aggregate-entry work are settled as they occur; the former end-of-projection bulk debit is removed. Each new representation object is charged once. Existing mathematical application/verification work is preserved, and output never changes the published search account. Shared references remain counted by identity.

Verification:

- Valid RED: all eight new tests failed for the intended missing owners or primary-exception corruption; `red-valid.log`, `red-valid/xml`, and the corresponding source snapshot bind this run.
- Two earlier test-trigger attempts are retained: the first used an assessment constructor that has no observed debit; the second lacked StackWalker's class-reference option. Both diagnostic mistakes were corrected before the valid RED and any production changes.
- First GREEN attempt: all eight new cases and three existing export accounting cases passed. The old chronological test depended on the aggregate owner being the top frame. Its observer now walks enclosing frames while retaining its two ordered assessment-change assertions.
- Final GREEN: **14 tests, zero failures/errors/skips**, freshly compiled with incremental compilation disabled and `--rerun-tasks`; three existing accounting, three existing chronology, eight ownership cases. Source SHA256 values exactly match the committed files.
- Frozen pre-fix projection hash: `22c7a8db6725066c8c50a76d3220de3f896341a5f35f2c6f9105235f20961071`. The full serialized projection matches this hash and the independent retained/unretained calls. Codec counts, complete witnesses/events/assessments, repeated-export costs, cleanup, and the unchanged published search ledger are checked separately.

The old source's V6/V2 partial flags remain unchanged. The parent's separately planned V7/V3 revision is not part of this commit and has not been folded into the frozen output expectation. No complete P04 or lifecycle-economic claim is made. No global tests or full public matrix were run. The Gradle slot was explicitly released after the final process exited.

Exact final command, from the bound worktree:

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2 node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --no-daemon --no-configuration-cache --max-workers=1 --rerun-tasks --init-script /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-result-export/fresh-compile.init.gradle :regelsuche-search:test --tests de.regelsuche.search.moves.NativeResultExportOwnershipTest --tests de.regelsuche.search.moves.NativeExportAccountingTest --tests de.regelsuche.search.moves.NativeExportOrderTest
```

`source-binding.json` binds the commit, sources, runner, JDK and nonincremental init script. `green/summary.json` and `green/xml` contain the selected results. All failed attempts remain in this evidence directory.
