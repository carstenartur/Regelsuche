# P04 assumption metadata: scoped implementation evidence

Commit: `3aa54c3cd28da7f18208b0b2a54688bde8587dcf`
Tree: `3848a5579680859f8b93a63b072945d3984c43b8`
Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`
Branch: `codex/p04-assumption-metadata-20261009`

## What changed

- `AssumptionSignature` exposes its actual list/fingerprint through the existing
  retained-graph contract. The initialized record and its constructor's defensive
  copy overlap the caller's list before allocation work can abort.
- Existing normalization stages keep their actual old/new strings, operand
  substrings and trimmed parentheses. The sorted set, immutable list, joined
  fingerprint and final record remain owned through completion/failure.
- Literal `BigInteger.abs()` and the approved adjacent exponent-bound
  `BigInteger.valueOf()` guard operands are owned before their completed-operation
  debit. A semantic rejection is raised only after technical observation and
  cleanup succeed. Original technical throwables survive identical or distinct
  cleanup failures.
- Domain `Work.add` was not changed or duplicated; tests assert exact visited
  prefixes on success, semantic rejection and resource abort.

## Verification

The two RED invocations compiled the unchanged production base and produced real
behavioral failures: 7/7 assumption tests and 6/6 literal/power-guard tests. They
failed because actual owners/abort opportunities were missing, not from harness
or compilation errors. `core-red-xml`, `literal-red-xml`, `focused-red.log` and
`literal-red.log` retain the evidence. The first command stopped at the intended
core failure, so learning RED ran separately.

One scoped GREEN invocation completed with exit 0 in 25 seconds:

```text
--no-daemon --no-configuration-cache --continue --max-workers=1
:regelsuche-core:test
  --tests de.regelsuche.assumption.*Test
  --tests de.regelsuche.transform.AstRewriteTransportAssumptionsTest
  --tests de.regelsuche.transform.AstRewriteTransformationEngineAssumptionTest
:regelsuche-learning:test
  --tests de.regelsuche.evolution.CheckedSchemaLiteralOwnershipTest
  --tests de.regelsuche.evolution.CheckedSchemaApplicationPhasesTest
  --tests de.regelsuche.evolution.CheckedSchemaProofBoundaryTest
  --tests de.regelsuche.evolution.CheckedLearnedSchemaModelTest
```

Runner: `evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs`;
JDK 25; Gradle 9.7.1; shared `gradle-home`; one worker;
`JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2`. All Gradle use was serialized with
other agents. Slot passed to proof-export after process exit.

XML totals: **129 tests, 0 failures, 0 errors, 0 skipped**: 29 core and 100 learning,
including 37 nested native-provider-accounting cases. All 13 added RED regressions
now pass. Existing tests required no changes. `focused-results.json`,
`regelsuche-core-green-xml`, `regelsuche-learning-green-xml` and `focused-green.log`
retain counts and raw evidence. The existing deprecation and missing Jackson
annotation enum compile warnings remain visible in logs; no warning suppression
was added. `git diff --check` passed before commit; worktree is clean.

## Boundaries

Only the two production files and their two new focused test files changed.
No search caller or global budget/accounting API was changed. The parent owns
`NativeMoveProvider.carries` and `NativeMoveSearch.Execution.carries` available-set
ownership. No new mathematical authority, normalization language or data format
was introduced. Logical retained units do not establish physical heap bytes or
an economic speedup.

This is a scoped P04 slice, not full P04 acceptance. V6 remains
`PARTIAL_ATOMIC_INVENTORY`, `INCONCLUSIVE`, `complete=false`, `withinBudget=false`.
The complete native P03 differential, combined Core/Search/Learning suites,
independent final review and exact-head CI remain parent integration gates.
