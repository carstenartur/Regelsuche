# P04 assumption metadata and scalar guard ownership

Source base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`.
Isolated branch: `codex/p04-assumption-metadata-20261009`.

The accepted P04 design is unchanged. This slice closes actual metadata-owned
normalization strings, sorted-set/list/fingerprint overlaps, the signature's
defensive constructor copy, the absolute numerator of a checked literal and the
converted exponent upper bound. It does not replace AST validation, alter the
canonical signature bytes or change polynomial-domain decisions.

1. Add behavioral ownership tests and demonstrate RED on the unchanged base.
2. Retain real completed objects before their debit and preserve the primary
   exception through observation and owner release. Keep semantic domain rejection
   separate from technical resource failure. Domain `Work` visits stay once only.
3. Run focused new tests and existing assumption/schema/domain regressions.
4. Record source bindings, logs, XML and a scoped commit for integration.

Gradle is serialized with the parent and other P04 workers. No global suite or
remote publication belongs to this slice. Final P04 combined-module/native P03
differential/review/CI gates remain the parent's responsibility. V6 remains
`PARTIAL_ATOMIC_INVENTORY`, `INCONCLUSIVE`, `complete=false`, `withinBudget=false`.

Shared search gaps reported to the parent, not edited here:
`NativeMoveProvider.carries` and `NativeMoveSearch.Execution.carries` build a
temporary available-assumptions `HashSet` without an owned frame or work debit.

## RED evidence

- `focused-red.log` and `core-red-xml`: 7 tests run, 7 expected behavioral failures
  on the original implementation. Missing observed strings/metadata and missing
  injected-abort opportunities; no compilation or harness error.
- `literal-red.log`: separate learning invocation because the first build stopped
  at the deliberately red core task. It also tests the converted exponent bound,
  included after the parent explicitly approved that adjacent guard.
