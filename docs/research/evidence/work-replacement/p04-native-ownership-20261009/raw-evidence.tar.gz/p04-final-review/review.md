# P04 – unabhängiger Abschlussreview

**Keine offenen Critical-/Important-Befunde in den vereinbarten Produktionskorrekturen der Matrix 1–9; R1–R4 sind geschlossen.** Die bestehende PARTIAL-Semantik bleibt erforderlich. Eine globale Freigabe vollständiger Kostenabdeckung für beliebige Erweiterungen ist durch diesen Review nicht belegt. Das lokale Pflicht-Gate `final-ai-4` ist am Abschluss-Head bestanden; `final-ai-3` bleibt für den vorherigen Head als RED erhalten.

Geprüfter Abschluss-Head: `2efdd698393f47045cf62a670955b2fd80579eca`, Baum `755c9449cf36c6d08ec7009662685474e5a72c28`. Akzeptierte Basis: `f67f9248fc4f282cb35af1fbf0d699801233bcb6`. Produktions-/Teststand der vollständigen Modul- und Korpusläufe: `1a09fdb3dd2940973c85d0f10c21e2fa2324afee`, Baum `8e51d80fbb7c6a33e0b429aab24ad9fb14a64589`. Vollständige Dateibindung: `source-binding.json`; zusätzliche Java-Identitätsbindung: `java-identity.json`.

Der Reviewer hat den vollständigen beauftragten Diff und anschließend nur dessen begrenzte Fix-/Test-Tails gelesen, vorhandene XML-/Korpusdaten unabhängig ausgewertet und Quellen gebunden. Keine Produkt-/Testdateien wurden geändert; keine Builds, Tests, geschützten Holdouts oder Remote-Aktionen wurden ausgeführt. Frühere Reviewstände einschließlich `review-0e26c2b.md` bleiben erhalten.

## Geschlossene Befunde

| Befund | Nachweis und Abschluss |
|---|---|
| **R1: Replay-Abbruch und frische Verifikationsquittung** | Bezahlte Root-/Lineage-/Receipt-/Endpoint-Vergleiche lagen außerhalb des bisherigen ResourceLimit-Catchs. Die neue gemeinsame Grenze erhält bezahlte Prefix-/Verifikationsarbeit und besitzt den frischen Receipt vor dem Vergleich. Echte semantische Mismatches bleiben Fehler. Integriert in `cf4c58a`. |
| **R2: doppelte Witness-Materialisierung** | Der aktive Producer bezahlte die Liste bereits, `Objective.finish` delegierte zusätzlich das historische n+1. Unter aktivem Observer entfällt diese zweite Delegation; der unobservierte Legacy-Vertrag bleibt unverändert. Ebenfalls `cf4c58a`. R1/R2: vorhandenes RED 14 Tests/10 Fehler, GREEN 48/0. |
| **R3: scoped SymbolId im Monom-Pfad** | Der reale A²-gegen-scoped-x⁴-Pfad erzeugte unbesessene Hex-/UUID-/kanonische Zwischenprodukte. `807ef5c` veröffentlicht sie vor falliblen Debits, bewahrt Identität und alte Konvertierungsfehler. RED 11/11; GREEN 61/0. Die beiden korrigierten alten Test-Fixtures scheiterten nachweislich schon mit der Basisproduktion innerhalb des aktiven Observers. |
| **R4: finale Exportkopien einschließlich frühestem Abbruch** | Die erste Korrektur bezahlte Kopien nur nach einem bereits falliblen Einheitsdebit. Der abschließende Fix `c99a3ec` bezahlt den gesamten bereits fertigen Konstruktor-/Kopierblock vor seinem ersten Checkpoint. Reale identische Container kosten keine Kopie; Inputs und fertige Outputs bleiben gleichzeitig sichtbar. RED 11/10 zeigt Result 1 statt 12, Staged 1 statt 5 und Assessment 1 statt 4; GREEN 25/0 einschließlich früher Debit-/Checkpoint-Abbrüche. |

Die Quell-/XML-Bindungen liegen in `p04-replay-abort`, `p04-scoped-monomial` und `p04-export-atomic-copies`; die unabhängigen Auswertungen stehen zusätzlich in diesem Verzeichnis. Teilnachweise verschiedener Quellstände werden nicht als ein einziger finaler Testlauf ausgegeben.

## Abdeckung des vereinbarten Reviews

| Auditmatrix | Gelesener Vertrag und Ergebnis |
|---|---|
| 1 – Identität | Gemeinsamer bezahlter struktureller Vergleicher für Store/aktive Expr-Identität, Frontier, Goal und Replay; Kollisionen ersetzen keinen Vergleich. Scope, Gruppierung und Reihenfolge bleiben relevant. R1 geschlossen. |
| 2 – TreePosition | Parent-/Navigations-/Funktionsargument-/Ergebnis-Owner vor fallibler Weiterarbeit; unveränderte Geschwister bleiben geteilt. Keine zweite Instanziierungs- oder Frontier-Implementierung. |
| 3 – Primitive | DoubleTerm, verworfene Zwischenkandidaten, Assumptions- und Ergebnis-Metadaten sind in den bestehenden Rewritepfad eingebunden; mathematische Regeln unverändert. |
| 4 – Monome | Reale Maps, Besuche, Wurzeln und Handoffs werden erfasst, ohne Backtracking-Branches als Monomarbeit umzudeuten. R3 schließt den verbundenen scoped-Symbol-Pfad. |
| 5 – Skalare | Eigene exakte Zwischenwerte und deren Überlappungen werden beobachtet; Formeln, Bit-/Exponentenlimits und mathematische Quittungen bleiben erhalten. |
| 6 – Formatter/Features | Failure-atomic Pufferwachstum, bezahlter JSON-Writer und struktureller Kontext; historischer Text-/JSON-Vertrag bleibt erhalten. AstReplayJson hält frisch erzeugten Scalar-/Symboltext bis zur Übergabe. |
| 7 – Annahmen/Guards | Eigene Set-/String-/Normalisierungs- und Literalguard-Zwischenwerte; technische Abbrüche werden nicht als fachliche Ablehnung versteckt. |
| 8 – Proof/Export | Application-/Proofwrapper, Hash-Zwischenwerte, Verifikations- und zusammengesetzter Legacy-Export; Digest/Status verleihen keine mathematische Autorität. R4 geschlossen. |
| 9 – Ergebnisquittungen | Reale Producer-/Lane-/Witness-/Result-Kopien; begrenzte Endmontage nach einem festgehaltenen Limit bezahlt nur bereits bestimmte Metadaten und nimmt die Suche nicht wieder auf. R2 geschlossen. |

Im vereinbarten unterstützten Bereich bleibt keine weitere konkret belegte eigene Java-Owner-/Arbeitslücke offen. Das ist keine Aussage über beliebige externe Callbacks, nicht geprüfte weitere Verfahren oder physische JVM-Allokationen.

## Laufnachweise und begrenzte Test-Tails

Die vorhandenen frischen XML-Dateien von `p04-integration-gates/full-modules-isolated-2` enthalten **Core 1147, Search 671 und Learning 1089 Tests: insgesamt 2907 ohne Fehler, Errors oder Skips**. Die Dateien sind an `1a09fdb` gebunden. Der Review hat die XML-Summen selbst nachgezählt; er hat die Suiten nicht erneut ausgeführt.

Die Testkorrekturen verschieben Fixturebau und mathematische Ergebnisvergleiche aus aktiven Messcallbacks, verwenden dort Typ-/Referenzproben und erhalten bzw. ergänzen die konkreten mathematischen Assertions nach dem Scope. Grenzen, Kostenassertionen und die Cursor-Abbruchmatrix wurden nicht aufgeweicht. Die ursprünglichen 1M-/10M-Budgetfehlschläge bleiben als reale negative Zeilen erhalten. Zusätzliche 1B-Läufe verwenden die vorab im öffentlichen Korpus deklarierte Diagnosegrenze und sind keine wirtschaftliche Aufwertung.

Nach `1a09fdb` bleibt **jede Produktions-Java-Datei unverändert**. `192c441` verändert keine Java-Datei; alle 27 übernommenen AI-Baseline-/Provenanzdateien sind blobgleich zum separat qualifizierten #1068-Stand `709a1a6`. Danach ändern `139d028` und `77e77f6` ausschließlich die Kindreferenz-Dispatchfunktionen zweier Testgraphbesucher. Besuchsreihenfolge, Identitätsmenge, Queue und Assertions bleiben gleich; die vorhandenen frischen Tail-Läufe enthalten 2/2 bzw. 6/6 erfolgreiche Fälle. Die vollständige 2907-Suite wird dadurch nicht fälschlich auf dem späteren Head neu behauptet. `2efdd69` extrahiert dieselbe unveränderte Kindreferenz-Dispatchlogik in zwei weiteren Testhelfern (`TreePositionOwnershipTest`, `ProofExportOwnershipTest`). Die Folge, Identitätsmengen, Queue, Typen und Assertions sind identisch. Die eigenständig nachgezählten frischen Tail-XML enthalten Core 9 und Learning 12 erfolgreiche Fälle; ihre vor dem Commit gebundenen Testdatei-Hashes stimmen mit `2efdd69` überein. Weiterhin keine Produktionsänderung.

Der öffentliche native Korpus `p04-native-public-corpus/final-matrix-1` ist an `1a09fdb` gebunden. Alle 13 Ergebnisdateien sind zwischen zwei frischen JVMs bytegleich; die Hashes wurden unabhängig nachgerechnet. Pro Budgetmodus existieren 26 Such-/Qualitätszeilen, außerdem zehn Cursorfälle, acht Expr-Identitäten, drei State-Identitäten und zwei negative Replays. Die ausgewerteten nativen Codec-Zähler bleiben null.

Unter der großzügigen Diagnosegrenze stimmen **24/26 strikte Projektionen** überein. Die übrigen zwei Zeilen (`primitive-assumption-absent`, `schema-assumption-absent`) unterscheiden sich ausschließlich im bewusst falschen nativen `completeBoundedRelation`. Unter den eingefrorenen Zahlenbudgets stimmen **0/26 strikte Projektionen** überein; sämtliche bezahlten Erschöpfungen/Abweichungen bleiben im Bericht. Es gibt keine nachträgliche Budgetanhebung in diesen Zeilen und keinen Lern-/Leistungsnachweis. Das Training bleibt separat gebunden; echte gelernte und wiederhergestellte Anbieter werden verwendet.

`final-ai-3` ist an `77e77f6` mit Exitcode 1 gebunden und bleibt unverändert als RED erhalten. `final-ai-4` ist an den aktuellen Abschluss-Head gebunden und mit Exitcode 0 bestanden: sauberer Quellstatus, 18 frische Reportdateien. Deren Hashes wurden vom Reviewer unabhängig mit dem Gate-Manifest abgeglichen. Policy und Schwellen werden durch diese Test-Tails nicht verändert. Sämtliche vorgeschriebenen Remote-CI-Prüfungen auf dem freizugebenden Head wurden durch diesen Reviewer nicht selbst qualifiziert. Die vorgeschriebene Remote-CI bleibt vor Integration gesondert zu qualifizieren.

## Konkrete Grenze einer möglichen V8-Freigabe

**Ja: Eine V8-Freigabe braucht eine ausdrückliche, revisionsgebundene Zulassung bekannter Ausführungspfade.** Die derzeitige öffentliche `NativeMoveSearch.Problem`-Konstruktion akzeptiert Provider, Policy, StateScore, StateValue und Verifier ohne Beleg ihrer vollständigen Ausführungskostenabdeckung. `RetainedGraph.View` beschreibt erreichbare Daten; ein zulässiges Enum belegt ebenfalls nicht die Kosten seines Codes. `NativeMovePriorityPolicy.contextWork()` liefert standardmäßig null Einheiten. Ein solcher Callback kann zusätzliche Java-Arbeit erledigen, obwohl die vorhandenen beobachteten Quittungen vollständig aussehen. Die mathematische Registrierung in `NativeVerifier.registered` beantwortet eine andere Frage und darf nicht als Kostenfreigabe verwendet werden.

Damit ist eine globale Umschaltung von `complete`/`accountingComplete` allein aufgrund der Matrix 1–9, der Tests oder erfolgreicher Graphbeobachtung nicht belegt. Eine eng gefasste neue Revision muss alle tatsächlich verwendeten Ausführungs- und Delegationspfade auf die ausdrücklich geprüfte Abdeckung begrenzen; unbekannte Erweiterungen bleiben PARTIAL. Das betrifft auch angehängte Auswahl-/Bewertungs-/Verifikations- bzw. Suchauftragsfunktionen, nicht nur den äußeren Providertyp. Ein öffentlich behaupteter Status oder ein Digest genügt dafür nicht.

Zusätzlich bleiben vollständige vorhandene Accounting- und Cursorquittungen, bezahlter Final-Replay sowie die bisherigen Arbeits-/Retentions-/Unknown-Fehlerpfade erforderlich. `completeBoundedRelation` darf nur den ursprünglichen Kernelwert **und** die eigene erfolgreiche Qualifikation übernehmen. Eine neue logische Inventory-Definition verspricht weiterhin keine CPU-Instruktions-, JVM-Byte- oder GC-/RSS-Garantie. V7/V3-Rohdaten bleiben historisch unverändert; #745/Produktionsphase, Defaults, Lern- und Geschwindigkeitsbehauptungen erhalten keine Freigabe.

Diese Erweiterungsgrenze ist kein neuer Defekt der derzeit korrekt gesperrten PARTIAL-Fassung. Sie ist ein konkret fehlender Freigabevertrag für die angefragte globale V8-Änderung. Der vorliegende Review schließt die beauftragten Produktionskorrekturen ab und erklärt P04 bzw. P01–P12 nicht insgesamt für abgeschlossen.
