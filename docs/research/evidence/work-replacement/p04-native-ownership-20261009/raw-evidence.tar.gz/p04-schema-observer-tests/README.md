# CheckedLearnedSchemaModelTest: observer reentrancy correction

Base: `0e26c2b1974b00a6b48c38c0b8367b07230b73c7`.
Commit: `443b6b1734b8d258b76739c6a806cd46df0ce066`. Tree: `cfc9d72db1ce93f1de4f1885f3ee1d7fd3e632d7`.
Only `regelsuche-learning/src/test/java/de/regelsuche/evolution/CheckedLearnedSchemaModelTest.java` changed.
Production code, budgets, measurement revisions and expected work numbers remain unchanged.

## Source-bound observed failure

The parent's fresh isolated full-module run in
`../p04-integration-gates/full-modules-isolated-1/` provided both complete XML
reports for this file: 78 tests (41 outer + 37 nested), 41 failures (15 + 26),
0 errors/skips. The test source SHA-256 matches that run's complete source binding.
Copies of the actual XML traces and original test source are in `red-xml` and
`red-src`, with the binding/counts in `red-source-binding.json`.

Real traces show paid Expr.equals re-entering the observers through
ExpressionIdentity -> RetainedOperation.work -> executionWork:

- ImportMeter's TreeMap.containsValue(Expr).
- VerifierMeter.snapshot's expression equality and construction of NumberExpr(0)
  inside the observer callback.
- CursorMeter's List.contains(source Expr).
- ProviderMeter's List.contains(received.expression()).

## Scoped test correction

The probes now use actual owner identity and type checks. ImportMeter captures
the actual replacing NumberExpr; an additional assertion outside the measured
scope confirms its exact value remains 991. VerifierMeter observes the actual
application object at TARGET_DOMAIN and its retained target identity; an
additional assertion outside the scope confirms the target is exactly source+0.
No mathematical assertion is replaced with a weaker shape-only assertion.

Receiving State/context/provider fixtures are prepared before the observed call.
The ancestor-rebuild result assertions are also outside its measurement scope.
The existing work, receipt, phase, ownership, cleanup and primary-error assertions
remain, with no expected numeric value relaxed or revised.

## Fresh verification

Single-file filter (including nested class), new unique /tmp build and project
cache, offline JDK25.0.2+10/Gradle9.7.1, no build cache, rerun tasks, serial worker,
nonincremental Java compilation configured by `isolate-build.gradle`.

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --offline --no-daemon --no-build-cache --rerun-tasks --max-workers=1 --project-cache-dir /tmp/regelsuche-p04-schema-observers-i7a_0fdd/project-cache -I /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-schema-observer-tests/isolate-build.gradle :regelsuche-learning:test --tests 'de.regelsuche.evolution.CheckedLearnedSchemaModelTest*'
```

Result: exit 0 in 30 seconds, **78 tests passed**, 0 failures/errors/skips.
All 3044 compiled project classes and both XML reports are fresh; the test source
hash remained unchanged throughout verification. Raw output, XML, test class
snapshots and source hashes are in `green-1.*`, `green-1-xml`, `green-1-classes`,
`green-1-src` and `green-1-source-binding.json`.

Existing compiler warnings/notes from dependency modules remain in the log;
none refers to the modified test source. No additional project-wide gate was run
by this agent. Combined P04 acceptance remains the parent's responsibility.
The Gradle slot was explicitly handed to the primitive/core agent after exit.
