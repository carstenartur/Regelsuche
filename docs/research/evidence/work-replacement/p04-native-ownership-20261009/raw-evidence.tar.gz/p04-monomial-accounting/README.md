# P04 bounded monomial accounting slice

Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`.
Verified isolated commit: `de2e114111273b5556d5d36f737ea9e3a43743db`.

The existing bounded monomial path now pays each admitted Budget.visit directly into the active RetainedOperation. Consumption precedes its debit, so an accounting failure does not refund or settle the same visit again. Algebraic visits are not added to historical MatchAttempt.visitedBranches; the original visit/depth/coefficient/exponent limits and assumption-free rejection decisions remain unchanged.

Lexical owners expose the actual defensive natural-order powers map, each monomial and Optional handoff, input/operand/accumulator overlap, reciprocal/coefficient and integer-root scalar intermediates (including absolute, difference, sum, midpoint, power and signed-root values), and AST construction before folding. Completed allocations use retainCompleted/produced so failed debit observation precedes cleanup. The matcher holds returned monomials through root inference, rendering and equivalent comparison. The former package-private record is a View class with a private defensive powers map; there is no new matcher or solver.

## Verification

- RED on unchanged production base: existing ExactMonomialInferenceTest 24 passed; all 7 new ExactMonomialOwnershipTest cases failed for the intended missing owners or visit payment/injected abort. No test errors. `red.log`, `red-results/`, `red-test.patch` preserve the evidence.
- GREEN on the committed source: 110 passed, 0 failed/errors/skipped: ExactMonomialInferenceTest 24, ExactMonomialOwnershipTest 7, ExprMatcherOwnershipTest 52, MatcherAttemptOwnershipTest 16, MatcherLimitOwnershipTest 3, PatternMatcherTemporaryOwnershipTest 8. `green.log` and `green-results/` preserve the evidence. `git diff --cached --check` passed before the commit; `verified.patch` binds its complete diff.
- Command used the existing run-gradle25.cjs runner, JDK 25.0.2+10, Gradle 9.7.1, shared gradle-home, `JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2`, `--offline --no-daemon --no-configuration-cache --max-workers=1 -Dorg.gradle.jvmargs=-Xmx768m :regelsuche-core:test`, with only the named classes selected. Gradle ran in the parent-controlled serialized slot.

## Boundaries

This is the audit matrix row-4 slice, not P04 acceptance. Core/Search/Learning full-suite verification and independent combined review remain with the parent. V6, PARTIAL_ATOMIC_INVENTORY, INCONCLUSIVE, complete=false and withinBudget=false are unchanged. No thresholds or historical comparison data changed.

RetainedGraph still measures declared logical objects/references/scalar characters and observer work, not JVM allocations, headers, stack, GC or RSS. Internal ExactRational arithmetic/constructor temporaries remain the separate row-5 scalar slice; raw matcher AST equality and collection comparison algorithms are not replaced here. No remote action, publication, comment or merge was performed.
