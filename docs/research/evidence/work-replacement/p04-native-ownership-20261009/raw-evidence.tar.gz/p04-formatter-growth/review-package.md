# P04 formatter allocation-debit slice

Base: `8fc3bcd7c246e48b9272ed3977b19c43082656ce`. Only `ExpressionFormatter.java` and its existing `ExpressionFormatterTemporaryOwnershipTest.java` changed.

The formatter used to allocate its initial `char[16]`/pending deque, then debit 19 units before publishing the `Output` owner. Growth likewise allocated a replacement array, debited its length, and only then retained the old/replacement pair. Failed debits therefore skipped those actual allocations.

The existing output frame now uses `retainCompleted(19, builder)`. Initial action scheduling happens inside that frame. Growth uses `retainCompleted(replacement.length, old, replacement)`. Successful operation debit amounts and number of formatter checkpoints are retained. No new formatter, observer implementation, JSON path, frontier change, revision promotion, or qualification change.

Five focused regression/control tests were added to the existing ownership suite. They cover initial expression workspace/input/callback, initial equation workspace/input, pre-copy old/new array overlap on growth debit failure, preservation of the original arithmetic failure when checkpoint and frame cleanup also throw (initial and growth cases), and the already failure-atomic actual String result handoff. Existing callback, conversion, emission, grouping and rendering assertions remain in place.

Verification: clean focused baseline 26 tests; genuine RED 18 tests with 4 expected assertion failures; focused GREEN 31 tests, 0 failures/errors/skips. The added String handoff control passed in RED and GREEN; production handoff logic was not changed. `git diff --check` passed. XML and full logs are retained here. An initial wrapper-download attempt failed before compilation; it is infrastructure-only, not a source/test failure. Local Java 25/Gradle 9.7.1 runner recovered the checks without repository configuration changes.

Scope remains bounded to audit matrix row 6 formatter buffer debit handling. This is not P04 acceptance: V6 / PARTIAL_ATOMIC_INVENTORY / INCONCLUSIVE / complete=false / withinBudget=false remain unchanged. All other audited regions remain pending. Parent explicitly deferred complete Core/Search/Learning suites and native P03 qualification to the combined P04 gate and will arrange a combined review. No publication, merge or comments were made.
