# Independent whole-slice review — TreePosition ownership

Date: 2026-10-09. This is the first completed independent review of this slice; the previous interrupted reviewer produced no report. Verdict: **no Critical or Important findings; no blocking correction identified within this slice.** This is not acceptance of complete P04 accounting.

## Exact review binding

- Worktree: `/workspace/scratch/4e87c3dfd845/Regelsuche-p04-tree-position`
- Branch declared in the supplied binding: `codex/p04-tree-position-20261009`
- Verified HEAD/base: `ae6b36eae23ed96aed2f0815442ab67634f87065`
- Verified HEAD tree: `eb052f81047973154d99105273de5851b0c9b9a3`
- Review target: the uncommitted three-file slice, including the untracked test (not merely the two files shown by ordinary `git diff`).
- SHA-256 of `git diff --binary` for the tracked changes: `055d1c11afef58f05c9be755e792e7aade98324fad19673cd1ee5ac70ae9b590`.

| File, relative to worktree | SHA-256 of reviewed bytes |
| --- | --- |
| `regelsuche-core/src/main/java/de/regelsuche/moves/enumerate/TreePosition.java` | `a0adbebb0585907611df3dd72f48b9772c91315bdb2488854ca6133ba482f973` |
| `regelsuche-core/src/test/java/de/regelsuche/moves/enumerate/TreePositionOwnershipTest.java` | `59dac7d999af20e0e9d34a0cfd93ebdd31b2e7ba86e7df6b67875335f599ccb8` |
| `regelsuche-learning/src/test/java/de/regelsuche/evolution/CheckedLearnedSchemaModelTest.java` | `b352f7343c8dbc0cf01b9ebeb83af0ebab4eb8546978b3203ee91db3c26f1c1d` |

Read the supplied plan, review package, progress ledger, source binding, focused results, actual diff, complete new direct test, relevant retention implementation, FunctionExpr copying contract, CheckedApplication call site, existing retention tests, Task 4, and native qualification boundary. `git diff --check` passed. No builds, test executions, source edits, remote actions, or delegation were performed by this reviewer.

## Prioritized findings

**Critical: none. Important: none.**

**Minor coverage note, nonblocking:** the new direct typed-outcome test covers empty, negative, and absent paths through selection. It does not independently exercise every replacement-failure branch, null root, or binary/function out-of-range index. Source review confirms these preserve the original categories and publish their failure results. This is a limit on the test evidence, not an identified defect or a request for broader testing.

## Reviewed behavior

- **Failed acquisition:** `TreePosition.java:100–101,136–137,171–173,225–226` places completed owners into `retainCompleted` before its debits. Although acquisition precedes each local try block, `RetainedOperation.acquire` already publishes the frame, attempts observation after a failed debit, restores the previous frame, and preserves the original throwable. An additional enclosing TreePosition acquisition handler is not required.
- **Failure after allocation/mutation:** the actual mutable parent buffer, Navigation, rebuilt node, argument copy, and typed result are installed into reachable lists/slots before their corresponding work charge. The catch path observes those fields before release. In particular, `237–243` exposes the argument list both before and after replacement and overlaps it with FunctionExpr's immutable list; `208–215` overlaps mutable and frozen parent lists.
- **Release and repeated throwable:** `261–273` guards against self-suppression for both observation and close failures. `Frame.close` clears ownership and restores its predecessor before charging release. A primary failure therefore survives identical repeated throwables, while distinct cleanup failures can be suppressed. A close-only failure propagates after the previously completed allocation has already been observed. Nested unwinding does not leave a frame installed.
- **Sharing and intermediate ownership:** navigation retains the original root and parent frames. Reconstruction retains the preceding rewritten child while publishing its new parent; the returned ancestor is reachable before the next rebuild. Binary siblings and unchanged function arguments retain identity. Empty-path replacement returns the replacement itself with zero copied ancestors.
- **Path semantics:** null root is INVALID_PATH; negative and invalid binary/function indices are INVALID_PATH; descent past a leaf is POSITION_NOT_PRESENT. Failed traversal retains its partially accumulated mutable parents until observation/release. No second navigation, rewrite, or rendered-text authority was introduced.
- **Mathematical work and integration:** CheckedApplication's existing `work.add(patternNodes(schema.target()) + path.size() + 1L)` remains unchanged at line 619. TreePosition only adds execution work/checkpoints, never validation work or another mathematical receipt charge. The integration test compares observed versus historical work and exported moves and requires an actual non-root ReplacementResult during provider execution.
- **Scope:** production edits are confined to TreePosition. No codec call, threshold/baseline alteration, revision promotion, or qualification-flag edit appears in the diff.

## Evidence and declined judgments

The preserved XML independently confirms 9 direct RED assertion failures and 1 corrected integration RED assertion failure. The four focused GREEN XML files report 9 + 1 + 41 + 37 = **88 tests**, with zero failures, errors, or skips; the preserved log says BUILD SUCCESSFUL. The initial integration harness's unrelated export failure is not counted as the corrected RED. These are inspected author-run results, not reviewer-executed tests; the reviewed-byte hashes above bind this report, while the supplied test evidence records its own timestamps.

I decline claims about whole-project green, full public P03 qualification, CI at a future commit, complete P04 ownership, physical heap bounds, performance gains, or P05 readiness. Full Core/Search/Learning validation remains deferred by the parent until the coherent P04 patch; no concrete new risk found here justifies broadening tests now. V6, PARTIAL_ATOMIC_INVENTORY, INCONCLUSIVE, and false completion/within-budget qualification remain unchanged. Other documented atomic regions remain outstanding.
