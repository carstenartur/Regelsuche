# P04 TreePosition ownership slice

Goal: publish and pay actual iterative navigation and ancestor-rebuild temporary ownership through the existing CheckedApplication path.
Architecture: retain the existing TreePosition algorithm; explicitly expose position, parent frames, navigation/results and copied arguments to the active lexical RetainedOperation. Publish completed allocations before charging; preserve primary failure through release. Historical calls remain unobserved. No second rewrite or search.
Tech stack: Java25, Gradle9.7.1, JUnit5, RetainedOperation/RetainedGraph logical inventory.
Spec: docs/superpowers/plans/2026-09-20-work-replacement.md Task4; docs/research/native-expr-qualification.md; parent-authorized Slice2.
Global constraints: V6/partial flags unchanged, no P04 acceptance assertion, no threshold or baseline edits, no codec, untouched sibling sharing; existing Work.add mathematical charge exactly once; no publication/merge.
Review focus: acquisition failure before checkpoint; completed mutable/copy overlap; invalid and absent paths; root replacement; same Throwable repeated by close; existing native cursor historical receipt contract.

1. Add direct ownership/abort behavioral tests. Run RED and existing local occurrence control tests. Expected: new ownership assertions fail because TreePosition has no RetainedOperation publication; existing mathematical behavior stays green.
2. Instrument the existing navigation and reconstruction, retaining actual locals and results. Run direct tests GREEN. Expected: success and typed failures measured; paid attempted allocations visible before failure; all frames release; original failure retained.
3. Prove integration with CheckedApplication by direct observation and the existing model/cursor golden receipt tests. Preserve existing mathematical charge. Run affected suites and project tests; report every failure or resource limitation without widening scope.
4. Independent read-only final review; address important findings via RED/GREEN; commit only verified source/tests. Preserve external evidence and hand off exact commit/commands/limits.
