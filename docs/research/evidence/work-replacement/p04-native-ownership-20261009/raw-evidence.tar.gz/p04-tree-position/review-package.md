# P04 TreePosition whole-slice review

Base ae6b36eae23ed96aed2f0815442ab67634f87065. Uncommitted current worktree /workspace/scratch/4e87c3dfd845/Regelsuche-p04-tree-position (owner will not edit during initial review).

Changed production: regelsuche-core/src/main/java/de/regelsuche/moves/enumerate/TreePosition.java
Tests: new regelsuche-core/src/test/java/de/regelsuche/moves/enumerate/TreePositionOwnershipTest.java; added nested native provider integration in regelsuche-learning/src/test/java/de/regelsuche/evolution/CheckedLearnedSchemaModelTest.java.

Plan/spec: plan.md here; repository docs/superpowers/plans/2026-09-20-work-replacement.md Task4 and docs/research/native-expr-qualification.md.

Review focus: acquisition failure before checkpoint; completed mutable/copy overlap; invalid and absent paths; root replacement; same Throwable repeated by close; existing native cursor historical receipt contract. Preserve sibling identity and no codec, no second rewrite, no revision/partial flag promotion, no math charge duplication. Measure logical work/ownership, not physical heap. Check fields reachable at failed post-allocation charge and close; notice existing RetainedOperation.retainCompleted already observes/cleans acquisition failure.

Evidence: core-red.xml (9 failed before implementation); integration-red-TEST* (missing TreePosition result); green-focused.log and focused-results.json. Full project test still planned after review. First integration harness accidentally exported legacy in an active native scope (unrelated ObjectNode gap); corrected test exports outside scope, reran genuine RED, then GREEN. Ruling: evidence/plan/ledger stays at parent-mandated external path.

No Gradle, source edits, comments or publication by reviewer. Report actionable Critical/Important findings with exact location/behavior, minor notes separately, and any declined judgments. Source implementation should remain smallest coherent slice; P04 remains incomplete.
