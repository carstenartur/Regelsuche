# SDD ledger — plan: /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-tree-position/plan.md

Base ae6b36eae23ed96aed2f0815442ab67634f87065; isolated worktree created and clean. No applicable AGENTS.md found.
Pre-flight: TreePosition replacement is called directly by CheckedApplication.advance; its Work.add remains the only mathematical application charge.
Ruling: retain evidence and ledger outside the repository at the parent-mandated path; no generated repository plan/workspace is introduced.
Supporting TDD writing-good-tests.md resource was unavailable after two exact/relative attempts; core TDD skill read in full and its behavioral-test rules applied.

RED1: core direct6/6 failed on absent ownership; existing occurrence control1/1 passed, red.log. Integration first run exposed unrelated explicit legacy export while scope active; test corrected to export outside native scope. Corrected integration RED: absent actual TreePosition result, not an unsupported payload. No production edits yet.

RED complete:9 direct tests/9 assertion failures; integration1 assertion failure. GREEN: direct9 + occurrence1 + CheckedLearnedSchemaModelTest and nested provider suite all passed. See focused-results.json and preserved XML/log. Production attachment was already direct, so CheckedLearnedSchemaModel production source remains unchanged; its existing Work.add retains the mathematical charge.

Verification ruling (parent instruction): do not run global test now. Full Core/Search/Learning final suites are deferred until the whole P04 patch; this slice uses focused88/88 and independent review. Broaden only for a concrete reviewer risk. This overrides the generic TDD full-suite default; final handoff will not claim whole-project green or P04 acceptance.

Independent whole-slice review completed after the interrupted reviewer produced no
report. No Critical/Important findings. Minor coverage note: not every invalid
replacement category has a separate new direct case; existing categories and
failure publication were verified in source. Ruling: no additional mirroring tests
for this non-defect; preserve the reviewer limitation. Cost if wrong: a currently
unobserved invalid-path branch could regress; existing domain tests and final
Core/Search/Learning qualification remain required. No broad suite or P04
completion claim follows from the 88 focused passes.
