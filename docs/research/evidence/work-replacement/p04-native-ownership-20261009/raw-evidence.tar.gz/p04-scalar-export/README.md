# P04 rendered AST export text: bounded ownership follow-up

Base: `9dd41e639b5f66b45b76dca4bd5e46bf1587f5cc`.
Commit: `5527d1e9ca21cbc9023d7ebb92de9598c6367600`. Tree: `0bf50264d63a94bb9cc0ea1fc6e9ff567151bcbc`.
Only `AstReplayJson.java` and `AstReplayTextOwnershipTest.java` are changed.
No P04 completion flag, measurement revision, or unrelated conversion API was changed.

## Finding and correction

The reachable output path is `NativeMoveSearch.Result.exportLegacy` ->
`NativeExportSession.run` -> result/proof projection ->
`CompiledAstReplayCodec.encodeExpressionUncached` -> `AstReplayJson.write`.
A number or scoped symbol produced a fresh `canonicalText()` String and passed it
to `text(value)` before the owned JSON node adopted it. Validation can debit or
reject while the new text is absent from the owned graph. Its rendering was also
not separately debited from the existing text-validation scan.

The new narrow handoff retains completed rendered text before its first fallible
validation debit, pays the completed rendering once (`1 + length`), and holds it
until the existing JSON node adopts it. Borrowed names and import parsing remain
unchanged. A guarded release preserves primary throwable identity when observation
or nested frame release also fails. The historical inactive output bytes remain
unchanged. This is a separate output boundary, not AST JSON frontier transport.

## Verification

- RED: 5 tests, 5 intended assertion failures, 0 errors; `red.log`, `red-xml`,
  `red-results.json`, `red-src`, `red-source-binding.json`.
- GREEN: 29 tests, 0 failures/errors/skips; `green.log`, `green-xml`,
  `green-results.json`, `green-src`, `green-classes`, `source-binding.json`.
- Five new tests cover successful number/symbol text ownership and byte parity,
  rejected oversized rendering, failed completed-render debit, validation debit
  failure with distinct secondary failures, repeated primary throwable on cleanup,
  and release/reuse of lexical frames.
- Existing selected tests: CompiledAstReplayCodecTest (11),
  CompiledAstReplayBoundaryTest (7), NativeExportAccountingTest (3),
  NativeExportOrderTest (3).
- JDK 25.0.2+10 / Gradle 9.7.1, offline, serial, no build cache, rerun tasks,
  external init script disables incremental Java compilation. Both builds ran
  from this worktree with the shared Gradle home, only after explicit slot handoff.
- No project-wide gate was run here; combined qualification belongs to the parent.
- Existing compiler warnings remain: egraph missing JsonCreator enum metadata;
  NativeMoveProof/NativeVerification varargs calls; MoveSearchVisitsTest unchecked
  operation note. No warning refers to the two changed files.

Shared command prefix:

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --offline --no-daemon --no-build-cache --rerun-tasks --max-workers=1 -I /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-scalar-export/fresh-compile.init.gradle :regelsuche-search:test
```

RED appended `--tests de.regelsuche.search.program.AstReplayTextOwnershipTest`.
GREEN appended that class plus the four existing classes listed above (with their
full `de.regelsuche.search.program` or `de.regelsuche.search.moves` package names).

## Closed read-only conversion inventory at the base

This audit examined only the excluded conversion/export helpers from the earlier
scalar slice, for actual built-in native Primitive/Program/Schema call paths.
It does not make claims about arbitrary user-supplied provider callbacks.

- `canonicalText` in `NativeMoveSearch.Execution.state` ->
  `AstExpressionValidation.renderedText` is already published to a retained
  Counter field before the rendering/validation debit (127, 145-152 at the base).
  `MatcherDescriptor.putText` and `pattern` likewise publish their actual fields
  before payment (205-206, 261 onward). `ExpressionFormatter.NumberConversion`
  already owns its own BigDecimal and rendered text intermediates.
- `fromCanonicalText` is reached by `AstReplayJson.read`/codec decoding and EGraph
  import, not by native typed stepping. The native schema verifier calls
  `replayOccurrence` with typed bindings (CheckedLearnedSchemaModel line 998);
  its legacy BindingReplay performs explicit import decoding separately.
- `fromDecimal`/`toBigDecimal` production callers are Solver-IR,
  DeterministicNumericEquivalence, DeterministicCounterexampleSearchService,
  and SearchBenchmark. No call was found in the qualified built-in native
  Primitive/Program/Schema path. CompiledAstRewriteProgram restricts source
  stages to PreparedAstRewriteTransformationEngine (constructor lines 97-112).
- Native `equalsInteger` call sites use small constants 0/1/2; the pinned JDK25
  `lib/src.zip`, `java.base/java/math/BigInteger.java` confirms `valueOf` reuses
  the -16..16 constants. The variable-long RulePatternBindingSearch use belongs
  to mining; native checked schemas match with core ExprMatcher (line 536).
- Therefore the only demonstrated remaining ownership/work defect in this
  bounded residual list was the rendered-text output handoff corrected here.
  JDK internal arithmetic/rendering temporaries, generic import qualification,
  and unrelated solver/mining APIs were not expanded into new P04 blockers.
