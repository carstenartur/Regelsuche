# P04 proof wrappers and monomial cleanup follow-up

Base: `de2e114111273b5556d5d36f737ea9e3a43743db`.

Verified commits:
- `ce431a338d3cf947dd97d163a44b0fe7ea9b2b90`: same-primary-safe release in existing monomial/matcher owner scopes, with three failing-first conversion/root/rendering regressions.
- `bcac74da690c13f58bc33b29ddc27edf782a867e`: actual provider Optional, accepted/result/final exact-evidence, and verification-export receipt/list/final-result handoffs. Binding validates each existing hash directly, avoiding the temporary String[3].

The working tree is clean. Both GREEN runs tested the final source content subsequently committed above. `source-binding.json` records each source blob, SHA-256, exact tree, and selected XML suite totals. Patches contain only scoped source/test changes. Evidence stays outside the repository.

## RED

`red.log`, `red-tests.patch`, and `red-results/` preserve the test-only run on the base production source: 29 tests, 21 intended failures, 8 passes, no errors or skips. Three monomial cases received IllegalArgumentException (self-suppression) instead of the original DebitAbort. Nine search-export and nine learning-evidence cases exposed missing owners or missing debit-abort boundaries; the pre-existing monomial cases and authorization/hash guards passed.

## GREEN

`green.log`: exit 0, 128 selected tests. `green-matcher-guards.log`: exit 0, 19 selected MatcherAttemptOwnership/MatcherLimitOwnership tests. Total 147 tests, 0 failures, 0 errors, 0 skips. The two matcher class names were initially abbreviated in the first filter; the separate second run uses their full names and supplies their current XML. Only selected suites from the relevant runs were copied; stale Gradle XML was not counted.

Coverage includes all 24 ExactMonomialInference tests; 10 monomial ownership tests; 52 ExprMatcherOwnership, 8 PatternMatcherTemporaryOwnership, 16 MatcherAttemptOwnership and 3 MatcherLimitOwnership tests; 9 new verification-export ownership cases plus 6 adjacent accounting/order tests; 10 new evidence-wrapper cases, 4 proof-boundary tests, registered exact search, and four directly adjacent model authority/export/import tests.

Successful calls preserve matching/math, rendered receipts and verification work fields. Debit failures observe completed actual owners, preserve the original RuntimeException/Error identity, suppress distinct cleanup errors, release all frames, and permit a successful retry. Monomial guards change no normal work calls, branch settlement, bit/exponent/assumption limits or matching path. Provider handoffs do not re-charge binding allocation owned by the model factory or previously completed application mathematics. No new capability authority or cache was added.

Commands used the shared run-gradle25.cjs runner with Gradle 9.7.1/JDK 25.0.2, offline mode, no persistent daemon/configuration cache, one worker, ActiveProcessorCount=2 and Xmx768m. The Gradle slot was serialized and released after process completion. Existing compile warnings concern unrelated deprecated/unchecked calls, the older NativeMoveProof varargs call, and Jackson Mode annotations.

P04 remains V6 / PARTIAL / INCONCLUSIVE. Independent P04 slices and the combined final Core/Search/Learning gate remain parent-owned; these focused runs do not claim a global gate or final review. No remote action, publication, merge or remote comment occurred.
