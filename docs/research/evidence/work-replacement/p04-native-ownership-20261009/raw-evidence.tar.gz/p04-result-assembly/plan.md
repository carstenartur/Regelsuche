# P04 result assembly and available assumptions

Isolated worktree: `Regelsuche-p04-result-assembly`.
Base: `61d468f` (qualified-main continuation, TreePosition, formatter and monomial slices).
Approved identity checkpoint `f8323e49f2758a27d0c5bb168f0cfefb68f97c75` is locally
cherry-picked as `d6c99708f84d6d2f43bd865f79cde5ec783cdbea`. It remains an integration
checkpoint, not a fully qualified implementation. The earlier metadata slice
`3aa54c3` is not cherry-picked and will be integrated by the parent.

## Reproduced finalization failure

The parent recorded two actual native regressions with paid Expr identity:
`NativeRetentionSearchTest.discardedAtomicRewriteStillConsumesRetentionAndWork`
and `anEnumCallbackCannotHideTheRunCreatedGraphDeclaredByItsView`. Both throw
`ResourceLimit` from `ExpressionIdentity.hash -> State.hashCode -> Set.copyOf ->
SearchExecution.Result -> MoveSearchKernel.finish` after a previously recorded
retention failure. The raw evidence is in `p04-expression-identity/first-green.log`
and `first-green-xml/TEST-de.regelsuche.search.moves.NativeRetentionSearchTest.xml`.
This worker inspected both traces before changing production code.

## Implementation contract

- Retain each actual Result collection copy before another copy/hash/checkpoint;
  preserve immutable collection reuse and independently owned input/output graphs.
- Retain actual mutable receipt collection, metadata, admission values and
  capability delta while wrapping and handing off the candidate.
- Settle existing completed assessment work exactly once before its source
  validation can fail; retain it while checking the capability source.
- Use one native available-assumptions implementation for both callers, with
  paid owned set construction, union and short-circuit membership checks.
- A package-local Environment begin/end hook brackets finite result assembly.
  Native observations remain paid and record all failures, but do not rethrow
  an already recorded resource limit during that bounded metadata operation.
  Final ownership/work is checked after construction, with at most one correction
  of success flags/first-hit metadata. No search, matching, verification, new
  frontier expansion or budget refund is permitted in this phase.

Own production files: SearchExecution, MoveSearchKernel (assembly/admission only),
NativeMoveProvider.carries, NativeMoveSearch.Execution (common carries and assembly
hook only), and NativeRetentionSession (the concretely reproduced assembly contract).
Core AST identity and other workers' files remain untouched.

Focused RED tests precede implementation. Gradle is serialized through the parent.
No global suites, remote writes or independent review loop. P04 retains V6 partial
coverage and INCONCLUSIVE qualification pending parent integration gates.
