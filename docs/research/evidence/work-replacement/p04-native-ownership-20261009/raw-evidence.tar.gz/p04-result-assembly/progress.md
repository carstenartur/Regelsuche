# P04 result ownership and bounded finalization

## Initial block

The unchanged identity checkpoint reproduced 19 focused tests / 11 failures: all nine
new ownership/result tests plus the two previously reported actual native retention
aborts. After the finite assembly hook and owners were implemented, 40 focused tests
passed without failures, errors or skips. The tested source is committed as
`c87998b16347058647e75d8c0cf64fa1bbd69c7e` (tree
`e07575b044f4c45660f40cda9f3b5962f3d475e2`). It requires the parent identity checkpoint
`f8323e49f2758a27d0c5bb168f0cfefb68f97c75`, cherry-picked locally as `d6c9970`.
The parent integrated the block as `d60acc3`.

Finalization is finite metadata assembly, with at most one correction of outcome,
completion and hit metadata after all copy/frame-close/hook-close costs are known.
It does not invoke provider generation, mathematical proof replay or frontier work.
Actual output copies remain owned with their inputs and with the attempted result.
The native observer still records failures, peaks and cost during this phase. No
failure becomes an accepted or qualified success. Completed callback/provider work
is settled once into the existing ledger. Assumption checks share one owned set
implementation; canonical assumption semantics are not changed.

## Adjacent producer follow-up

Approved scope: `MoveWitnessPath.steps`, `StagedIncrementalLanes.receipt`,
`SearchExecution.Expansion`, `NativeMoveSearch.Result` provider metadata, and
`QualityResult` witness copies. The finite outer constructor handoff uses the same
session contract only after replay has finished and before final accounting.

The first test attempt had five genuine ownership assertion failures and three
invalid test-fixture failures (`unsupported native provider registration`). Its
log is retained as `producers-fixture-red.log`; it is not the qualification RED.
The corrected explicit rejecting-verifier fixture and the added quality-copy test
produced nine tests / eight ownership failures / one passing existing abort control
on otherwise unchanged production `c87998b`. Evidence: `producers-red.log` and
`producers-red.xml`. No production was changed between those RED attempts.

Producer implementation is committed as `cbd8bc93144000b9625adf172e1a79a974332225` (tree `87b23f709c9f1431d0e13126ab9593e44422683e`).
The serialized focused GREEN passed 65 tests with zero failures, errors or skips.
It includes the 18 new ownership/assembly tests, NativeRetention10, SourceOnly6,
Visits4, Dominance5, Picker5, Capability1, Staged11 and TypedStaged5. Evidence is
`producers-green.log`, `producers-green-xml`, `producers-green-results.json` and
`producer-source-binding.json`. The worktree is clean, and the shared Gradle slot
was handed directly to the scalar export worker. No further optional runs or
scope extensions were performed. P04 remains V6
`PARTIAL_ATOMIC_INVENTORY`, `INCONCLUSIVE`, `complete=false`, `withinBudget=false`.
No global suites, remote writes or independent review loops were run by this worker.
