# P04 proof export ownership

Commit `3a781d03608b14360e0ff70b199e8d5dbfd2c214`, tree `1dfd125304678b9f53dc69c3f92c179b591b8d3d`, base `8fc3bcd7c246e48b9272ed3977b19c43082656ce`.

The existing lexical observer now owns completed UTF-8 input, SHA-256 bytes, hex text and the prefixed hash before their work debit. Defensive ApplicationData path/map copies retain the original inputs until handoff. Evidence creation, canonical JSON/hash, final textual Binding and typed native Binding are observed before returning. Abort cleanup preserves the original throwable.

Mathematical `applicationWork`, canonical JSON field order, SHA-256 format and private capability recognition are unchanged. Known empty/ASCII/Unicode SHA vectors and observed-versus-unobserved real schema exports agree; existing fresh-JVM application replay and forged-binding rejection regressions pass. The explicit learned-schema export charges output separately and leaves the published search receipt unchanged.

## Verification

- Initial RED: 11 tests, 10 expected missing-owner/abort failures, 0 errors/skips; the unchanged public output ledger control passed. See `red.log`, `red-xml/`, `red-summary.json`.
- Native Binding follow-up RED: 101 tests, exactly the new native Binding handoff case failed because its expected debit abort never happened; all previous implementation and existing cases passed. See `native-binding-red.log`, `native-binding-red-xml/`.
- Final GREEN: 101 tests, 0 failures/errors/skips: 12 ownership, 41 checked-schema, 37 native provider accounting, 7 schematic-plan and 4 plan lifecycle. See `green.log`, `green-xml/`, `green-summary.json`.
- `git diff --check` passed before the scoped commit. No remote actions or global test runs.

Command (JDK 25.0.2+10, Gradle 9.7.1, shared cache, one serialized worker):

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2 node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --no-daemon --no-configuration-cache --max-workers=1 :regelsuche-learning:test --tests de.regelsuche.evolution.ProofExportOwnershipTest --tests de.regelsuche.evolution.SchematicProofPlanTest --tests de.regelsuche.evolution.SchematicProofPlanLifecycleTest --tests de.regelsuche.evolution.CheckedLearnedSchemaModelTest
```

## Limits and integration

This is one P04 slice, not a complete search/export qualification. V6, PARTIAL_ATOMIC_INVENTORY, INCONCLUSIVE, complete=false and withinBudget=false remain unchanged. RetainedGraph reports logical ownership, not physical JVM bytes. The parent owns combined qualification and persistence of this evidence. `adjacent-gaps.md` identifies the remaining surrounding wrapper/JSON ownership work; parent delegated those to separate agents. The nativeBinding allocation belongs to this commit and must not be charged again by a provider wrapper.
