# P04 proof export ownership slice

Base: 8fc3bcd7c246e48b9272ed3977b19c43082656ce. Worktree: Regelsuche-p04-proof-export.

Use the existing RetainedOperation/retainCompleted ownership contract. No new proof, authority, cache, or frontier implementation. Preserve historical SHA-256 UTF-8 bytes and canonical evidence, frozen application work, and P04 partial flags.

1. RED: Completed UTF-8, digest, hex, bound hash, immutable path/map copies and binding become invisible on missing ownership. Existing bytes and real restored-schema export serve as semantic controls.
2. Implement only SchematicProofPlan.hash and CheckedLearnedSchemaModel ApplicationData/evidence/renderEvidence handoffs. Observe actual products before post-allocation work debit; retain primary abort when cleanup also fails.
3. GREEN: Focused ownership tests, schematic plan/lifecycle tests, real checked-schema import/export regressions. Parent owns final combined suites, review and CI.
4. Bind source commit and retain every RED/GREEN log/XML. Report residual wrappers beyond this slice explicitly.

Scope note: logical RetainedGraph units describe owned Java-level objects/text/references, not JVM heap bytes or JDK internals. Export cannot retroactively qualify a partial search.

Parent extended the coherent slice to ApplicationData, evidence issuance, and renderEvidence. Tests now include the actual public export of a selected learned/restored schema, with an unchanged published search receipt.

Known adjacent gap, outside the two production files: RetainedJson.ObjectValue and ArrayValue constructors call work(2) before their caller can publish the returned object. A caller owner cannot observe the object if this constructor-internal debit fails. The broader RetainedJson class remains partial; this slice does not claim a complete export inventory.

RED completed: 11 tests, 10 expected missing-owner/abort failures, 0 errors/skips. The public selected-schema export comparison already passes on the baseline. Production changes started only after this RED. Parent delegated the RetainedJson constructor gap to the JSON agent; no duplicate implementation here.
