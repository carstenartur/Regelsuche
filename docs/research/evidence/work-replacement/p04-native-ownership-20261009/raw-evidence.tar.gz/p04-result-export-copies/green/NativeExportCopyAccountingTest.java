package de.regelsuche.search.moves;

import de.regelsuche.ast.*;
import de.regelsuche.retention.*;
import de.regelsuche.transform.*;
import java.util.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/** Constructor copy costs belong to the native export caller, not the historical constructors. */
class NativeExportCopyAccountingTest {
    private static final Expr X=new VariableExpr("x");
    private static final Expr SOURCE=new BinaryExpr(X,BinaryOperator.ADD,new NumberExpr(0));
    private enum Value implements NativeStateValue,RetainedGraph.View {
        INSTANCE;
        @Override public Assessment evaluate(TypedMoveSearch.State state,TypedMoveSearch.Context context){
            return state.expression().equals(SOURCE)?new Assessment(3,1,1,0,
                Map.of("zero",new Capability("zero",SOURCE,"",SOURCE,X))):Assessment.EMPTY;
        }
        @Override public void retainedReferences(RetainedGraph.Visitor visitor){}
    }
    private static NativeMoveSearch.Result source(MoveSearch.Scheduling scheduling){
        var a=PatternExpr.var("A");
        var rule=new PatternRewriteRule("zero",PatternExpr.op(BinaryOperator.ADD,a,PatternExpr.num(0)),a);
        var descriptor=new MoveProvider.Descriptor("zero","zero",SearchMove.SourceKind.PRIMITIVE,
            SearchMove.ProofStrength.REPLAYABLE,List.of(),SearchMove.ValueEvidence.UNKNOWN,"copy-export/v1");
        var provider=new NativeMoveSearch.Primitive(descriptor,new AstRewriteTransport(List.of(rule),32,32));
        var result=new NativeMoveSearch().search(new NativeMoveSearch.Problem(SOURCE,TypedMoveSearch.Context.frozen(X),
            List.of(provider),MoveSearch.Mode.FAST,scheduling,new MoveSearch.Budget(2,2,0,10,10_000_000),
            NativeMovePriorityPolicy.INVENTORY_ORDER,NativeMoveSearch.ZeroScore.INSTANCE,Value.INSTANCE),SearchContinuationContract.PATH_SENSITIVE);
        assertEquals(MoveSearch.Outcome.TARGET_REACHED,result.observedOutcome());return result;
    }
    private static List<Object> refs(RetainedGraph.View owner){
        var values=new ArrayList<Object>();
        owner.retainedReferences(new RetainedGraph.Visitor(){
            @Override public void reference(Object value){values.add(value);}
            @Override public void requireExact(Object value,Class<?> type){assertEquals(type,value.getClass());}
        });return values;
    }
    private static List<Object[]> frames(RetainedOperation scope){
        var result=new ArrayList<Object[]>();if(scope==null)return result;
        Object current=refs(scope).get(2);
        while(current instanceof RetainedOperation.Frame frame){
            var owned=refs(frame);result.add((Object[])owned.get(2));current=owned.get(1);
        }return result;
    }
    private static boolean at(String method){return StackWalker.getInstance().walk(stack->stack.anyMatch(frame->
        frame.getClassName().equals(SearchExecution.class.getName()) && frame.getMethodName().equals(method)));}
    private enum Kind { RESULT,STAGED,LANES,STATE }
    private record Copy(Kind kind,Object source,Object target,long units){
        long expected(){return source==target?0:1L+(source instanceof Map<?,?> map?map.size():((Collection<?>)source).size());}
    }
    private record AssessmentCopy(Map<?,?> source,StateValue.Assessment target,List<Long> debits){}
    private static final class Abort extends RuntimeException{}
    private static final class Probe implements RetainedOperation.Sink {
        NativeMoveSearch.Result source;RetainedOperation scope;RetainedJson.Scope json;
        final List<Copy> copies=new ArrayList<>();
        final List<AssessmentCopy> assessments=new ArrayList<>();
        final Abort primary=new Abort();
        boolean abortCopy;Copy stopped;
        long work;
        @Override public void retainedReferences(RetainedGraph.Visitor visitor){visitor.reference(source);visitor.reference(scope);visitor.reference(json);}
        @Override public void executionWork(long units){
            work=Math.addExact(work,units);
            if(!at("completed"))return;
            var frames=frames(scope);
            for(var values:frames)if(values.length==3 && values[0] instanceof NativeStateValue.Assessment
                && values[1] instanceof Map<?,?> input && values[2] instanceof Object[] pending
                && pending[3] instanceof StateValue.Assessment result){
                var observed=assessments.stream().filter(item->item.target()==result).findFirst().orElseGet(()->{
                    var item=new AssessmentCopy(input,result,new ArrayList<>());assessments.add(item);return item;});
                observed.debits().add(units);return;
            }
            if(!at("copied"))return;
            for(var values:frames)if(values.length==2 && values[0] instanceof TypedMoveSearch.State original
                && values[1] instanceof Object[] pending && pending[1] instanceof MoveState result){
                copies.add(new Copy(Kind.STATE,original.capabilities(),result.capabilities(),units));return;
            }
            for(var values:frames)if(values.length>=7 && values[0] instanceof Map<?,?> && values[6] instanceof Object[] pending){
                Object target=pending[2];Copy copy;
                if(pending[1] instanceof MoveSearch.Result result){
                    Object input=target==result.witness()?values[1]:target==result.events()?values[2]
                        :target==result.reachedStates()?values[3]:target==result.deadEndStates()?values[4]
                        :target==result.stateAssessments()?values[0]:null;
                    assertNotNull(input,"copy receipt must identify one actual result field");
                    copy=new Copy(Kind.RESULT,input,target,units);
                }else if(pending[0] instanceof StagedIncrementalMoveExecution staged){
                    Object input=target==staged.providers()?refs(source).get(2):target==staged.expansions()?values[5]:null;
                    assertNotNull(input);copy=new Copy(Kind.STAGED,input,target,units);
                }else if(pending[1] instanceof StagedIncrementalMoveExecution.Expansion expansion){
                    var receipts=(List<?>)pending[3];assertEquals(1,receipts.size(),"single root expansion fixture");
                    var receipt=(SearchExecution.Expansion<?>)receipts.getFirst();
                    assertSame(expansion.lanes(),target);copy=new Copy(Kind.LANES,receipt.lanes(),target,units);
                }else throw new AssertionError("unknown completed copy product");
                copies.add(copy);
                if(abortCopy && stopped==null && copy.kind()==Kind.RESULT){
                    stopped=copy;
                    assertTrue(graph(scope).contains(copy.source()));assertTrue(graph(scope).contains(copy.target()));
                    throw primary;
                }
                return;
            }
            throw new AssertionError("native copy receipt has no active actual owner");
        }
        @Override public void validationWork(long units){fail("export is not new mathematical authorization");}
        @Override public void checkpoint(){work=Math.addExact(work,RetainedGraph.measure(this).work());}
    }
    private static Set<Object> graph(Object root){
        var seen=Collections.newSetFromMap(new IdentityHashMap<Object,Boolean>());var todo=new ArrayDeque<Object>();
        if(root!=null)todo.add(root);
        while(!todo.isEmpty()){
            var value=todo.removeFirst();if(!seen.add(value))continue;
            Collection<?> children=value instanceof RetainedGraph.View view?refs(view)
                :value instanceof Map<?,?> map?map.entrySet().stream().flatMap(entry->java.util.stream.Stream.of(entry.getKey(),entry.getValue())).toList()
                :value instanceof Collection<?> collection?collection:value instanceof Object[] array?Arrays.asList(array):List.of();
            for(var child:children)if(child!=null)todo.add(child);
        }return seen;
    }
    private static MoveSearch.Result export(Probe probe){
        try(var scope=RetainedOperation.open(probe);var json=RetainedJson.open()){
            probe.scope=scope;probe.json=json;return probe.source.projectLegacy();
        }
    }
    private static List<Copy> copies(Probe probe,Kind kind){return probe.copies.stream().filter(copy->copy.kind()==kind).toList();}
    private static void exact(List<Copy> copies){for(var copy:copies)assertEquals(copy.expected(),copy.units(),copy.kind().name());}
    @Test void finalResultPaysAllFiveActualContainerCopiesOnce(){
        var probe=new Probe();probe.source=source(MoveSearch.Scheduling.STAGED);
        var output=export(probe);var copies=copies(probe,Kind.RESULT);
        assertEquals(5,copies.size());exact(copies);
        assertEquals(output.witness().size()+output.events().size()+output.reachedStates().size()
            +output.deadEndStates().size()+output.stateAssessments().size()+5L,copies.stream().mapToLong(Copy::units).sum());
        assertTrue(copies.stream().allMatch(copy->copy.source()!=copy.target()),"these inputs are the actual mutable aggregate builders");
    }
    @Test void stagedCopiesUseActualIdentityAndReuseTheFrozenLaneLists(){
        var probe=new Probe();probe.source=source(MoveSearch.Scheduling.STAGED_INCREMENTAL);export(probe);
        assertEquals(2,copies(probe,Kind.STAGED).size());exact(copies(probe,Kind.STAGED));
        var lanes=copies(probe,Kind.LANES);assertEquals(1,lanes.size());exact(lanes);
        assertSame(lanes.getFirst().source(),lanes.getFirst().target());assertEquals(0,lanes.getFirst().units());
    }
    @Test void immutableStateCapabilitiesAreObservedAsReuseWithoutCopyCharge(){
        var probe=new Probe();probe.source=source(MoveSearch.Scheduling.STAGED);export(probe);
        var copies=copies(probe,Kind.STATE);assertFalse(copies.isEmpty());exact(copies);
        for(var copy:copies){assertSame(copy.source(),copy.target());assertEquals(0,copy.units());}
    }
    @Test void assessmentPaysTheActualImmutableWrapperBackingMapAndEntries(){
        var probe=new Probe();probe.source=source(MoveSearch.Scheduling.STAGED);export(probe);
        assertEquals(2,probe.assessments.size());
        for(var copy:probe.assessments){
            assertInstanceOf(RetainedSortedMap.class,copy.target().capabilities());
            Object backing=refs((RetainedGraph.View)copy.target().capabilities()).getFirst();
            assertInstanceOf(TreeMap.class,backing);assertNotSame(copy.source(),backing);assertEquals(copy.source(),backing);
            assertEquals(List.of(1L,copy.source().size()+2L),copy.debits(),"one assessment object, then actual wrapper, TreeMap and entries");
        }
    }
    @Test void copyDebitAbortStillOwnsBothConstructorInputsAndCompletedOutput(){
        var probe=new Probe();probe.source=source(MoveSearch.Scheduling.STAGED);probe.abortCopy=true;
        assertSame(probe.primary,assertThrows(Abort.class,()->export(probe)));
        assertNotNull(probe.stopped);assertEquals(probe.stopped.expected(),probe.stopped.units());
        assertEquals(0,RetainedGraph.measure(probe.scope).retained().nodes());assertEquals(0,RetainedGraph.measure(probe.json).retained().characters());
        assertFalse(RetainedOperation.isObserved());assertFalse(RetainedJson.active());
    }
    @Test void historicalConstructorsKeepTheirWorkContractAndImmutableInputReuse(){
        var output=source(MoveSearch.Scheduling.STAGED).projectLegacy();var probe=new Probe();
        try(var scope=RetainedOperation.open(probe)){
            probe.scope=scope;long before=probe.work;
            var copy=new MoveSearch.Result(output.outcome(),output.witness(),output.events(),output.reachedStates(),output.deadEndStates(),
                output.metrics(),output.completeBoundedRelation(),output.stateAssessments(),null,null);
            var providers=List.<StagedIncrementalMoveExecution.Provider>of();var expansions=List.<StagedIncrementalMoveExecution.Expansion>of();
            var staged=new StagedIncrementalMoveExecution("work","order",providers,expansions);
            assertEquals(before,probe.work);assertSame(output.witness(),copy.witness());assertSame(output.events(),copy.events());
            assertSame(output.reachedStates(),copy.reachedStates());assertSame(output.deadEndStates(),copy.deadEndStates());
            assertSame(output.stateAssessments(),copy.stateAssessments());assertSame(providers,staged.providers());assertSame(expansions,staged.expansions());
        }
    }
}
