# P04 final export constructor copy receipts

Commit `e780be29433eca6d9fd27070c71e1e37db07c9bd`, tree `1f3ee5efb47daa4ff0b080dee02b8b3d1048fbca`, base `0e9c83f780e6b3e5a231bf3a3150c8cbda104c8a`. Worktree clean.

This narrow follow-up fixes the confirmed aggregate-export review finding: the final legacy constructors copy containers after mutable export builders have already been charged. Only the native callers in `NativeMoveSearch.projectLegacy` and its State/Assessment export helpers change. The legacy constructors, search/replay algorithm and revision constants are unchanged.

The existing `SearchExecution.copied` rule settles the five actual Result field copies and the Staged/Expansion lists. A different returned container pays its entry count plus one container unit; an identical input/output reference pays zero copy units. Every completed result and both original/copied containers are owned before the debit. The assessment additionally pays its actual RetainedSortedMap wrapper, newly allocated TreeMap and entries. The assessment record's existing one-unit charge is retained exactly once. MoveState's capabilities are checked against the actual original set; assumption-normalization charges are not repeated.

RED: six tests, five intended failures, no errors/skips. Missing Result/Staged copy receipts, the absent copy-debit abort boundary and assessment receipt `[1]` instead of `[1,3]` were detected. The legacy-constructor work/reuse control passed before the fix.

GREEN: **20 tests, zero failures/errors/skips**, with fresh `--rerun-tasks` compilation and `options.incremental=false`: six copy accounting, eight component ownership, three existing output accounting and three chronology tests. The latter retain the frozen pre-fix projection hash, complete projection/ordering checks, codec counts and unchanged published search account. No tests were weakened or filtered after RED.

The new tests compare actual constructor argument/output identities, require exactly five final Result copy receipts, inspect the assessment wrapper's real backing TreeMap, prove immutable lane/set reuse at zero copy units, and abort after a real copy debit while both input and output remain owned. Raw historical Result/Staged constructors still emit no native receipt and reuse already immutable inputs.

All failed attempts, selected XML, source snapshots and the exact command remain bound here. No additional or global suites were run. The Gradle slot was explicitly released after GREEN so the parent can run its combined suites. P04 partial flags remain false for full accounting/budget qualification; the parent's V7/V3 revision is deliberately outside this commit.

Final command:

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2 node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --no-daemon --no-configuration-cache --max-workers=1 --rerun-tasks --init-script /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-result-export-copies/fresh-compile.init.gradle :regelsuche-search:test --tests de.regelsuche.search.moves.NativeExportCopyAccountingTest --tests de.regelsuche.search.moves.NativeResultExportOwnershipTest --tests de.regelsuche.search.moves.NativeExportAccountingTest --tests de.regelsuche.search.moves.NativeExportOrderTest
```
