# P04 scoped monomial conversion ownership

Verified commit: `ab87fd8962fe2a6c14e89175a1256a39ba8ef144`, tree `648403fed87ad655c5334d30111386361b96c895`.
Base: `14c10d4439f44a35ae64aede5b3db536ae6ea124`.

The fixed review path is A^2 matching a scoped x^4 and rendering scoped x^2. `BoundedExactMonomial.factorExpression` already owns the completed VariableExpr; the previously invisible work happened inside its `SymbolId.fromIdentifier -> fromCanonicalText` call. The only production edit is SymbolId.java. Active conversions now own and pay their actual hex/UUID/canonical substring/string products, parsed UUID, parsed SymbolId, workspace and handoff before a debit can fail. Existing validation, exception types/messages, namespaces/ordinals and unobserved conversion paths are preserved. Monomial mathematics, scope equality, limits and branch accounting were not changed.

## Failing-first evidence

- `red.log`, `red-test.java`, `red-results/`: 11 tests, 11 intended failures on base production. The positive case could not observe intermediate products; ten actual-debit abort cases (five stages, same/distinct cleanup failure) did not abort because the intermediate owners were missing.
- One additional compatibility test was added after that RED to compare accepted identities and rejected input exception classes/messages under observed and unobserved conversion. It is not described as a failing-first test.

## Integration test lifetime correction

The first selected GREEN attempt (`green-initial.log`) passed every new scoped-symbol test but failed two old monomial ownership assertions: 59/61 passed. `baseline-observer-lifetime.log` repeats those two failures with the original base SymbolId.java, proving they did not arise from the conversion fix.

Those tests enclosed test fixture creation and result assertions in the observed operation. Integrated scalar construction and expression equality now emit checkpoints of their own before/after the matcher, when its input owner correctly does not exist. Moving assertions alone was insufficient (`green-assertions-only.log`, 59/61). The final test-only correction constructs each numeric pattern before opening the scope and checks returned values after closing it. The observer and production owner lifetimes are unchanged.

## Final verification

`green.log`: BUILD SUCCESSFUL, exit 0. Fresh selected XML totals: 61 tests, 0 failures, 0 errors, 0 skips.

- ExactMonomialScopedSymbolOwnershipTest: 12
- ExactMonomialOwnershipTest: 10
- ExactMonomialInferenceTest: 24
- SymbolIdTest: 4
- ScopedSymbolIdentityTest: 4
- SymbolicExpressionCodecTest: 7

The failure cases verify actual completed-owner visibility, original exception identity under repeated identical cleanup failures, suppression of distinct cleanup failures, complete release and a successful retry. The existing tests preserve scoped identity, exact inference and export/parse behavior.

All commands used the established run-gradle25.cjs runner, Gradle 9.7.1/JDK 25.0.2, --offline --no-daemon --no-configuration-cache --max-workers=1, ActiveProcessorCount=2 and Xmx768m. No parallel Gradle process was started; the slot was released after final completion. `git diff --cached --check` passed before commit. `source-binding.json` binds the exact source blobs and XML hashes; `verified.patch` contains the three scoped files. The worktree is clean.

V6 / PARTIAL / INCONCLUSIVE and all false qualification flags remain unchanged. The full Core/Search/Learning and public-corpus gate remains parent-owned. No remote action or publication occurred.
