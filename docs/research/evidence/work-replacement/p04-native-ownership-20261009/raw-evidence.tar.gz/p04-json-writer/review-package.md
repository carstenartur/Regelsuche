# P04 JSON writer bounded slice

Commit: `1165658c0c2c2c95e7a5d9bcab7fb8ff440aa1ca`, on accepted formatter base `084b9abe10bcbc1e7002a78e740886ea54202283`. Isolated worktree: `/workspace/scratch/4e87c3dfd845/Regelsuche-p04-formatter-growth`; clean after commit. No publication or merge was performed.

The existing writer now pays append/input/escape/number/output/flush work under active RetainedOperation. Actual writer state, borrowed values, completed numeric strings, output strings, and flush chunks are observed with existing lexical frames. Checkpoints remain bounded at operation/chunk boundaries; failed mutation debits observe the current live state. Internal StringBuilder arrays remain JDK internals. Stream callback state is observed before chunk release; original callback exceptions survive observation and cleanup failures, including identical throwable reuse. Inactive historical bytes and existing String-based callback/flush/close contracts remain intact.

Parent-authorized extensions are narrow: RetainedJson ObjectValue/ArrayValue publish their completed nodes and children before the existing constructor debit; StructuralMoveContext key delegates output-copy accounting to JsonWriter and typedKey separately retains/pays its completed prefix concatenation. No changes to context collection/hash/degree, search, frontier, proof export, qualification, or JSON engines/libraries.

## Evidence

- `baseline.log` / baseline XML: five existing streaming tests passed before production edits.
- `red-recompiled.log` / matching XML: eight initial writer tests, seven failures; thirteen RetainedJson tests, two new constructor failures; five existing streaming tests pass. Original `red.log` included stale node test bytecode and is not node RED evidence.
- `overlap-and-context-red.log`: stale main bytecode detected; retained for infrastructure diagnosis, not implementation verification.
- `clean-main-red.log` / selected XML: source-matched 36-test RED, five failures. Three writer regressions cover numeric temporary/source overlap, historical null conversion text, and identical-primary cleanup. Two context tests cover exact historical/typed bytes, duplicate copy booking, and both strings surviving failed prefix debit.
- `green-focused.log` / `green-focused-xml`: fresh 36 selected tests, zero failures/errors/skips. Writer 11; Streaming 5; RetainedJson 13; StructuralMoveContext 2; TypedHistoryMovePolicy 5.
- `source-binding.json`, `focused-results.json`, and `*.javap.txt`: exact committed file hashes, compiled hashes/behavior, and timestamped selected XML. Unselected old formatter XML lives in `unselected-prior-xml` and is excluded from the 36-test result.

The final serial Gradle command, from the isolated worktree, was:

```sh
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2 node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs --offline --no-daemon --no-configuration-cache --no-build-cache --max-workers=1 --rerun-tasks --continue --init-script /workspace/scratch/4e87c3dfd845/evidence-20261009/p04-json-writer/nonincremental-java.init.gradle -Dorg.gradle.jvmargs=-Xmx768m :regelsuche-core:test --tests de.regelsuche.json.JsonWriterOwnershipTest --tests de.regelsuche.json.StreamingJsonWriterTest --tests de.regelsuche.retention.RetainedJsonTest :regelsuche-learning:test --tests de.regelsuche.inventory.StructuralMoveContextOwnershipTest --tests de.regelsuche.inventory.TypedHistoryMovePolicyTest
```

The external init script disables Java incremental compilation. Merely `--no-build-cache --rerun-tasks` had retained stale existing main classes. Prior class/compile-state directories were preserved here; no prior evidence was deleted. JDK 25.0.2 and Gradle 9.7.1 used the existing runner. Final build exit 0, 24 tasks executed, 30 seconds. Existing deprecation/unchecked, Jackson annotation dependency, and search inexact-varargs warnings remain; this slice does not alter those regions.

Only six scoped production/test files are committed. Full combined review, core/search/learning gates and native qualification remain parent-owned. V6 / PARTIAL_ATOMIC_INVENTORY / INCONCLUSIVE / complete=false / withinBudget=false remain unchanged. Gradle slot was released directly to Scalar after the verified commit.
