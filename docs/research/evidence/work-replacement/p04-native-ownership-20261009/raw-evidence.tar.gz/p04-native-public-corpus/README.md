# Public native P03 driver preparation

Scoped test-only commit: `ee387046f4a7470dedb006fc87ad922899eb9248`. Base: `551e4b3cb04538e9e0fede69329a00dd22ca3c3f`. Production files are untouched.

The driver includes all 24 public search cases and both quality cases at their historical budgets, then separately at the declared diagnostic ceiling for both adapters. All eight expression identity pairs, three state pairs, ten cursors and two negative replays are included. It uses actual training/restoration, native providers and the existing search kernel. Every failed row is preserved.

Verified so far: one-file javac syntax/API compile against the unchanged, hashed 2,705 GREEN classes from proof-export commit `3a781d03608b14360e0ff70b199e8d5dbfd2c214`; exit 0. This does not compile or qualify the final combined production tree. The Java source SHA256 in that compile matches the scoped commit. Four Python report-boundary tests pass. The added missing-codec regression failed before the report fix and passed afterward. All commands/source/toolchain/dependency/class bindings and logs are retained.

The full two-fresh-JVM matrix has NOT RUN. It remains reserved for the parent coordinator's final combined source and serialized slot. No parity, cost or P04 acceptance claim follows from preparation. See the committed harness README for the exact full-run command and boundaries. `accountingComplete`, `withinBudget`, and economic qualification remain false.
