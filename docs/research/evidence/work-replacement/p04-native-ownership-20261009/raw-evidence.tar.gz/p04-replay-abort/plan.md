# P04 final review: replay abort receipts and objective delegation

Base: `34f2e93c05258818938a3c22a41dfaa2be24e3af`.
Worktree: `Regelsuche-p04-replay-abort`, branch `codex/p04-replay-abort-20261009`.
Approved scope: `NativeMoveSearch.replay`, its local receipt ownership, focused
regressions; narrow additional `MoveSearchObjective.finish` / `MoveWitnessPath`
materialization overlap. No export/Result constructor changes, no further audit.

## Root cause inspected

The current replay catches `SearchExecution.ResourceLimit` only directly around
`execution.verify`. Paid Expr equality also runs in root, lineage, complete checked
receipt, and endpoint comparison. An abort in any of these places escapes instead
of returning a replay receipt; a successfully returned `checked.work` is then lost
with the whole outer result. The fresh checked wrapper and producer binding are
also absent from the live owner graph during equality. The installed schema checker
is a real producer of such fresh exact receipts, as confirmed by the reviewer.

`MoveSearchObjective.finish` adds historical `witness.size()+1` materialization to
ledger.search. Under the active native observer, `MoveWitnessPath.steps` already
owns and bills the mutable builder and the immutable copy (`size()+1`) through the
same sink. Inactive legacy execution must keep its historical receipt unchanged.

## Prepared RED

- NativeReplayAbortTest: real existing private replay and real Execution invoked
  at their existing boundary; actual paid Expr comparisons are interrupted by an
  observer at root, second lineage, first and second receipt comparison, endpoint,
  and an empty witness. Expected work preserves completed 37-unit checks, both
  74 units, or 37 + 13 units transferred from an interrupted second verify.
- Full fresh receipt/producer/step ownership during comparison; unaccounted replay
  keeps its original exception; foreign root, lineage and endpoint remain errors.
- NativeReplayReceiptFailureTest: real target and source-only entrypoints use the
  real primitive verifier. Its second completed call returns a fresh structural
  receipt after allocating a retained 50-node graph. The next replay observation
  must preserve the completed verification work and the attempted search result.
- MoveSearchObjectiveWorkTest: nonempty n=1 and n=3 paths compare direct producer
  sink work, objective sink work and delegated ledger work independently; legacy
  n+1 and witness chronology remain exact.

No production changes before the serialized RED. The first test run waits for the
parent's explicit Gradle release. No global tests or remote actions. V6 coverage
and public qualification remain PARTIAL_ATOMIC_INVENTORY / INCONCLUSIVE.
