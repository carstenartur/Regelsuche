# P04 replay review fix

Commit `af6755267539cdf7f0168fc5e122e518e852efcf`, tree `8e79821d6e3bc9164400b60166b343f45336dcf8`, isolated base
`34f2e93c05258818938a3c22a41dfaa2be24e3af`.

Only `NativeMoveSearch.replay` and `MoveSearchObjective.finish` changed in production.
No export/Result constructor, search ordering, mathematical checker, global budget
or qualification policy changed. Worktree is clean. Gradle slot was returned to
parent immediately after GREEN; no global tests or remote actions ran here.

## Reproduction and verification

- RED: 14 tests, 10 actual failures, 4 passing controls. Test-only sources and
  unchanged production base are bound in `red-binding.json`; logs and XML retained.
- Both real Native target/quality entrypoints failed after independent verification
  returned successfully: `NativeVerification.equals -> Primitive/Step.equals ->
  VariableExpr.equals -> ExpressionIdentity.same -> ResourceLimit`. These exact
  traces are in `red-xml/TEST-de.regelsuche.search.moves.NativeReplayReceiptFailureTest.xml`.
- Additional real paid comparison boundaries: root, second lineage, first/second
  receipt, endpoint and empty witness. Completed work is 37 or 74; interrupted second
  verification returns prefix 37 plus unreturned 13, once each. Fresh complete receipt,
  producer and source step are visible while receipt equality runs.
- Controls preserve original unaccounted exception identity and true foreign-source,
  lineage and endpoint errors; no resource limit is treated as mathematical rejection.
- Nonempty objective paths n=1,3 independently compare producer sink, objective sink
  and delegated ledger. Observed materialization delegates zero; inactive legacy
  keeps n+1, its objective-score work and witness chronology.
- GREEN: 48 tests, zero failures/errors/skips. All 14 new cases plus existing native
  SourceOnly6, Retention10, ResultAssembly9 and FinalProducer9. See `green.log`,
  `green-xml`, `green-results.json`, `green-binding.json`, and `review-fix.diff`.

Replay now owns its whole input and fresh returned check while paid comparisons run.
Completed check work is settled before observing/comparing the receipt. One enclosing
ResourceLimit boundary captures root, lineage, verifier, receipt, endpoint and frame
cleanup; it marks native accounting incomplete and transfers only still-unreturned
work. Other mathematical/structural failures retain their original meaning.

P04 remains V6 `PARTIAL_ATOMIC_INVENTORY` / `INCONCLUSIVE`; this scoped fix is not a
claim of full atomic inventory, total economic benefit, or P01–P12 completion.
