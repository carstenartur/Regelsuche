from pathlib import Path
import os, subprocess, shutil
root=Path('/workspace/scratch/4e87c3dfd845/Regelsuche-p04-tree-position')
evidence=Path('/workspace/scratch/4e87c3dfd845/evidence-20261009/p04-expression-identity')
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
production=[p for p in tracked if '/src/main/' in p]
production.append('regelsuche-core/src/main/java/de/regelsuche/ast/ExpressionIdentity.java')
backup={p:(root/p).read_bytes() for p in production}
for path,data in backup.items():
    destination=evidence/'revised-red-production-backup'/path
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
try:
    for p in production:
        old=subprocess.run(['git','show','HEAD:'+p],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
        if old.returncode==0:(root/p).write_bytes(old.stdout)
        else:(root/p).unlink()
    shutil.rmtree(root/'regelsuche-core/build/classes/java/main',ignore_errors=True)
    shutil.rmtree(root/'regelsuche-core/build/classes/java/test',ignore_errors=True)
    env=dict(os.environ,GRADLE_USER_HOME='/workspace/scratch/4e87c3dfd845/gradle-home',JAVA_TOOL_OPTIONS='-XX:ActiveProcessorCount=2')
    with (evidence/'revised-native-red.log').open('w') as log:
        run=subprocess.run(['node','/workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs','--no-daemon','--no-configuration-cache','--no-build-cache','--rerun-tasks','--max-workers=1',':regelsuche-core:test','--tests','de.regelsuche.ast.ExpressionIdentityAccountingTest'],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
    shutil.copy(root/'regelsuche-core/build/test-results/test/TEST-de.regelsuche.ast.ExpressionIdentityAccountingTest.xml',evidence/'revised-native-red-test.xml')
    shutil.copy(root/'regelsuche-core/src/test/java/de/regelsuche/ast/ExpressionIdentityAccountingTest.java',evidence/'revised-native-red-test.java')
    print('revised RED exit',run.returncode)
finally:
    for p,data in backup.items():(root/p).write_bytes(data)
