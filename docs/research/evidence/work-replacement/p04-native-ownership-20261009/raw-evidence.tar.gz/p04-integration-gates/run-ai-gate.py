from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tempfile, time

root = Path('/workspace/scratch/4e87c3dfd845/Regelsuche-p04-tree-position')
commit, output_name = sys.argv[1:]
output = Path(__file__).parent / output_name
output.mkdir(exist_ok=False)
parent = Path(tempfile.mkdtemp(prefix='regelsuche-p04-ai-', dir='/tmp'))
checkout = parent / 'checkout'
subprocess.run(['git', 'worktree', 'add', '--detach', str(checkout), commit], cwd=root, check=True)
runner = Path('/workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs')
initializer = Path('/workspace/scratch/4e87c3dfd845/evidence-20261009/pr1076-p04-validation/scripts/extractor-javac25.init.gradle')
command = ['node', str(runner), '--no-daemon', '--no-configuration-cache', '--max-workers=1',
    '--console=plain', '--stacktrace', '-I', str(initializer), '-PenableAiKnowledgeExtractor=true',
    '-PuseLocalAiKnowledgeExtractor=true',
    '-PaiKnowledgeExtractorCheckout=/workspace/scratch/4e87c3dfd845/ai-knowledge-extractor', 'aiKnowledgeCheck']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
binding = {'source': commit, 'checkout': str(checkout), 'command': command,
    'runnerSha256': sha(runner), 'initSha256': sha(initializer),
    'baselineSha256': sha(checkout/'ai-knowledge/complexity-baseline.json')}
(output/'source-binding.json').write_text(json.dumps(binding, indent=2)+'\n')
environment = dict(os.environ, GRADLE_USER_HOME='/workspace/scratch/4e87c3dfd845/gradle-home',
    AI_KNOWLEDGE_EXTRACTOR_ENABLED='true')
environment['JAVA_TOOL_OPTIONS'] = environment.get('JAVA_TOOL_OPTIONS', '')+' -XX:ActiveProcessorCount=2'
started = time.time()
with (output/'gradle.log').open('w') as log:
    result = subprocess.run(command, cwd=checkout, env=environment, stdout=log, stderr=subprocess.STDOUT)
reports = {}
for directory in ['build/ai-knowledge', 'build/reports/quality']:
    for path in (checkout/directory).glob('*'):
        if path.is_file() and path.suffix in ['.json', '.md']:
            destination = output/'reports'/directory
            destination.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination/path.name)
            reports[str(path.relative_to(checkout))] = {'sha256': sha(path), 'fresh': path.stat().st_mtime >= started}
summary = {'exitCode': result.returncode,
    'sourceStatus': subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout, text=True),
    'reports': reports}
(output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps({'exitCode': result.returncode, 'sourceStatus': summary['sourceStatus'],
    'reports': len(reports), 'allReportsFresh': all(r['fresh'] for r in reports.values())}))
sys.exit(result.returncode)
