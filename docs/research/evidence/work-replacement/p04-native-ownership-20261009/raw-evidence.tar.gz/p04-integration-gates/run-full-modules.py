from pathlib import Path
import hashlib, json, os, shutil, subprocess, sys, tempfile, time, xml.etree.ElementTree as ET

root = Path('/workspace/scratch/4e87c3dfd845/Regelsuche-p04-tree-position')
expected, output_name = sys.argv[1:]
output = Path(__file__).parent / output_name
output.mkdir(exist_ok=False)
modules = ['regelsuche-core', 'regelsuche-search', 'regelsuche-learning']
runner = Path('/workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs')
isolated = Path(tempfile.mkdtemp(prefix='regelsuche-p04-modules-', dir='/tmp'))
isolated_init = isolated/'isolate-build.gradle'
isolated_init.write_text('gradle.beforeProject { p ->\n'
    + '  p.layout.buildDirectory.set(new File(' + json.dumps(str(isolated/'build'))
    + ", p.path == ':' ? '_root' : p.path.substring(1).replace(':', '_')))\n"
    + '  p.tasks.withType(org.gradle.api.tasks.compile.JavaCompile).configureEach { options.incremental = false }\n'
    + '}\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
head = git('rev-parse', 'HEAD')
if expected != head or git('status', '--porcelain', '--untracked-files=all'):
    raise SystemExit('An exact committed and clean source tree is required')
sources = {str(p.relative_to(root)): sha(p) for p in root.glob('*/src/**/*.java')}
command = ['node', str(runner), '--no-daemon', '--no-configuration-cache', '--console=plain',
    '--max-workers=1', '--no-build-cache', '--rerun-tasks', '--continue',
    '--project-cache-dir', str(isolated/'project-cache'), '-I', str(isolated_init),
    *[':' + m + ':test' for m in modules]]
binding = {'head': head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'sources': sources,
    'runnerSha256': sha(runner), 'initSha256': sha(isolated_init), 'command': command,
    'isolatedBuildRoot': str(isolated/'build'),
    'scope': 'Complete Core/Search/Learning suites, fresh nonincremental Java25 compilation. No P04 qualification or economic claim is implied.'}
(output/'source-binding.json').write_text(json.dumps(binding, indent=2)+'\n')
shutil.copy2(isolated_init, output/'isolate-build.gradle')
# Every output starts in a new directory outside the synchronized source tree.
# No exclusions or test selectors hide transient classes or real regressions.
started = time.time()
env = dict(os.environ, GRADLE_USER_HOME='/workspace/scratch/4e87c3dfd845/gradle-home')
env['JAVA_TOOL_OPTIONS'] = env.get('JAVA_TOOL_OPTIONS', '') + ' -XX:ActiveProcessorCount=2'
with (output/'gradle.log').open('w') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
summary = {'exitCode': result.returncode, 'modules': {},
    'headUnchanged': git('rev-parse', 'HEAD') == head,
    'sourcesUnchanged': sources == {str(p.relative_to(root)): sha(p) for p in root.glob('*/src/**/*.java')}}
for m in modules:
    destination = output/m; destination.mkdir()
    totals = {k: 0 for k in ('tests','failures','errors','skipped')}
    files = sorted((isolated/'build'/m/'test-results/test').glob('TEST-*.xml'))
    for path in files:
        report = ET.parse(path).getroot()
        for k in totals: totals[k] += int(report.attrib[k])
        shutil.copy2(path, destination/path.name)
    totals['allReportsFresh'] = bool(files) and all(p.stat().st_mtime >= started for p in files)
    classes = list((isolated/'build'/m/'classes').rglob('*.class'))
    totals['allClassesFresh'] = bool(classes) and all(p.stat().st_mtime >= started for p in classes)
    summary['modules'][m] = totals
(output/'summary.json').write_text(json.dumps(summary, indent=2)+'\n')
print(json.dumps(summary, indent=2))
sys.exit(result.returncode or (0 if summary['headUnchanged'] and summary['sourcesUnchanged']
    and all(r['allReportsFresh'] and r['allClassesFresh'] for r in summary['modules'].values()) else 1))
