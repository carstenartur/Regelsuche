# Core observer instrumentation repair

Base: 0e26c2b1974b00a6b48c38c0b8367b07230b73c7.
Scope: only RewriteTemporaryOwnershipTest, CanonicalizerWorkBoundaryTest,
CanonicalizerTemporaryOwnershipTest, TreePositionOwnershipTest, and
PolynomialTemporaryOwnershipTest. No production, build policy, threshold,
expected work count, or shared identity changes. ExprMatcher's separate 9/11
observation remains with the parent.

Both parent full runs reproduce 22 failures across these 59 tests. The second
uses fresh isolated /tmp build outputs and confirms the diagnosis independently
of the local synchronization artifacts in the initial run. Original XML and
source binding are preserved here.

The StackOverflow traces cycle from a test observer through Expr.equals into
ExpressionIdentity and RetainedOperation checkpoint/work, back into the observer.
Other failing owner checks run semantic result equality or build a parser-based
expected fixture after the measured operation releases its input owner but
before the test closes the surrounding RetainedOperation.

Replace only observer comparisons of actual copies with element-reference and
concrete type/field checks. Retain semantic result assertions outside the active
scope. The new function boundary captures the actual new FunctionExpr and checks
its complete value after the scope closes. All original ownership, paid-work,
cleanup, exact count and budget assertions stay in place; no numerical expected
value changes are permitted without a separately demonstrated reason.

Focused verification awaits the serialized Gradle slot. It will select exactly
these five classes with fresh non-incremental compilation and a private /tmp
build root/project-cache. Parent owns the final integrated module gate.

First focused run: 59 tests, 58 passed, one remaining allocation-abort trigger
failed. The failure and all 59 original XML results/source hashes are retained
in focused-attempt-1. Source inspection identifies the trigger's unqualified
one-unit debit: the newly paid rewritten.equals(subtree) occurs before the
list allocation and also has rewriteEverywhere on the stack. The final test
change restricts injection to retainCompleted with that direct producer caller;
it does not require a successful owner observation before injecting failure.
No ownership assertion or numerical expectation changed.
