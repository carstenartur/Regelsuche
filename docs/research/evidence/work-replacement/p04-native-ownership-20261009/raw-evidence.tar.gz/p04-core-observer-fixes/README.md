# P04 Core ownership observer fixes

Base: `0e26c2b1974b00a6b48c38c0b8367b07230b73c7`.
Commit: `01b0ed4f5a289b13c6d92327207b7683573d7c07`.
Tree: `821108d90128661fec57fa9908b5178f16cae993`; worktree clean.
This task changes only the five assigned Core test files. No production file,
shared expression identity, owner contract, budget, coverage policy or numerical
expected value is changed.

## Diagnosis and result

| Test class | Tests | Confirmed original failures | Final failures |
| --- | ---: | ---: | ---: |
| RewriteTemporaryOwnershipTest | 18 | 14 | 0 |
| CanonicalizerWorkBoundaryTest | 5 | 1 | 0 |
| CanonicalizerTemporaryOwnershipTest | 7 | 2 | 0 |
| TreePositionOwnershipTest | 9 | 1 | 0 |
| PolynomialTemporaryOwnershipTest | 20 | 4 | 0 |
| Total | 59 | 22 | 0 |

The parent first observed these failures in a full module run that also exposed
unrelated synchronized-build artifacts. Its independent repeat on the identical
sources with fresh private /tmp outputs confirmed all 22 failures. Both source-
bound XML sets are preserved; the private-output repeat is the qualifying RED.

Observer calls to Expr.equals, collection equality involving Expr, or contains
entered the newly paid ExpressionIdentity path and recursively called the same
observer. Some successful operations were followed by semantic assertions or
construction of an expected parsed AST while the test's outer scope was still
active; those unrelated checkpoints incorrectly reported that the completed
operation no longer owned its input.

The repair uses actual element/child identities in owner probes. The numeric
three observation inspects its existing scalar value without creating/comparing
an Expr. The function-boundary probe captures the actual new function and checks
its complete semantic value outside the scope. Semantic output assertions and
parser-built expectations now run outside the measured operation. All original
owner overlap, input coverage, failed-work, cleanup, exact count and budget
assertions remain; no expected numbers were raised or weakened.

The first focused attempt passed 58 of 59 tests. The final remaining test's
one-unit allocation-abort trigger also intercepted the new one-unit expression
comparison preceding the allocation in rewriteEverywhere. It now identifies
retainCompleted with the exact direct producer caller. It does not condition
failure injection on whether ownership is correct. The old allocation-owner
assertion and all four allocation-boundary cases remain intact. This intermediate
failure is preserved in `focused-attempt-1` with its exact sources and XML.

## Final verification

Fresh private build root: `/tmp/regelsuche-p04-core-observer-final-2n4kqdf9`.
Private Gradle project cache; JavaCompile incremental=false; --no-build-cache,
--no-configuration-cache, --rerun-tasks, --max-workers=1. The existing JDK25
runner selected exactly the five listed test classes in :regelsuche-core:test.
The full command and source hashes are recorded in `green/source-binding.json`.

Final process: **BUILD SUCCESSFUL in 17s, 59 tests, 0 failures, 0 errors,
0 skips**. All six Gradle tasks executed. Twenty-five actual compiled test class
files are hash/timestamp-bound in the same JSON. Source hashes before and after
the run match. Original final JUnit XML, process record, log and isolated build
configuration are retained under `green/`.

The separate ExprMatcherOwnershipTest repair remains with the parent. This
focused GREEN does not claim that the full Core/Search/Learning gate or P04 as
a whole is complete. The production V6 partial accounting status is untouched.
