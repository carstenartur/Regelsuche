# P04 concurrent native session acceptance

Test-only addition: `NativeConcurrentSessionsTest`.
Commit: `b968dd81beb9bb1d35de1bbbe03de12346892224`.
Committed tree: `f6963850b20465bd50efa0f260a7e9842f98d296`; worktree clean.
Dependency head: `86f3fdb` (parent paid identity `f8323e4` plus assembly
`c87998b`, cherry-picked locally as `86f3fdb`).

## Verified outcome

The first focused run passed **2 tests, 0 failures, 0 errors, 0 skips**:
`STAGED` and `STAGED_INCREMENTAL`. Both modes execute separate sequential
references and two actual NativeMoveSearch calls on worker threads, sharing
immutable AST/context inputs and the same existing exact primitive provider.

The successful session reaches the declared target through two checked steps
and pays independent replay. Its work allowance was fixed before the run at
20,000,000; the aborted session uses 3,000,000. The latter's four-node limit
admits the complete input graph, then fails on an actual additional search
allocation and returns its retained paid failure. No budget was changed after
observing a test result.

Concurrent outcomes, total/component work, witnesses, replay, cursor receipts,
retained peaks, final/external ownership and cleanup match their corresponding
sequential references exactly. Parent RetainedOperation scopes coexist across
external start/end barriers. Their counters are thread-confined, native work
does not leak into the caller scope, and each native close restores its own
parent. Closed scopes and frames have no live contents; output identity-graph
inspection finds no mutable session/store/scope links.

The executor, barriers and phase counter remain external test coordination;
they are never captured inside a claimed stateless/native callback View.

## Command and actual outputs

```
GRADLE_USER_HOME=/workspace/scratch/4e87c3dfd845/gradle-home \
JAVA_TOOL_OPTIONS=-XX:ActiveProcessorCount=2 \
node /workspace/scratch/4e87c3dfd845/evidence-20261009/pr1065-recovered/pr1065-p04-structural-index/run-gradle25.cjs \
:regelsuche-search:test --tests de.regelsuche.search.moves.NativeConcurrentSessionsTest \
--no-daemon --no-build-cache --no-configuration-cache --rerun-tasks --max-workers=1
```

`attempt-1.log` records BUILD SUCCESSFUL in 21s, all ten tasks executed. This
isolated worktree had no previous build outputs. Source and fresh test-class
hashes/timestamps are in `source-binding.json`; the actual class files and javap
output are retained alongside the original JUnit XML and `results.json`.
There was no synthetic RED cycle: this is an acceptance regression of the
existing concurrency contract after its prerequisite assembly fix.

## Boundaries

No production file, shared equality implementation or result assembly was
changed by this test-only task. The test intentionally preserves V6 partial
accounting: `accountingComplete=false` and `withinBudget=false`. This establishes
this two-session case, not arbitrary provider thread safety or completion of
P04. The parent owns integrated Core/Search/Learning, broader native corpus,
review and CI gates. No global tests or remote changes were made here.
