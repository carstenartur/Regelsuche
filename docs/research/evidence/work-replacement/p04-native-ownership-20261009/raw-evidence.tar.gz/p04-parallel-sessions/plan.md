# P04 concurrent native sessions

Test-only branch: `codex/p04-parallel-sessions-20261009`.
Initial integrated base: `551e4b3cb04538e9e0fede69329a00dd22ca3c3f`.
Paid identity checkpoint: `f8323e49f2758a27d0c5bb168f0cfefb68f97c75`.
Assembly dependency: `c87998b16347058647e75d8c0cf64fa1bbd69c7e`, applied locally as
`86f3fdb` after its owner reported the targeted 40-test GREEN.

The acceptance case exercises two actual NativeMoveSearch calls on two worker
threads, sharing the same immutable ASTs and existing exact primitive provider.
One session has adequate work/retention limits; the other has a distinct budget
and a forced four-node retention limit (the full shared input graph fits;
additional rewrite allocations exceed it). Both parent RetainedOperation scopes
coexist across externally owned start and completion barriers.

For STAGED and STAGED_INCREMENTAL separately, compare each concurrent result
with its independently executed sequential reference: declared observed outcome,
total and component work, witness/independent replay, picker/cursor receipts,
retention peaks and final/external ownership. Check each thread's parent scope
restoration and counters, scope/frame release, absent post-close thread binding,
and no result edge into either mutable session graph.

The barrier/executor/atomic phase counter are external test infrastructure. They
are never hidden in a native callback or falsely declared stateless View. The
parent observers own exactly their actual marker buffers and scope reference.
All traversal of returned graphs uses identity outside measured scopes.

No production, expression identity, search algorithm or result assembly changes
are made here. This qualifies an existing concurrency contract; no artificial
RED cycle is forced. The parent has identified two failures in abort-result
assembly on the paid-identity checkpoint, so verification first waited for that fix. The dependency is now applied;
the test run still awaits the serialized Gradle slot.
The final combined/module/native-corpus/review/CI gates remain with the parent;
partial P04 flags remain unchanged.
