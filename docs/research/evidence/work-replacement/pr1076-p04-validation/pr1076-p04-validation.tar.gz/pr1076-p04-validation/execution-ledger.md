# SDD ledger — plan: docs/superpowers/plans/2026-09-20-work-replacement.md

## Resume 2026-10-09 — P04 validation retention

Task 0–3: integrated; repository progress report and Git history are authoritative.
P04 remains incomplete. PR #1065 merged at 51d699d092c8a6dae139c2c3b539d774d96955e3
on 2026-10-06. Exact head 014343918090e2ab6cebc21d8b80f0579af384df passed
CI 37443413603, all six authorities and ciCheck. All three review threads resolved.
Current baseline: 8a98a14e6713225801832918befd7c12d5cb74ba.

Pre-flight: existing RetainedOperation frames expose explicit View fields to the
same observer; no new search or verifier interface. AstExpressionValidation's
existing node/text validation ledger must remain unchanged. Additional queue,
allocation and cleanup work belongs to a new native measurement revision.

Ruling: resume the already authorized P04 work with bounded validation ownership;
do not reapply the now integrated #1065 fixes. No new public architecture or
mathematical authority. Cost if wrong: incomplete diagnostic cost/retention, never
a qualified total-budget success because partial coverage remains mandatory.

Task 4 current slice: tests first for numeric/symbol/intermediate-history rendering,
failed validation debit, paid explicit traversal ownership, release and no JSON.
Use a bounded iterative preorder counter with the existing structural/text limits;
retain actual source, current visit, pending visits and rendered scalar, observe
periodically and before release/failure, preserve the primary throwable.
No opaque lambdas or new runtime dependency in the validator.

The supplementary writing-good-tests skill resource is unavailable via either
advertised relative location; the fully read TDD skill remains in force.

Baseline: existing AstExpressionValidationTest + AstHistoryValidationTest pass (5).
RED: new AstValidationRetentionTest 7 tests, 6 expected behavioral failures.
First implementation: all new validator/codec/history tests pass; 5 existing native
integration tests fail because the new input observation can throw ResourceLimit
before entering the kernel. Preserve this failed run, do not change its budgets.
Fix: record input resource failure in the existing retention session and route it
through the kernel's first checkpoint and normal paid result path.
Second RED: queuedOccurrencesCannotMultiplyTheFiniteNodeLimit exposes oversized
scratch from nested wide functions. Guard queued + visited occurrences per state
at the existing 10,000 node limit before allocating another visit.

Ruling: use an append-only per-inspection visit arena to keep actual scratch growth
visible between bounded observations, rather than full graph scanning at each
child. Cost: extra bounded logical retention, explicitly paid and documented; no
performance claim. JDK-internal scalar formatting remains outside this slice.

Focused GREEN: 23 tests (8 new, 5 existing codec/history, 10 native integration).
First modules run: core + search 1,658 passing; learning 1,058 with one failure,
TypedLearnedMoveInventoryTest.actualLearnedTracesDispatchOverTypedStatesAndFeedBackIntoHistory:
10,001,396 units exceed the unchanged 10,000,000 budget. The new validator repeats
a full terminal observation immediately after its last scalar observation with
no intervening ownership growth. Remove that duplicate observation, not the
budget or assertion. Add a RED observation-count test and a size-dependent scalar
render-work test; completed rendering must be paid separately from text scanning.
The first scalar RED attempt was a Gradle journal-lock timeout, not behavioral
evidence: this environment gives concurrent Gradle daemons the same namespace PID.
Run subsequent Gradle invocations sequentially.
Local pinned AI extractor v0.1.10 complexity authority: PASS, 17 hotspots,
unchanged ratchet. Final source must be rechecked after the pending correction.

Scalar-work/duplicate-observation RED: 2 tests fail behaviorally after the lock-only
attempt. Fix: pay completed rendered characters separately; skip only the duplicate
terminal checkpoint when no ownership grew after the last successful observation.
Focused GREEN includes TypedLearnedMoveInventoryTest with the original budget:
TARGET_REACHED, 9,977,168 / 10,000,000 units. Public withinBudget remains false.
Acquisition RED: failedScopeAcquisitionStillPaysForCounterRelease exposes missing
counter release debit when frame acquisition itself fails. Move acquisition into
the same failure-preserving cleanup boundary, retaining RetainedOperation's own
observation and frame cleanup. No budget, proof or expected-result assertion changed.

All 2,719 module tests and complexity authority passed after acquisition cleanup.
Final lifetime RED: completedRenderingIsReleasedBeforeVisitingTheNextNode proves
the completed scalar was retained into the next node. Release it, with a paid
debit while still owned, immediately after successful observation. This prevents
an unobserved overlap between the previous string and the next completed rendering.
Rerun the complete affected suites and unchanged complexity authority before commit.
The requesting-code-review template resource is also unavailable; use the fully
read review skill and the P04 spec/ledger directly for the independent reviewer.

Final local verification: core 1,058 + search 604 + learning 1,058 = 2,720 tests,
zero failures/errors/skips; pinned unchanged complexity authority PASS, 17 hotspots.
Local implementation commit b0883b6d3c7d968ef292c927ed5a6fdc7eb1bb53, tree
eb052f81047973154d99105273de5851b0c9b9a3. One fresh-context whole-branch review
dispatched to p04_validation_review (gpt-6-astra, high). P04 itself remains open.

Published source: 151826e648da62784574573b0980da42d3b68beb, same tree eb052f8;
local publication verified by fetch and zero tree diff. PR #1076 is ready for
review. Exact-head hosted CI 37938454239 is still pending at this checkpoint.
Unchanged public P03 probe freshly compiled on the published head: two fresh JVMs,
all 15 historical output files byte-identical. Earlier same-tree local run retained.

Final whole-branch review: no Critical, Important or Minor findings. Independent
probe: 1,366 callback failure sites x two failure modes, and 2,000 randomized
expression/history codec differentials passed. Reviewer independently counted all
2,720 final XML tests; worktree remained clean. The initial probe-only failure
(invalid SymbolId ordinal 0) was corrected in the generator, not production.

Final: Ruling: full P04 completion and physical JVM heap/OOM guarantees were not
judged by this bounded review — keep PARTIAL_ATOMIC_INVENTORY, INCONCLUSIVE and
false withinBudget; do not present these probes as total qualification — cost if
wrong: diagnostic retention or failure boundaries may remain incomplete.
Final: Ruling: JDK-internal formatting allocations are outside this explicit
ownership slice — keep the documented partial boundary and record completed
buffers only — cost if wrong: measured logical work/retention can undercount internals.
Final: Ruling: unchanged PR #1065 store behavior is not re-reviewed here — rely on
its separately source-bound final CI and resolved reviews, not older slice evidence
— cost if wrong: a pre-existing store defect may remain outside this change.
Final: Ruling: sealed holdouts and parent-owned P03/remote CI were not independently
executed by the reviewer — leave holdouts untouched; parent verifies exact-head
public P03 and all hosted authorities before integration — cost if wrong: independent
generalization or full-hosted qualification must not be claimed from local tests.
Final: minor (deferred): none.
