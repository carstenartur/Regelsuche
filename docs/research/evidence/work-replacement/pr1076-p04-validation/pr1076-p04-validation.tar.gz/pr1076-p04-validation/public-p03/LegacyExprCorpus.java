package de.regelsuche.preparation;

import de.regelsuche.ast.*;
import de.regelsuche.assumption.Assumption;
import de.regelsuche.evolution.*;
import de.regelsuche.parse.ExpressionParser;
import de.regelsuche.search.moves.*;
import de.regelsuche.search.program.CompiledAstReplayCodec;
import de.regelsuche.symbol.SymbolScope;
import de.regelsuche.transform.*;
import java.nio.file.*;
import java.util.*;
import static de.regelsuche.ast.BinaryOperator.*;

/** Development characterization only. No native P04 API or new proof authority. */
public final class LegacyExprCorpus {
    private static final CompiledAstReplayCodec CODEC = new CompiledAstReplayCodec();
    private static final ExpressionParser PARSER = new ExpressionParser();
    private static final List<Object> CASES = new ArrayList<>();
    private static final List<Object> IDENTITIES = new ArrayList<>();
    private static final MoveSearch.Budget BUDGET = new MoveSearch.Budget(6, 2, 100, 64, 30000);
    private static final Expr ZERO = new NumberExpr(0);

    public static void main(String[] args) throws Exception {
        Path out = Path.of(args[0]); Files.createDirectories(out);
        var rule = new PatternRewriteRule("p04-zero", PatternExpr.op(ADD, PatternExpr.var("A"), PatternExpr.num(0)), PatternExpr.var("A"));
        var transport = new AstRewriteTransport(List.of(rule), 32, 32);
        var primitive = TypedMoveSearch.primitiveProvider(descriptor("p04-zero", List.of()), transport);
        var verifier = TypedMoveSearch.primitiveReplay(transport);
        Expr rational = NumberExpr.exact("-7/13");
        run("primitive-exact-rational", add(rational, ZERO), rational, List.of(), List.of(primitive), verifier, BUDGET, true);
        identity("equal-rational-spellings", NumberExpr.exact("0.125"), NumberExpr.exact("1/8"), true);
        identity("rational-leaf-versus-division", NumberExpr.exact("1/3"), parse("1/3"), false);
        Expr huge = NumberExpr.exact("10000000000000000.125");
        run("primitive-large-exact-decimal", add(huge, ZERO), huge, List.of(), List.of(primitive), verifier, BUDGET, true);

        var parent = new SymbolScope(new UUID(0, 4001));
        var child = parent.child(new UUID(0, 4002));
        var outerId = parent.declare("x"); var innerId = child.declare("x");
        Expr outer = VariableExpr.scoped(outerId), inner = VariableExpr.scoped(innerId);
        identity("same-display-x-different-scopes", outer, inner, false);
        parent.alias("renamed_x", outerId);
        identity("alias-same-symbol", outer, VariableExpr.scoped(parent.resolve("renamed_x")), true);
        run("primitive-scoped-symbol", add(outer, ZERO), outer, List.of(), List.of(primitive), verifier, BUDGET, true);
        run("scope-must-not-reach-other-x", add(outer, ZERO), inner, List.of(), List.of(primitive), verifier, BUDGET, false);
        write(out, "symbol-bindings.json", Map.of("parentNamespace", parent.namespace().toString(), "childNamespace", child.namespace().toString(),
            "parentBindings", Map.of("x", outerId.identifier(), "renamed_x", outerId.identifier()), "childBindings", Map.of("x", innerId.identifier()),
            "displayNote", "Both lexical declarations use x; alias renamed_x refers to the original outer identity."));

        Expr left = parse("(a+b)+c"), right = parse("a+(b+c)");
        identity("grouping", left, right, false);
        identity("independently-allocated-equal-tree", right, parse("a+(b+c)"), true);
        identity("scalar-multiplication-order-structural", parse("a*b"), parse("b*a"), false);
        run("primitive-preserves-grouping", add(right, ZERO), right, List.of(), List.of(primitive), verifier, BUDGET, true);
        run("grouping-is-not-a-goal-equivalence", add(right, ZERO), left, List.of(), List.of(primitive), verifier, BUDGET, false);
        Expr ordered = new FunctionExpr("orderedProduct", List.of(outer, inner));
        Expr reverse = new FunctionExpr("orderedProduct", List.of(inner, outer));
        identity("opaque-ordered-operation", ordered, reverse, false);
        run("opaque-order-preserved", add(ordered, ZERO), reverse, List.of(), List.of(primitive), verifier, BUDGET, false);

        var conditionalRule = new PatternRewriteRule("p04-conditional-zero", PatternExpr.op(ADD, PatternExpr.var("A"), PatternExpr.num(0)), PatternExpr.var("A")) {
            @Override public List<Assumption> assumptions(Expr input) { return List.of(Assumption.nonZero("x")); }
        };
        var conditionalTransport = new AstRewriteTransport(List.of(conditionalRule), 32, 32);
        var conditional = TypedMoveSearch.primitiveProvider(descriptor("p04-conditional-zero", List.of("x != 0")), conditionalTransport);
        var conditionalVerifier = TypedMoveSearch.primitiveReplay(conditionalTransport);
        var admitted = run("primitive-assumption-present", parse("x+0"), parse("x"), List.of("x != 0"), List.of(conditional), conditionalVerifier, BUDGET, true);
        run("primitive-assumption-absent", parse("x+0"), parse("x"), List.of(), List.of(conditional), conditionalVerifier, BUDGET, false);
        var edge = admitted.witness().getFirst();
        var dropped = conditionalVerifier.verify(state(edge.source().expression()), edge.move(), TypedMoveSearch.Context.frozen(parse("x")));
        require(!dropped.accepted(), "missing assumptions must reject independent replay");
        write(out, "assumption-replay-negative.json", Map.of("source", CODEC.encodeExpression(edge.source().expression()),
            "move", edge.move(), "contextAssumptions", List.of(), "verification", dropped));
        run("primitive-tight-work-budget", parse("x+0"), parse("x"), List.of(), List.of(primitive), verifier,
            new MoveSearch.Budget(6, 2, 100, 64, 1), false);

        var formation = new TraceRewriteStrategyLearner().learn(TraceStrategyTransferExample.inventory(),
            TraceStrategyTransferExample.trainingInputs(), TraceStrategyTransferExample.limits());
        var inventory = formation.typedMoves();
        require(!inventory.learnedPrograms().isEmpty(), "actual learner must form a registered program");
        Expr base = new FunctionExpr("f", List.of(outer, NumberExpr.exact("1/3"), right));
        Expr programSource = cancellation(base, inner), programGoal = new BinaryExpr(base, POW, new NumberExpr(2));
        var programResult = run("actual-learned-program", programSource, programGoal, List.of(), inventory.providers(), inventory.verifier(),
            new MoveSearch.Budget(6, 1, 0, 64, 30000), true);
        require(programResult.witness().stream().anyMatch(s -> s.move().sourceKind() == SearchMove.SourceKind.LEARNED
            && s.move().transformation().primitiveStepCount() > 1), "learned program witness required");
        var model = inventory.checkedSchemas();
        var restored = CheckedLearnedSchemaModel.load(model.toCanonicalJson(), formation.inventory().contentHash());
        require(restored.toCanonicalJson().equals(model.toCanonicalJson()), "model reproof must preserve artifact");
        Expr schemaBase = add(outer, NumberExpr.exact("1/3"));
        Expr schemaSource = cancellation(schemaBase, inner), schemaGoal = new BinaryExpr(schemaBase, POW, new NumberExpr(2));
        var schemaResult = run("actual-learned-schema-scoped-rational", schemaSource, schemaGoal, List.of(), restored.providers(4), restored.verifier(), BUDGET, true);
        require(schemaResult.witness().stream().anyMatch(s -> s.move().transformation().exactTheoryStepCount() > 0), "checked-schema witness required");
        run("schema-rejects-opaque-function-domain", programSource, programGoal, List.of(), restored.providers(4), restored.verifier(), BUDGET, false);
        Expr divided = parse("1/x"), y = parse("y");
        run("schema-rejects-variable-division-domain", cancellation(divided, y), new BinaryExpr(divided, POW, new NumberExpr(2)),
            List.of(), restored.providers(4), restored.verifier(), BUDGET, false);
        var gated = restored.requiring(List.of("x > 0"));
        run("schema-assumption-absent", schemaSource, schemaGoal, List.of(), gated.providers(4), gated.verifier(), BUDGET, false);
        run("schema-assumption-present", schemaSource, schemaGoal, List.of("x > 0"), gated.providers(4), gated.verifier(), BUDGET, true);
        var proof = schemaResult.witness().getFirst();
        var wrongSource = restored.verifier().verify(state(parse("(x+y)*(x-y)+z*z")), proof.move(), TypedMoveSearch.Context.frozen(schemaGoal));
        require(!wrongSource.accepted(), "schema cannot authorize a foreign source");
        write(out, "schema-source-binding-negative.json", Map.of("source", CODEC.encodeExpression(parse("(x+y)*(x-y)+z*z")),
            "move", proof.move(), "verification", wrongSource));

        currentContracts(out, restored, schemaResult, schemaSource, schemaGoal, primitive, verifier);

        writeRaw(out, "training/formation.json", formation.toCanonicalJson());
        writeRaw(out, "training/model.json", model.toCanonicalJson());
        writeRaw(out, "training/inventory.json", formation.inventory().toCanonicalJson());
        write(out, "training/accounting.json", Map.of("limits", formation.limits(), "inputs", TraceStrategyTransferExample.trainingInputs(),
            "trainingSearch", formation.trainingSearchWorkUnits(), "trainingPrimitive", formation.trainingPrimitiveWorkUnits(),
            "formationTotalObserved", inventory.formationWork(), "schemaFormation", model.formationWork(), "restoreReproof", restored.loadWork(),
            "scope", "Existing observed logical units only; no total CPU/memory/time or lifecycle completeness claim."));
        write(out, "identities.json", IDENTITIES);
        write(out, "cases.json", CASES);
        System.out.println("characterized " + CASES.size() + " searches and " + IDENTITIES.size() + " identity pairs");
    }

    private static TypedMoveSearch.Result run(String id, Expr source, Expr goal, List<String> assumptions,
            List<MoveProvider> providers, TypedMoveSearch.Verifier verifier, MoveSearch.Budget budget, boolean expectedReached) {
        return run(id, source, goal, assumptions, providers, verifier, budget, expectedReached,
            MoveSearch.Scheduling.STAGED, SearchContinuationContract.PATH_SENSITIVE);
    }
    private static TypedMoveSearch.Result run(String id, Expr source, Expr goal, List<String> assumptions,
            List<MoveProvider> providers, TypedMoveSearch.Verifier verifier, MoveSearch.Budget budget, boolean expectedReached,
            MoveSearch.Scheduling scheduling, SearchContinuationContract continuation) {
        var context = new TypedMoveSearch.Context(goal, assumptions, MoveContext.Phase.FROZEN_EVALUATION);
        var problem = new TypedMoveSearch.Problem(source, context, providers, MovePriorityPolicy.INVENTORY_ORDER, verifier,
            state -> 0, MoveSearch.Mode.FAST, scheduling, budget);
        var result = new TypedMoveSearch().search(problem, continuation);
        require(result.reached() == expectedReached, id + " unexpected outcome: " + result.outcome());
        var replay = new ArrayList<Object>(); long replayWork = 0;
        var cursor = source;
        for (var step : result.witness()) {
            require(cursor.equals(step.source().expression()), id + " broken witness lineage");
            var checked = verifier.verify(step.source(), step.move(), context);
            require(checked.accepted() && checked.equals(step.verification()), id + " independent replay differs");
            replayWork = Math.addExact(replayWork, checked.work()); replay.add(checked);
            cursor = step.target().expression();
        }
        require(!result.reached() || cursor.equals(goal), id + " wrong witnessed target");
        var row = new TreeMap<String, Object>();
        row.put("id", id); row.put("source", CODEC.encodeExpression(source)); row.put("goal", CODEC.encodeExpression(goal));
        row.put("context", Map.of("assumptions", context.initialAssumptions(), "phase", context.phase()));
        row.put("budget", budget); row.put("mode", "FAST"); row.put("scheduling", scheduling);
        row.put("continuation", continuation); row.put("policy", "INVENTORY_ORDER"); row.put("stateScore", "constant-zero/v1");
        row.put("providers", providers.stream().map(MoveProvider::descriptor).toList());
        row.put("transportRevision", TypedMoveSearch.REVISION); row.put("expectedReached", expectedReached);
        row.put("accountingComplete", result.accountingComplete());
        row.put("legacyResultJson", LearnedSchedulingArtifacts.resultJson(result.encodedResult()));
        row.put("finalReplay", replay); row.put("finalReplayWork", replayWork);
        long total = Math.addExact(result.metrics().totalWork(), replayWork);
        row.put("searchPlusFinalReplayWork", total); row.put("withinBudgetAfterReplay", result.accountingComplete() && total <= budget.totalWork());
        row.put("logicalWorkScope", "Legacy search metrics plus explicit independent replay; export bytes reported separately; no CPU ledger.");
        row.put("legacyResultUtf8Bytes", ((String) row.get("legacyResultJson")).getBytes(java.nio.charset.StandardCharsets.UTF_8).length);
        CASES.add(row); return result;
    }

    private static void currentContracts(Path out, CheckedLearnedSchemaModel model, TypedMoveSearch.Result schemaResult,
            Expr schemaSource, Expr schemaGoal, MoveProvider primitive, TypedMoveSearch.Verifier primitiveVerifier) throws Exception {
        run("p02-typed-primitive-batch", parse("x+0"), parse("x"), List.of(), List.of(primitive), primitiveVerifier,
            BUDGET, true, MoveSearch.Scheduling.STAGED_INCREMENTAL, SearchContinuationContract.PATH_SENSITIVE);
        run("p02-typed-batch-tight-budget", parse("x+0"), parse("x"), List.of(), List.of(primitive), primitiveVerifier,
            new MoveSearch.Budget(6, 2, 100, 64, 5), false, MoveSearch.Scheduling.STAGED_INCREMENTAL, SearchContinuationContract.PATH_SENSITIVE);
        String schema = schemaResult.witness().getFirst().move().transformation().rule();
        var plan = CheckedSchemaMatcherPlan.prepare(model, 1, Map.of(), Set.of(schema));
        run("p03-registered-scoped-rational", schemaSource, schemaGoal, List.of(), List.of(plan.provider()), model.verifier(),
            BUDGET, true, MoveSearch.Scheduling.STAGED_INCREMENTAL, SearchContinuationContract.PATH_SENSITIVE);
        var mixedVerifier = (TypedMoveSearch.Verifier) (source, move, context) -> move.sourceKind() == SearchMove.SourceKind.PRIMITIVE
            ? primitiveVerifier.verify(source, move, context) : model.verifier().verify(source, move, context);
        run("p03-schema-with-primitive-fallback", schemaSource, schemaGoal, List.of(), List.of(plan.provider(), primitive), mixedVerifier,
            BUDGET, true, MoveSearch.Scheduling.STAGED_INCREMENTAL, SearchContinuationContract.PATH_SENSITIVE);
        run("p03-registered-tight-budget", schemaSource, schemaGoal, List.of(), List.of(plan.provider()), model.verifier(),
            new MoveSearch.Budget(6, 2, 100, 64, 10), false, MoveSearch.Scheduling.STAGED_INCREMENTAL, SearchContinuationContract.PATH_SENSITIVE);

        var a = new PatternRewriteRule("p04-route-a", PatternExpr.op(ADD, PatternExpr.var("A"), PatternExpr.num(0)), PatternExpr.var("A"));
        var b = new PatternRewriteRule("p04-route-b", PatternExpr.op(ADD, PatternExpr.var("A"), PatternExpr.num(0)), PatternExpr.var("A"));
        var ta = new AstRewriteTransport(List.of(a), 32, 32); var tb = new AstRewriteTransport(List.of(b), 32, 32);
        var pa = TypedMoveSearch.primitiveProvider(descriptor(a.id(), List.of()), ta);
        var pb = TypedMoveSearch.primitiveProvider(descriptor(b.id(), List.of()), tb);
        TypedMoveSearch.Verifier routes = (source, move, context) -> move.ruleId().equals(a.id())
            ? TypedMoveSearch.primitiveReplay(ta).verify(source, move, context)
            : move.ruleId().equals(b.id()) ? TypedMoveSearch.primitiveReplay(tb).verify(source, move, context)
            : primitiveVerifier.verify(source, move, context);
        var full = run("continuation-path-sensitive-stateless", parse("(x+0)+0"), parse("absent"), List.of(), List.of(pa,pb), routes,
            BUDGET, false, MoveSearch.Scheduling.STAGED, SearchContinuationContract.PATH_SENSITIVE);
        var local = run("continuation-declared-state-local", parse("(x+0)+0"), parse("absent"), List.of(), List.of(pa,pb), routes,
            BUDGET, false, MoveSearch.Scheduling.STAGED, SearchContinuationContract.DECLARED_STATE_LOCAL);
        require(local.events().stream().anyMatch(e -> e.decision() == MoveSearch.Decision.DOMINATED), "state-local fixture needs a dominated alternate label");
        require(full.reachedStates().stream().map(s -> CODEC.encodeExpression(s.expression())).collect(java.util.stream.Collectors.toSet())
            .equals(local.reachedStates().stream().map(s -> CODEC.encodeExpression(s.expression())).collect(java.util.stream.Collectors.toSet())), "same stateless structural closure");
        run("continuation-history-gated-path-sensitive", parse("(x+0)+0"), parse("x"), List.of(),
            List.of(filtered(pa, s -> s.searchDepth() == 0), filtered(pb, s -> s.searchDepth() == 0),
                filtered(primitive, s -> s.previousRule().equals(b.id()))), routes,
            BUDGET, true, MoveSearch.Scheduling.STAGED, SearchContinuationContract.PATH_SENSITIVE);
        write(out,"continuation-contracts.json",Map.of(
            "statelessPair", List.of("continuation-path-sensitive-stateless","continuation-declared-state-local"),
            "historyCase", "continuation-history-gated-path-sensitive",
            "historyEligibility", "route-a and route-b only at searchDepth=0; p04-zero only after previousRule=p04-route-b",
            "scope", "Existing typed primitives independently replayed. History gating requires PATH_SENSITIVE; no invalid state-local declaration is tested as valid."));
        var encoded = CODEC.encodeExpression(parse("x"));
        var plain = MoveState.root(encoded);
        var states = new ArrayList<Object>();
        for (var other : List.of(new MoveState(encoded,0,0,"",List.of("x != 0"),Set.of(),0),
                new MoveState(encoded,0,0,"previous-rule",List.of(),Set.of(),0),
                new MoveState(encoded,0,0,"",List.of(),Set.of("capability"),0))) {
            require(!plain.equals(other),"continuation-bearing state fields must remain distinct");
            states.add(Map.of("left",plain,"right",other,"stateEqual",false));
        }
        write(out,"state-identities.json",states);

        Expr pair = parse("((a+b)*(a-b)+b*b)+((c+d)*(c-d)+d*d)");
        var pairState = MoveState.root(CODEC.encodeExpression(pair));
        var cursorContext = MoveContext.frozen("");
        var expected = model.providers(1, Map.of(), Set.of(schema)).getFirst().candidates(pairState,cursorContext);
        require(expected.moves().size() == 2,"two public schema occurrence fixture");
        var cursorCases = new ArrayList<Object>();
        cursorCases.add(cursorCase("zero-allowance-close",plan,pairState,cursorContext,0,null,false,model));
        for (var phase : IncrementalProviderContract.ApplicationPhase.values())
            cursorCases.add(cursorCase("close-after-"+phase,plan,pairState,cursorContext,2,phase,false,model));
        for (long allowance : new long[]{2,16,100000}) {
            var row = cursorCase("drain-allowance-"+allowance,plan,pairState,cursorContext,allowance,null,true,model);
            require(row.get("transformations").equals(expected.moves().stream().map(SearchMove::transformation).toList()),"drain matches exact eager transformations");
            cursorCases.add(row);
        }
        var gatedPlan = CheckedSchemaMatcherPlan.prepare(model.requiring(List.of("x > 0")),1,Map.of(),Set.of(schema));
        cursorCases.add(cursorCase("missing-assumptions",gatedPlan,pairState,cursorContext,100000,null,true,model.requiring(List.of("x > 0"))));
        cursorCases.add(cursorCase("unsupported-variable-division",plan,MoveState.root(CODEC.encodeExpression(parse("(1/x+y)*(1/x-y)+y*y"))),cursorContext,100000,null,true,model));
        write(out,"cursor-eager-reference.json",Map.of("source",pairState,"context",cursorContext,"provider",model.providers(1,Map.of(),Set.of(schema)).getFirst().descriptor(),"batch",expected));
        write(out,"cursor-cases.json",cursorCases);
        var quality = new ArrayList<Object>();
        for (boolean lazy : new boolean[]{false,true}) {
            var providers = lazy ? List.<MoveProvider>of(plan.provider()) : model.providers(1,Map.of(),Set.of(schema));
            var schedule = lazy ? MoveSearch.Scheduling.STAGED_INCREMENTAL : MoveSearch.Scheduling.STAGED;
            var calls = new ArrayList<Object>();
            TypedMoveSearch.Verifier tracked = (source,move,context) -> {
                var checked = model.verifier().verify(source,move,context);
                calls.add(Map.of("source",CODEC.encodeExpression(source.expression()),"move",move,"verification",checked));
                return checked;
            };
            var problem = new TypedMoveSearch.Problem(pair,TypedMoveSearch.Context.sourceOnly(List.of(),MoveContext.Phase.FROZEN_EVALUATION),
                providers,MovePriorityPolicy.INVENTORY_ORDER,tracked,s -> 0,MoveSearch.Mode.FAST,schedule,new MoveSearch.Budget(6,1,1000,32,100000));
            var result = new TypedSourceOnlySearch().searchUntil(problem,s -> new TypedSourceOnlySearch.Score(nodes(s.expression()),nodes(s.expression())),
                nodes(pair)-1,SearchContinuationContract.PATH_SENSITIVE);
            require(result.search().outcome() == MoveSearch.Outcome.QUALITY_REACHED && result.withinBudget(),"quality + paid final replay");
            var row = new TreeMap<String,Object>();
            row.put("id",lazy ? "quality-prepaid-incremental" : "quality-eager");row.put("source",CODEC.encodeExpression(pair));
            row.put("sourceOnly",true);row.put("assumptions",List.of());row.put("phase",MoveContext.Phase.FROZEN_EVALUATION);
            row.put("objective","AST occurrence node count/v1; score and work both count nodes");row.put("maximumOutputScore",nodes(pair)-1);
            row.put("budget",problem.budget());row.put("mode",problem.mode());row.put("scheduling",schedule);row.put("continuation",SearchContinuationContract.PATH_SENSITIVE);
            row.put("providers",providers.stream().map(MoveProvider::descriptor).toList());row.put("policy","INVENTORY_ORDER");
            row.put("incumbent",CODEC.encodeExpression(result.incumbent().expression()));row.put("inputScore",result.inputScore());row.put("outputScore",result.outputScore());
            row.put("search",LearnedSchedulingArtifacts.resultJson(result.search().encodedResult()));row.put("queryWork",result.queryWork());row.put("selectionWork",result.selectionWork());
            row.put("replayWork",result.replayWork());row.put("totalWork",result.totalWork());row.put("withinBudget",result.withinBudget());row.put("accountingComplete",result.accountingComplete());
            row.put("verificationCallsInOrder",calls);row.put("finalReplayCallCount",result.witness().size());
            row.put("additionalPlanCompilation",lazy ? plan.compilationWork() : 0);quality.add(row);
        }
        require(((Map<?,?>)quality.get(0)).get("incumbent").equals(((Map<?,?>)quality.get(1)).get("incumbent")),"same eager/lazy quality incumbent");
        write(out,"quality-cases.json",quality);
        write(out,"matcher-plan.json",Map.of("definition",plan.provider().contractDefinition(),"descriptor",plan.provider().descriptor(),"compilation",plan.compilationReceipt(),"selectedSchema",schema));
    }
    private static TypedMoveSearch.TypedProvider filtered(MoveProvider original, java.util.function.Predicate<MoveState> eligible) {
        return new TypedMoveSearch.TypedProvider() {
            @Override public Descriptor descriptor(){return original.descriptor();}
            @Override public Batch candidates(MoveState state,MoveContext context){return eligible.test(state) ? original.candidates(state,context)
                : new Batch(List.of(),TransformationWorkMetrics.ZERO.withDelegatedMechanicalWork(1),false);}
        };
    }
    private static Map<String,Object> cursorCase(String id,CheckedSchemaMatcherPlan plan,MoveState state,MoveContext context,
            long allowance,IncrementalProviderContract.ApplicationPhase stopPhase,boolean drain,CheckedLearnedSchemaModel model) {
        var cursor = plan.provider().openSession(state,context);var trace=new ArrayList<Object>();var actual=new ArrayList<Transformation>();
        var replay=new ArrayList<Object>();long replayWork=0;long previous=0;boolean stopped=false;
        trace.add(Map.of("operation","created","snapshot",cursor.snapshot()));
        for(int i=0;i<10000;i++) {
            var emitted=cursor.next(allowance);var snap=cursor.snapshot();long paid=snap.work().metrics().totalWorkUnitsV2();
            require(paid>=previous && snap.accountingComplete(),id+" lost accounting");previous=paid;
            var row=new TreeMap<String,Object>();row.put("operation","next");row.put("allowance",allowance);row.put("snapshot",snap);
            if(emitted.isPresent()){actual.add(emitted.orElseThrow());row.put("transformation",emitted.orElseThrow());}
            trace.add(row);
            if(stopPhase != null && snap.work().prepaidApplications().phaseCalls().getOrDefault(stopPhase.name(),0L)>0){stopped=true;break;}
            if(!drain && stopPhase==null){stopped=true;break;}
            if(snap.status()==IncrementalProviderContract.Status.EXHAUSTED || snap.status()==IncrementalProviderContract.Status.INCONCLUSIVE){stopped=true;break;}
        }
        require(stopped,id+" exceeded fixture pull bound");
        if(stopPhase!=null){require(actual.isEmpty(),id+" candidate escaped phase stop");
            require(cursor.snapshot().work().mathematics().exactTheorySteps()==(stopPhase==IncrementalProviderContract.ApplicationPhase.EVIDENCE?1:0),id+" premature theorem");}
        if(stopPhase!=null){var paused=cursor.snapshot();require(cursor.next(0).isEmpty(),id+" zero allowance emitted");
            require(paused.equals(cursor.snapshot()),id+" zero allowance changed paused receipt");
            trace.add(Map.of("operation","zero-allowance-at-phase","snapshot",cursor.snapshot()));}
        cursor.close();trace.add(Map.of("operation","close","snapshot",cursor.snapshot()));
        var closed=cursor.snapshot();cursor.close();require(closed.equals(cursor.snapshot()),id+" non-idempotent close");
        require(cursor.next(100000).isEmpty() && closed.equals(cursor.snapshot()),id+" closed cursor changed");
        trace.add(Map.of("operation","second-close-and-post-close-pull","snapshot",cursor.snapshot()));
        for(var transformation:actual){var move=SearchMove.from(transformation,plan.provider().descriptor(),0);
            var checked=model.verifier().verify(state(CODEC.decodeExpression(state.expression())),move,
                TypedMoveSearch.Context.sourceOnly(context.initialAssumptions(),context.phase()));
            require(checked.accepted(),id+" independent candidate replay rejected");replayWork=Math.addExact(replayWork,checked.work());replay.add(checked);}
        var paidWork=cursor.snapshot().work();var prepaid=paidWork.prepaidApplications();
        long phaseCalls=prepaid.phaseCalls().values().stream().reduce(0L,Math::addExact);
        long operations=paidWork.operations().values().stream().reduce(0L,Math::addExact);
        require(paidWork.metrics().candidateWork().equals(ExecutionWork.ZERO),id+" prepaid exact mathematics billed twice");
        require(paidWork.metrics().totalWorkUnitsV2()==Math.addExact(operations,Math.addExact(phaseCalls,prepaid.chargedUnits())),id+" incorrect prepaid paid total");
        var result=new TreeMap<String,Object>();result.put("id",id);result.put("source",state);result.put("context",context);
        result.put("definition",plan.provider().contractDefinition());result.put("compilation",plan.compilationReceipt());result.put("trace",trace);
        result.put("transformations",actual);result.put("finalReplay",replay);result.put("finalReplayWork",replayWork);
        result.put("cursorPaidWork",cursor.snapshot().work().metrics().totalWorkUnitsV2());return result;
    }
    private static long nodes(Expr expression){
        if(expression instanceof BinaryExpr b)return 1+nodes(b.left())+nodes(b.right());
        if(expression instanceof FunctionExpr f)return 1+f.arguments().stream().mapToLong(LegacyExprCorpus::nodes).sum();return 1;
    }

    private static void identity(String id, Expr a, Expr b, boolean expected) {
        require(a.equals(b) == expected, id + " equality changed");
        require(a.equals(CODEC.decodeExpression(CODEC.encodeExpression(a))), id + " left codec mismatch");
        require(b.equals(CODEC.decodeExpression(CODEC.encodeExpression(b))), id + " right codec mismatch");
        require(CODEC.encodeExpression(a).equals(CODEC.encodeExpression(b)) == expected, id + " transport identity changed");
        IDENTITIES.add(Map.of("id", id, "left", CODEC.encodeExpression(a), "right", CODEC.encodeExpression(b), "equal", expected));
    }
    private static MoveProvider.Descriptor descriptor(String id, List<String> assumptions) {
        return new MoveProvider.Descriptor(id, id, SearchMove.SourceKind.PRIMITIVE, SearchMove.ProofStrength.REPLAYABLE,
            assumptions, SearchMove.ValueEvidence.UNKNOWN, "p04-characterization/v1");
    }
    private static TypedMoveSearch.State state(Expr expression) { return new TypedMoveSearch.State(expression, 0, 0, "", List.of(), Set.of(), 0); }
    private static Expr parse(String text) { return PARSER.parseTerm(text); }
    private static Expr add(Expr a, Expr b) { return new BinaryExpr(a, ADD, b); }
    private static Expr cancellation(Expr a, Expr b) {
        return add(new BinaryExpr(add(a, b), MUL, new BinaryExpr(a, SUB, b)), new BinaryExpr(b, MUL, b));
    }
    private static void require(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static void write(Path directory, String file, Object value) throws Exception { writeRaw(directory, file, LearnedSchedulingArtifacts.json(value)); }
    private static void writeRaw(Path directory, String file, String value) throws Exception {
        var path = directory.resolve(file); Files.createDirectories(path.getParent()); Files.writeString(path, value + "\n");
    }
}
