# P04 current-source public differential corpus

Prepared 2026-09-27. This is legacy characterization of reviewed P03 candidate **`be423b3f99c5f1e3bb4ea159e2610ecc5e63596a`**, tree **`e1bee2a7712ff95f14b2c3513f565ff6c26bde8b`**. It is not accepted-main binding, P03 qualification, P04 implementation/acceptance, a performance benchmark, or a learning/holdout claim. The controller will record an equal-tree accepted-main binding after merge. Read `p04-controller-rulings.md`; production remains gated on its release conditions.

The final harness compiled from current production source and ran in **two independent fresh JVMs with all 15 result files byte-identical**. It captured **24 target-search cases, 8 expression identity pairs, 3 state identity pairs, 10 cursor cases, and 2 source-only quality cases**. All selected target-search witnesses, all emitted cursor candidates and the selected quality witnesses were independently replayed with the existing registered verifier. `verification.json`, complete result data, source/toolchain bindings and the executable generator are the evidence; the tables below are summaries.

## Reproduce and provenance

From repository root:

```bash
python .superpowers/sdd/2026-09-20-work-replacement/p04-current-corpus-preparation/generator/run.py
```

This is a sibling copy of the historical concrete fixture/runner, extended only in this ignored preparation directory. It pins both commit and tree, rejects tracked production differences, hashes production Java/resource inputs from seven modules, directly compiles the probe and transitively needed production classes with `javac -proc:none`, explicitly includes installed ServiceLoader implementations, then compares every result byte from two fresh JVMs. It rejects source/HEAD changes during execution. It uses no repository build classfiles, Gradle, full tests or gates. `commands.jsonl` preserves the exact final javac/java argument arrays and `execution-logs.json` preserves their raw stdout/stderr (javac deprecation notes, no errors; each JVM reports 24 searches and 8 Expr pairs).

Default JDK: `/tmp/regelsuche-runtime/jdk-25.0.2+10`; default Maven dependency cache: `/workspace/scratch/38625e9262ff/m2`. `P04_JDK` and `P04_MAVEN_CACHE` may replace these paths; toolchain/dependency hashes bind the actual inputs. Each compile or JVM subprocess has a 180-second timeout. JVM heap is capped at 768 MiB, UTF-8, en_US locale. The runner writes only here; build classes, temporary directories and raw duplicate runs are under `build/`. Result/export bytes are not a CPU, heap or allocation ledger.

Dependencies are Jackson databind/core/dataformat-yaml/datatype-jsr310 2.22.2, Jackson annotations 2.22, and SnakeYAML 2.5. The existing cache lacked 2.5; 2.6/2.2 were not substituted. Exact 2.5 was downloaded into this directory with:

```bash
curl -fLsS --max-time 30 https://repo.maven.apache.org/maven2/org/yaml/snakeyaml/2.5/snakeyaml-2.5.jar -o .superpowers/sdd/2026-09-20-work-replacement/p04-current-corpus-preparation/build/dependencies/snakeyaml-2.5.jar
curl -fLsS --max-time 30 https://repo.maven.apache.org/maven2/org/yaml/snakeyaml/2.5/snakeyaml-2.5.jar.sha1 -o .superpowers/sdd/2026-09-20-work-replacement/p04-current-corpus-preparation/build/dependencies/snakeyaml-2.5.jar.sha1
```

Python hashlib verified the downloaded bytes against that published SHA-1. `dependency-download.json` records both URLs, artifact path, published/actual SHA-1, byte count and SHA-256 `e6682acf1ace77508ef13649cbf4f8d09d2cf5457bdb61d25ffb6ac0233d78dd`; `source-binding.json` binds absolute paths and SHA-256 for all six JARs. No dependency download, compilation or fixture execution failed. There were two bounded harness invocations: an initial successful run, then the final two-JVM run after adding explicit zero-allowance-at-phase and no-double-billing assertions. This is not production RED/GREEN evidence.

The historical `p04-corpus-preparation/` was not modified or its pin bypassed. `historical-preservation.json` hashes its non-build deliverables, and the final runner verifies them unchanged. The original 16 complete case objects are also exactly equal to the first 16 current case objects; current additions do not reinterpret historical counters. No tracked file, index, branch or commit was changed. No sealed FINAL/evaluator data or generator was accessed, no subagents used, and nothing was externally published.

## Complete projections and actual search outcomes

`results/cases.json` retains inputs as canonical tagged ASTs, normalized assumptions/phase, exact budgets, mode/scheduling/continuation, policy/provider descriptors, and unchanged full `LearnedSchedulingArtifacts.resultJson` for each run: ordered events/decisions, states/assessments, witness/metadata, counters, completeness, and incremental receipts where present. Explicit final-replay receipts/work and accounting-complete/budget predicates are retained separately. `withinBudgetAfterReplay` also requires `accountingComplete`; it is not a success predicate for an inconclusive search.

| Case | Observed outcome | Search work | Independent replay work | Generated successors |
| --- | --- | ---: | ---: | ---: |
| `primitive-exact-rational` | TARGET_REACHED | 13 | 3 | 1 |
| `primitive-large-exact-decimal` | TARGET_REACHED | 13 | 3 | 1 |
| `primitive-scoped-symbol` | TARGET_REACHED | 13 | 3 | 1 |
| `scope-must-not-reach-other-x` | INCONCLUSIVE | 17 | 0 | 1 |
| `primitive-preserves-grouping` | TARGET_REACHED | 13 | 3 | 1 |
| `grouping-is-not-a-goal-equivalence` | INCONCLUSIVE | 17 | 0 | 1 |
| `opaque-order-preserved` | INCONCLUSIVE | 17 | 0 | 1 |
| `primitive-assumption-present` | TARGET_REACHED | 13 | 3 | 1 |
| `primitive-assumption-absent` | BOUNDED_EXHAUSTED | 4 | 0 | 0 |
| `primitive-tight-work-budget` | WORK_EXHAUSTED | 7 | 0 | 1 |
| `actual-learned-program` | TARGET_REACHED | 40 | 13 | 1 |
| `actual-learned-schema-scoped-rational` | TARGET_REACHED | 132 | 35 | 2 |
| `schema-rejects-opaque-function-domain` | INCONCLUSIVE | 10 | 0 | 0 |
| `schema-rejects-variable-division-domain` | INCONCLUSIVE | 10 | 0 | 0 |
| `schema-assumption-absent` | BOUNDED_EXHAUSTED | 5 | 0 | 0 |
| `schema-assumption-present` | TARGET_REACHED | 132 | 35 | 2 |
| `p02-typed-primitive-batch` | TARGET_REACHED | 17 | 3 | 1 |
| `p02-typed-batch-tight-budget` | WORK_EXHAUSTED | 10 | 0 | 1 |
| `p03-registered-scoped-rational` | TARGET_REACHED | 82 | 35 | 1 |
| `p03-schema-with-primitive-fallback` | TARGET_REACHED | 89 | 35 | 1 |
| `p03-registered-tight-budget` | WORK_EXHAUSTED | 22 | 0 | 0 |
| `continuation-path-sensitive-stateless` | INCONCLUSIVE | 71 | 0 | 6 |
| `continuation-declared-state-local` | INCONCLUSIVE | 61 | 0 | 4 |
| `continuation-history-gated-path-sensitive` | TARGET_REACHED | 49 | 6 | 3 |

Default target-search budget is primitive steps 6, search depth 2, theory work 100, states 64, total work 30,000, and existing default complexity-debt bound `Integer.MAX_VALUE`. The learned-program fixture uses depth 1 and theory work 0. Tight-work cases set total work to 1 (historical primitive), 5 (P02 primitive batch), or 10 (P03 registered). Every row includes its full actual budget. Primitive fixture transports have growth/candidate bounds 32/32. Modes remain FAST; the original cases use STAGED/PATH_SENSITIVE and current cases explicitly record their differing scheduling/continuation.

The two stateless continuation cases compare the same typed primitive relation under PATH_SENSITIVE and DECLARED_STATE_LOCAL: structural reached-expression sets agree and the latter actually records DOMINATED decisions. They do not promise identical event traces or work. The history case permits route-a/route-b only at depth 0 and the final primitive only after previousRule=route-b; it succeeds under PATH_SENSITIVE with independent primitive replay. The eligibility contract is recorded in `continuation-contracts.json`; it is not falsely declared state-local. `state-identities.json` separately retains equal expressions with differing assumptions, previous rule or capabilities.

Expression identity cases preserve exact numeric values, scoped symbols/aliases, equal independent allocations, grouping, ordered arguments and unequal equivalent scalar syntax. The opaque `orderedProduct` fixture tests ordering only: no new noncommutative algebra or schema domain is authorized. Existing negatives preserve missing-assumption and wrong-source replay rejection; schema opaque-function/variable-division rejection remains unchanged.

## Actual P02/P03 receipts

`results/cursor-cases.json` retains every next/zero-pull/close snapshot, allowance, emitted full Transformation, definition, compilation receipt, full mathematics, paid metrics, per-phase calls/work, open/abandoned payments, status, resumability, accounting flag and independent replay receipts. The cursor inputs use the same real learned/restored schema as target search. `cursor-eager-reference.json` retains the complete actual eager batch for the two-occurrence public input; each of three drains is checked equal to its full ordered transformations, not merely endpoints.

| Cursor case | Paid cursor work incl. close | Emitted | Completed exact steps | Abandoned applications | Independent replay work | Final status |
| --- | ---: | ---: | ---: | ---: | ---: | --- |
| `zero-allowance-close` | 1 | 0 | 0 | 0 | 0 | CLOSED |
| `close-after-SUBSTITUTION_DOMAIN` | 45 | 0 | 0 | 1 | 0 | CLOSED |
| `close-after-INSTANTIATION` | 55 | 0 | 0 | 1 | 0 | CLOSED |
| `close-after-TARGET_DOMAIN` | 72 | 0 | 0 | 1 | 0 | CLOSED |
| `close-after-EVIDENCE` | 74 | 0 | 1 | 0 | 0 | CLOSED |
| `drain-allowance-2` | 271 | 2 | 2 | 0 | 102 | INCONCLUSIVE |
| `drain-allowance-16` | 219 | 2 | 2 | 0 | 102 | INCONCLUSIVE |
| `drain-allowance-100000` | 209 | 2 | 2 | 0 | 102 | INCONCLUSIVE |
| `missing-assumptions` | 2 | 0 | 0 | 0 | 0 | EXHAUSTED |
| `unsupported-variable-division` | 9 | 0 | 0 | 0 | 0 | INCONCLUSIVE |

Small pulls stop after each returning phase, and a zero-allowance pull then leaves the snapshot unchanged. Close after substitution/instantiation/target checks abandons a paid application without creating mathematics. Close after EVIDENCE retains one completed exact application despite zero emitted candidates. Close is idempotent and post-close pulls do nothing. Complete drains retain exactly two applications across allowances 2/16/100,000; extra small pulls cost additional operations, not repeated theorem work. Every cursor case explicitly asserts that billable candidate mathematics is zero and total paid work equals operation units + prepaid units + phase-event count. This validates observed prepayment projection without treating its payment ticket as proof.

The selected schema is a subset of the restored library, so successful full drains still finish INCONCLUSIVE for the library-wide relation. Missing assumptions finish EXHAUSTED for that provider admission; neither status is a theorem of global unreachability. Raw phase records retain EVIDENCE with zero work but one phase event per application. Maximum harness pulls per cursor case are 10,000, checked for termination; actual maximum here is 66. No bound is increased.

`matcher-plan.json` binds the existing `v3-prepaid` provider definition, `v2-prepaid-phases` compilation receipt, selected schema, model/configuration and inventory/checker semantics. Matcher plan compilation work is 465. It remains outside per-query work and is explicitly retained; its cost is not free.

## Source-only quality and retained lifecycle costs

`results/quality-cases.json` retains full legacy search JSON, source-only declaration, node-count objective and threshold, input/output scores, incumbent, budget, provider descriptors, all actual admission/final-replay calls in order, query/replay totals and accounting/budget predicates. The last `finalReplayCallCount` calls are the existing source-only independent final check. Both outcomes are QUALITY_REACHED, both remain within budget after final replay, and the complete incumbent expressions are asserted equal.

| Case | Node score | Query work | Final replay | Additional lazy-plan compilation | Generated successors |
| --- | --- | ---: | ---: | ---: | ---: |
| `quality-eager` | 23 → 15 | 197 | 51 | 0 | 2 |
| `quality-prepaid-incremental` | 23 → 15 | 159 | 51 | 465 | 1 |

Quality budget: primitive steps 6, depth 1, theory work 1,000, states 32, total work 100,000; threshold is source node count minus 1. The objective charges one unit per visited occurrence. This shows early stopping before the second lazy application under the existing frontier; it is not a speedup or amortization claim, particularly given additional preparation work.

`training/` retains actual inputs/limits, formation, inventory, canonical learned model and fresh load/reproof. Observed costs: training search 188, training primitives 24, formation total 2,734, schema formation 702, restore/reproof 582. They are separately scoped existing logical receipts, not necessarily disjoint summands; do not blindly add them into a lifecycle total. Training uses the unchanged four public `TraceStrategyTransferExample` inputs and existing limits, including training total work 30,000, states 80, candidates/state 32, primitive/expanding steps 6; formation bounds and minimality limits are fully serialized.

Actual restored schema bounds: expression nodes 512, pattern nodes 128, depth 64, coefficient bits 256, exponent 32, examples 128, pair attempts 256, schemas 32, match attempts 256, candidates 32. Historical eager schema cases select up to 4 schemas/occurrence; the current plan selects one named actual schema and max 1/occurrence. Existing expression codec, primitive transport and program bounds remain enforced by production code. This corpus does not exercise every upper-limit boundary.

## Hashes and use for P04

`hash-manifest.json` covers the final report, generator, bindings, command/log evidence and all results; it excludes itself and replaceable build files. The final manifest digest is returned separately. The following stable content bindings identify the final executed generator and observed data:

| Artifact | SHA-256 |
| --- | --- |
| `source-binding.json` | `89436a7085123994aee0775e5ba65bfb4a1425cac487d93da3a84dd4e2b520bf` |
| `toolchain.json` | `ac79150d7ef951b874b763b661afe79dbeccfcbfee9c855390b756ce4663f295` |
| `verification.json` | `6cdc1cbbb85f0496f229595e033516679f771c6941bc98f6e4a6344606c7fb32` |
| `generator/LegacyExprCorpus.java` | `6b291db8cca63f4a79c8a766a0aec2af51249081797d58991b5d0fe8246ef377` |
| `generator/run.py` | `a4568bf7ab5d822ce5b53994bc1234ddf341516f65c8e05ddf69681a91caa986` |
| `results/cases.json` | `886912a5d6726c6062fd483bae1ba4f61f8054d0e6d6ec3296d6180c81ea5c3a` |
| `results/cursor-cases.json` | `db95e5b3427fca0d6066b018ab1722ab92c0f8202b8c1a7930b2939b96ebf6ca` |
| `results/quality-cases.json` | `8924da022f30d3750162033d8b05080cf0003d95069561dff3b2627937a13cec` |
| `historical-preservation.json` | `689b01a1cabb07fdaefe356eab2e045ab4dcecac2652e3ed1716032ba855dddc` |
| `dependency-download.json` | `e863221ffd5ad911311fb9a52f0d6713ff8a65863c9e272cf8f3571340ab5acc` |

Use these full projections as public legacy characterization for the same declared contract. A future native work revision must retain its own paid storage/export accounting; equality of historical counters across different revisions is not promised. Native P04 must additionally test zero AST-JSON calls through generation/scoring/admission/final replay, private capability authorization, forced hash collisions, foreign/closed session refs, total retention including store and suspended phases, result ownership, eviction and parallel isolation. None of those native properties is claimed by this legacy corpus. P05 proof reuse remains separate.
