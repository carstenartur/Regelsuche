#!/usr/bin/env python3
"""Compile only this probe and its source dependencies; write only inside preparation/."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent.parent
ROOT = HERE.parents[3]
PIN = 'be423b3f99c5f1e3bb4ea159e2610ecc5e63596a'
MODULES = ['regelsuche-core', 'regelsuche-egraph', 'regelsuche-search', 'regelsuche-validation',
           'regelsuche-math-algorithms', 'regelsuche-solver-ir', 'regelsuche-learning']
JDK = Path(os.environ.get('P04_JDK', '/tmp/regelsuche-runtime/jdk-25.0.2+10'))
TREE = 'e1bee2a7712ff95f14b2c3513f565ff6c26bde8b'
BUILD = HERE / 'build'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def write(path, value):
    path.write_text(json.dumps(value, sort_keys=True, indent=2) + '\n')

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def source_files():
    # Deliberately limited to public production source/resource trees; no corpus directories.
    return sorted(p for module in MODULES for kind in ['java', 'resources']
                  for p in (ROOT / module / 'src/main' / kind).rglob('*') if p.is_file())

def hashes(paths, base):
    return {str(path.relative_to(base)): sha(path) for path in paths}

def run(command, log):
    with (BUILD / 'commands.jsonl').open('a') as commands:
        commands.write(json.dumps([str(x) for x in command]) + '\n')
    with log.open('w') as output:
        subprocess.run([str(x) for x in command], cwd=HERE, stdout=output,
                       stderr=subprocess.STDOUT, check=True, timeout=180)

def main():
    if git('rev-parse', 'HEAD') != PIN or git('rev-parse', 'HEAD^{tree}') != TREE:
        raise SystemExit('Source HEAD differs from pinned characterization base; use that checkout.')
    if git('diff', 'HEAD', '--', *[m + '/src/main' for m in MODULES]):
        raise SystemExit('Production inputs differ from pinned source.')
    BUILD.mkdir(exist_ok=True)
    (BUILD / 'commands.jsonl').write_text('')
    classes = BUILD / 'classes'
    if classes.exists(): shutil.rmtree(classes)
    classes.mkdir()
    temp = BUILD / 'tmp'; temp.mkdir(exist_ok=True)
    sources = source_files()
    source_hashes = hashes(sources, ROOT)
    cache = Path(os.environ.get('P04_MAVEN_CACHE', '/workspace/scratch/38625e9262ff/m2'))
    coordinates = [('com.fasterxml.jackson.core', 'jackson-databind', '2.22.2'),
                   ('com.fasterxml.jackson.core', 'jackson-core', '2.22.2'),
                   ('com.fasterxml.jackson.core', 'jackson-annotations', '2.22'),
                   ('com.fasterxml.jackson.dataformat', 'jackson-dataformat-yaml', '2.22.2'),
                   ('com.fasterxml.jackson.datatype', 'jackson-datatype-jsr310', '2.22.2'),
                   ('org.yaml', 'snakeyaml', '2.5')]
    jars = []
    for group, artifact, version in coordinates:
        matches = list((cache / group.replace('.', '/') / artifact / version).glob('*.jar'))
        if not matches: matches = list((cache / group / artifact / version).glob('*/*.jar'))
        if not matches: matches = list((BUILD / 'dependencies').glob(f'{artifact}-{version}.jar'))
        if len(matches) != 1: raise SystemExit(f'Expected one cached jar for {group}:{artifact}:{version}')
        jars.extend(matches)
    sourcepath = os.pathsep.join(str(ROOT / m / 'src/main/java') for m in MODULES)
    resources = [ROOT / m / 'src/main/resources' for m in MODULES if (ROOT / m / 'src/main/resources').is_dir()]
    # ServiceLoader implementations are not reached by javac's ordinary dependency traversal.
    service_sources = set()
    for resource in resources:
        for descriptor in (resource / 'META-INF/services').glob('*'):
            for line in descriptor.read_text().splitlines():
                name = line.split('#', 1)[0].strip()
                if not name: continue
                candidates = [ROOT / m / 'src/main/java' / (name.replace('.', '/') + '.java') for m in MODULES]
                service_sources.update(p for p in candidates if p.is_file())
    cp = os.pathsep.join(map(str, jars))
    run([JDK / 'bin/javac', '-J-Djava.io.tmpdir=' + str(temp), '-encoding', 'UTF-8', '-proc:none',
         '-sourcepath', sourcepath, '-classpath', cp, '-d', classes,
         HERE / 'generator/LegacyExprCorpus.java', *sorted(service_sources)], BUILD / 'compile.log')
    runtime = os.pathsep.join(map(str, [classes, *resources, *jars]))
    runs = []
    for index in [1, 2]:
        destination = BUILD / f'run-{index}'
        if destination.exists(): shutil.rmtree(destination)
        destination.mkdir()
        run([JDK / 'bin/java', '-Xmx768m', '-Dfile.encoding=UTF-8', '-Duser.language=en', '-Duser.country=US',
             '-Djava.io.tmpdir=' + str(temp), '-cp', runtime, 'de.regelsuche.preparation.LegacyExprCorpus', destination],
            BUILD / f'run-{index}.log')
        runs.append(hashes(sorted(p for p in destination.rglob('*') if p.is_file()), destination))
    if runs[0] != runs[1]: raise SystemExit('Independent JVM outputs differ; reference not reproducible.')
    if source_hashes != hashes(source_files(), ROOT) or git('rev-parse', 'HEAD') != PIN:
        raise SystemExit('Source changed during probe; refusing reference publication.')
    target = HERE / 'results'
    if target.exists(): shutil.rmtree(target)
    target.mkdir()
    shutil.copytree(BUILD / 'run-1', target, dirs_exist_ok=True)
    shutil.copyfile(BUILD / 'commands.jsonl', HERE / 'commands.jsonl')
    write(HERE / 'execution-logs.json', {name: (BUILD / name).read_text() for name in ['compile.log', 'run-1.log', 'run-2.log']})
    write(HERE / 'source-binding.json', {'sourceCommit': PIN, 'sourceTree': git('rev-parse', 'HEAD^{tree}'), 'bindingRole': 'Reviewed P03 candidate; accepted-main equal-tree binding is a separate controller record',
        'modules': MODULES, 'filesSha256': source_hashes, 'probeSourcesSha256': hashes(sorted((HERE / 'generator').glob('*')), HERE),
        'dependenciesSha256': {str(p.resolve()): sha(p) for p in jars}, 'compilation': 'javac from pinned main sources, no repository build classes'})
    version = subprocess.run([str(JDK / 'bin/java'), '-version'], capture_output=True, text=True, check=True)
    write(HERE / 'toolchain.json', {'javaVersion': version.stderr.strip(), 'javaSha256': sha(JDK / 'bin/java'),
        'javacSha256': sha(JDK / 'bin/javac'), 'jdkModulesSha256': sha(JDK / 'lib/modules'),
        'releaseSha256': sha(JDK / 'release'), 'maxHeap': '768m', 'encoding': 'UTF-8', 'locale': 'en_US'})
    write(HERE / 'verification.json', {'independentJvmRuns': 2, 'allOutputBytesIdentical': True,
        'resultFilesSha256': runs[0], 'searchCases': len(json.loads((target / 'cases.json').read_text())),
        'identityPairs': len(json.loads((target / 'identities.json').read_text())),
        'cursorCases': len(json.loads((target / 'cursor-cases.json').read_text())),
        'qualityCases': len(json.loads((target / 'quality-cases.json').read_text())),
        'scope': 'Development characterization only; no performance or new P04 acceptance claim.'})
    deliverables = [*sorted((HERE / 'generator').glob('*')), *sorted(p for p in target.rglob('*') if p.is_file()),
                    HERE / 'source-binding.json', HERE / 'toolchain.json', HERE / 'verification.json', HERE / 'historical-preservation.json', HERE / 'dependency-download.json', HERE / 'commands.jsonl', HERE / 'execution-logs.json', HERE / 'REPORT.md']
    write(HERE / 'hash-manifest.json', {'algorithm': 'SHA-256', 'files': hashes(deliverables, HERE)})
    old = HERE.parent / 'p04-corpus-preparation'
    for name, digest in json.loads((HERE / 'historical-preservation.json').read_text()).items():
        if sha(old / name) != digest: raise SystemExit('Historical corpus changed: ' + name)
    print('hash-manifest.json sha256:' + sha(HERE / 'hash-manifest.json'))
    print('Verified two fresh JVMs with byte-identical results.')

if __name__ == '__main__':
    main()
