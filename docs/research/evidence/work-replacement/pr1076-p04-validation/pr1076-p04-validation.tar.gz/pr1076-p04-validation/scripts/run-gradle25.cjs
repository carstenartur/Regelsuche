const { spawnSync } = require('node:child_process');
const env = { ...process.env };
env.JAVA_HOME = '/tmp/regelsuche-runtime/jdk-25.0.2+10';
env.PATH = `${env.JAVA_HOME}/bin:/tmp/regelsuche-runtime/apache-maven-3.9.9/bin:${env.PATH}`;
const options = ['-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts'];
for (const [protocol, raw] of [['http', env.HTTP_PROXY], ['https', env.HTTPS_PROXY]]) {
  if (!raw) continue;
  const proxy = new URL(raw);
  if (proxy.username || proxy.password) throw new Error('Authenticated proxy requires explicit configuration');
  options.push(`-D${protocol}.proxyHost=${proxy.hostname}`, `-D${protocol}.proxyPort=${proxy.port || '80'}`);
}
env.JAVA_TOOL_OPTIONS = [env.JAVA_TOOL_OPTIONS || '', ...options].join(' ');
const result = spawnSync('/tmp/regelsuche-runtime/gradle-9.7.1/bin/gradle', [...options, ...process.argv.slice(2)], { env, stdio: 'inherit' });
if (result.error) throw result.error;
process.exit(result.status ?? 1);
