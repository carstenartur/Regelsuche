// Mechanical evidence packaging; does not modify the source checkout or baselines.
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const cp = require('node:child_process');
const here = __dirname;
const repo = path.resolve(here, '../Regelsuche');
const packet = path.join(here, 'pr1076-p04-validation');
const recovered = path.join(here, 'pr1065-recovered/pr1065-p04-structural-index');
const expectedHead = '151826e648da62784574573b0980da42d3b68beb';
const base = '8a98a14e6713225801832918befd7c12d5cb74ba';
const git = (...args) => cp.execFileSync('git', ['-C', repo, ...args], {encoding: 'utf8'}).trim();
const sha = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
if (git('rev-parse', 'HEAD') !== expectedHead || git('status', '--porcelain'))
  throw new Error('Unexpected or dirty source head');
fs.mkdirSync(packet); // Refuse to overwrite an existing packet.
function copy(source, relative) {
  const destination = path.join(packet, relative);
  fs.mkdirSync(path.dirname(destination), {recursive: true});
  fs.copyFileSync(source, destination);
}
function copyTree(source, relative, accepted = () => true) {
  for (const item of fs.readdirSync(source, {withFileTypes: true})) {
    const from = path.join(source, item.name);
    const to = path.join(relative, item.name);
    if (item.isDirectory()) {
      if (!['binary', 'classes', 'tmp'].includes(item.name)) copyTree(from, to, accepted);
    } else if (item.isFile() && accepted(item.name)) copy(from, to);
  }
}
copy(path.join(here, 'pr1076-README.md'), 'README.md');
copy(path.join(here, 'pr1076-review.md'), 'review/result.md');
copyTree(path.join(here, 'review-probes'), 'review/probes');
const ledger = path.join(repo, '.superpowers/sdd/2026-09-20-work-replacement');
copy(path.join(ledger, 'progress.md'), 'execution-ledger.md');
copy(path.join(ledger, 'review-p04-validation.md'), 'review/contract.md');
copy(__filename, 'scripts/package-pr1076.cjs');
for (const name of fs.readdirSync(here)) {
  if (/^p04-validation.*\.log$/.test(name)) copy(path.join(here, name), 'logs/' + name);
  if (name.endsWith('-xml') || name === 'pre-review-modules')
    copyTree(path.join(here, name), 'attempts/' + name, name => name.endsWith('.xml'));
}
const counts = {};
for (const module of ['core', 'search', 'learning']) {
  const directory = path.join(repo, 'regelsuche-' + module, 'build/test-results/test');
  counts[module] = {tests: 0, failures: 0, errors: 0, skipped: 0};
  for (const file of fs.readdirSync(directory).filter(name => /^TEST-.*\.xml$/.test(name))) {
    const source = path.join(directory, file);
    const header = fs.readFileSync(source, 'utf8').match(/<testsuite\s[^>]*>/)[0];
    for (const key of Object.keys(counts[module]))
      counts[module][key] += Number(header.match(new RegExp(key + '="(\\d+)"'))[1]);
    copy(source, 'final-xml/' + module + '/' + file);
  }
}
if (JSON.stringify(Object.values(counts).map(c => c.tests)) !== '[1058,604,1058]' ||
    Object.values(counts).some(c => c.failures || c.errors || c.skipped))
  throw new Error('Final XML does not match verified counts');
for (const file of ['complexity.json', 'metrics-snapshot.json', 'check.json', 'evidence.json'])
  copy(path.join(repo, 'build/ai-knowledge', file), 'complexity/' + file);
for (const file of ['run-gradle25.cjs', 'extractor-javac25.init.gradle'])
  copy(path.join(recovered, file), 'scripts/' + file);
copy(path.join(here, 'compare-p03.py'), 'public-p03/compare-p03.py');
copy(path.join(recovered, 'public-p03/LegacyExprCorpus.java'), 'public-p03/LegacyExprCorpus.java');
copyTree(path.join(recovered, 'public-p03/baseline'), 'public-p03/baseline');
for (const [directory, label] of [
  ['p04-validation-compatibility', 'local-same-tree'],
  ['p04-validation-published-compatibility', 'published-head']
]) copyTree(path.join(here, directory), 'public-p03/' + label);
const report = JSON.parse(fs.readFileSync(path.join(here, 'p04-validation-published-compatibility/report.json')));
if (report.sourceHead !== expectedHead || !report.all15P03FilesByteIdentical || !report.twoFreshJvmsIdentical)
  throw new Error('Public P03 result is not bound to published source');
fs.writeFileSync(path.join(packet, 'source.patch'), cp.execFileSync('git', ['-C', repo, 'diff', base, expectedHead]));
const binding = {
  capturedAt: new Date().toISOString(), sourceHead: expectedHead, sourceTree: git('rev-parse', 'HEAD^{tree}'),
  baseHead: base, localSameTreeCommit: 'b0883b6d3c7d968ef292c927ed5a6fdc7eb1bb53',
  sourceStatus: 'clean', pr: 1076, java: '25.0.2+10', gradle: '9.7.1',
  extractorTag: 'v0.1.10', extractorCommit: 'b409bed957c31d63ce7b6ef37205890f0f0ebd9a',
  tests: counts, totalTests: 2720, newValidationRegressions: 12,
  complexity: {status: 'PASSED', hotspots: 17, thresholdsChanged: false},
  publicP03: report, independentReview: {critical: 0, important: 0, minor: 0,
    callbackFailureSites: 1366, failureModes: 2, codecDifferentials: 2000},
  nativeRevision: 'regelsuche.native-expr-move-search/v6-partial-validation-retention',
  coverage: 'PARTIAL_ATOMIC_INVENTORY', publicOutcome: 'INCONCLUSIVE', withinBudget: false,
  p04Complete: false, hostedCiAtCapture: {runId: 37938454239, status: 'pending'},
  priorEvidenceArchiveSha256: sha(path.join(here, 'pr1065.tar.gz'))
};
fs.writeFileSync(path.join(packet, 'source-binding.json'), JSON.stringify(binding, null, 2) + '\n');
const manifest = {};
function inventory(directory) {
  for (const item of fs.readdirSync(directory, {withFileTypes: true}).sort((a, b) => a.name.localeCompare(b.name))) {
    const file = path.join(directory, item.name);
    if (item.isDirectory()) inventory(file);
    else manifest[path.relative(packet, file)] = sha(file);
  }
}
inventory(packet);
fs.writeFileSync(path.join(packet, 'sha256.json'), JSON.stringify(manifest, null, 2) + '\n');
const archive = path.join(here, 'pr1076-p04-validation.tar.gz');
if (fs.existsSync(archive)) throw new Error('Archive already exists');
cp.execFileSync('tar', ['-czf', archive, '-C', here, path.basename(packet)]);
console.log(JSON.stringify({files: Object.keys(manifest).length, counts, archive,
  bytes: fs.statSync(archive).size, sha256: sha(archive)}, null, 2));
