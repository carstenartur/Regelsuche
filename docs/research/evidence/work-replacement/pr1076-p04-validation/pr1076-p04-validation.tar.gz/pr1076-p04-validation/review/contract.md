# Whole-branch review: P04 validation ownership

Base: `8a98a14e6713225801832918befd7c12d5cb74ba`. Review the committed branch head
given in the dispatch, not unrelated current PRs. Repository:
`/workspace/scratch/4e87c3dfd845/Regelsuche`.

Specification: user-authorized P04 in
`docs/superpowers/plans/2026-09-20-work-replacement.md`, global constraints and
Task 4; current boundary in `docs/research/native-expr-qualification.md`.
Execution decisions and all negative attempts are in the sibling `progress.md`.

This is one bounded continuation, not completed P04. No AST JSON transport,
second frontier, new learner, changed proof authority, changed budget, new runtime
dependency or promoted accounting coverage. V6 remains partial, INCONCLUSIVE and
never reports withinBudget=true. JDK formatting internals and other atomic regions
remain explicitly unqualified.

The change makes direct expression/history validation iterative with an actual
append-only per-inspection visit arena, bounded by the existing 10,000 occurrences
per state. It retains and separately charges completed numeric/symbol text, observes
growth in batches and before release, and preserves paid attempts/primary failures.
Input observation failures enter the existing kernel's normal receipt path.

Review focus (deliberately inspect each):

1. Canonical bytes/characters, Unicode, order, source/history limits and rejected
   inputs remain consistent with the existing codec; no false valid result.
2. Failed acquisition, allocation/validation debit, observation, release or frame
   close cannot lose work, hide new ownership or replace the primary throwable.
3. Wide/deep/shared trees and multi-state histories cannot inflate pending scratch
   beyond the stated bound; no incorrect deduplication of occurrences.
4. Skipping an unchanged terminal observation cannot miss an intervening ownership
   increase; scalar buffers cannot overlap unobserved on replacement.
5. Early input resource failure cannot escape without its receipt or authorize an
   unvalidated state. Existing learned execution retains its original budget.

Report Critical/Important/Minor findings with file and line, concrete effect and
reproduction if available. List any declined-to-judge behavior explicitly. Do not
modify files or inspect sealed holdouts. One fresh-context final review is requested;
the implementer will address substantive findings once with RED/GREEN tests.

Do not run concurrent Gradle invocations: executor PID namespaces cause journal
lock conflicts. Read current test XML and logs first; coordinate any extra run.
The supplementary code-reviewer skill template could not be loaded from the
provider, so this package preserves the complete applicable review contract.
