# Independent whole-branch review

Range: `8a98a14e6713225801832918befd7c12d5cb74ba` to local
`b0883b6d3c7d968ef292c927ed5a6fdc7eb1bb53`, tree
`eb052f81047973154d99105273de5851b0c9b9a3`, identical to published
`151826e648da62784574573b0980da42d3b68beb`.
Reviewer: fresh-context `p04_validation_review`, 2026-10-09.

Critical: none found. Important: none found. Minor: none found.

The bounded slice was accepted. Review confirmed canonical bytes, Unicode,
occurrence counts and history limits remain consistent with the existing codec;
the arena bounds visited plus queued occurrences to 10,000 per state; skipping
an unchanged observation does not hide new ownership; scalar buffers are observed
and released before the next node; cleanup preserves primary failures across
acquisition, debit, observation, release and close; early input resource exhaustion
reaches the kernel receipt path before state creation.

Independent verification passed 1,366 callback failure sites x two failure modes
and 2,000 expression/history codec differentials. Reviewer independently counted
2,720 XML tests with zero failures/errors/skips and checked the passing unchanged
complexity gate (17 hotspots). Worktree remained clean. The executable probe and
its command/result are included under `review/probes/`.

Declined-to-judge boundaries: full P04 completion; physical JVM heap/OOM guarantees;
JDK-internal formatting allocations; unchanged PR #1065 store behavior; sealed
holdouts; independent execution of parent-owned public P03 and remote CI checks.
Parent rulings for each boundary are recorded in `execution-ledger.md`. No total
accounting or performance qualification follows from this review.
