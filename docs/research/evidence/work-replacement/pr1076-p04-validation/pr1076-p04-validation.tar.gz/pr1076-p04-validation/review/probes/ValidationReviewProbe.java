import de.regelsuche.ast.*;
import de.regelsuche.retention.*;
import de.regelsuche.search.program.*;
import de.regelsuche.transform.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public class ValidationReviewProbe {
    static class Sink implements RetainedOperation.Sink {
        final Expr input;
        RetainedOperation operation;
        boolean armed, repeating;
        int index, failAt;
        final RuntimeException primary = new RuntimeException("primary");
        Sink(Expr input) { this.input = input; }
        void event() {
            if (!armed) return;
            index++;
            if (index == failAt) throw primary;
            if (repeating && index > failAt) throw new RuntimeException("secondary");
        }
        public void executionWork(long units) { event(); }
        public void validationWork(long units) { event(); }
        public void checkpoint() { RetainedGraph.measure(this); event(); }
        public void retainedReferences(RetainedGraph.Visitor visitor) {
            visitor.reference(input); visitor.reference(operation);
        }
    }
    static int inspectWithFailure(Expr expression, int failAt, boolean repeating) {
        var sink = new Sink(expression);
        try (var operation = RetainedOperation.open(sink)) {
            sink.operation = operation;
            var initial = RetainedGraph.measure(sink).retained();
            sink.failAt = failAt; sink.repeating = repeating; sink.armed = true;
            boolean failed = false;
            try { AstExpressionValidation.inspect(expression); }
            catch (RuntimeException failure) {
                if (failure != sink.primary) throw new AssertionError("primary replaced at " + failAt, failure);
                failed = true;
            }
            finally { sink.armed = false; }
            if ((failAt != Integer.MAX_VALUE) != failed) throw new AssertionError("missing failure " + failAt);
            if (!initial.equals(RetainedGraph.measure(sink).retained())) throw new AssertionError("leak " + failAt);
            return sink.index;
        }
    }
    static final Random random = new Random(34751);
    static final String[] texts = {"x", "é", "😀", "x\n\"\\\u0001", "\u07ff\u0800", "z\t\b\f\r"};
    static Expr expression(int depth) {
        int kind = random.nextInt(depth == 0 ? 3 : 5);
        return switch (kind) {
            case 0 -> NumberExpr.exact((random.nextInt(2001) - 1000) + "/" + (1 + random.nextInt(99)));
            case 1 -> new VariableExpr(texts[random.nextInt(texts.length)]);
            case 2 -> VariableExpr.scoped(new de.regelsuche.symbol.SymbolId(new UUID(random.nextLong(), random.nextLong()), 1 + random.nextInt(100)));
            case 3 -> new BinaryExpr(expression(depth - 1), BinaryOperator.values()[random.nextInt(BinaryOperator.values().length)], expression(depth - 1));
            default -> {
                var arguments = new ArrayList<Expr>();
                for (int i = random.nextInt(5); i > 0; i--) arguments.add(expression(depth - 1));
                yield new FunctionExpr(texts[random.nextInt(texts.length)], arguments);
            }
        };
    }
    public static void main(String[] args) {
        var input = new FunctionExpr("f", List.of(NumberExpr.exact("123456789012345678901234567890/7"), new VariableExpr("é😀"), new BinaryExpr(new NumberExpr(2), BinaryOperator.ADD, new NumberExpr(3))));
        int events = 0;
        for (var tested : List.<Expr>of(new VariableExpr("x"), input, new FunctionExpr("wide", Collections.nCopies(260, new VariableExpr("x"))))) {
            int count = inspectWithFailure(tested, Integer.MAX_VALUE, false);
            events += count;
            for (int i = 1; i <= count; i++) {
                inspectWithFailure(tested, i, false);
                inspectWithFailure(tested, i, true);
            }
        }
        var codec = new CompiledAstReplayCodec();
        for (int i = 0; i < 2000; i++) {
            var expr = expression(4);
            var encoded = codec.encodeExpression(expr);
            var inspection = AstExpressionValidation.inspect(expr);
            if (encoded.length() != inspection.canonicalCharacters() || encoded.getBytes(StandardCharsets.UTF_8).length != inspection.canonicalBytes()) throw new AssertionError("expression mismatch " + i);
            var step = new AstRewriteTransport.Step(expr, expr, "ruleé😀", RewriteKind.SIMPLIFY, false, Integer.MIN_VALUE, true, List.of("x > 0"), "pack", "license");
            int length = 1 + random.nextInt(8);
            var history = new CompiledAstRewriteProgram.Candidate("program😀", Collections.nCopies(length, "stageé"), Collections.nCopies(length, step));
            byte[] bytes = codec.encode(history);
            var inspectedHistory = AstExpressionValidation.inspectHistory(history);
            if (bytes.length != inspectedHistory.canonicalBytes() || new String(bytes, StandardCharsets.UTF_8).length() != inspectedHistory.canonicalCharacters()) throw new AssertionError("history mismatch " + i);
        }
        System.out.println("PASS: " + events + " callback failure sites x 2 modes; 2000 expression/history canonical differentials");
    }
}
