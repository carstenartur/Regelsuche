# PR #1055 P03 public legacy compatibility

Local clean final head `f7fd207fec9a131e65c5e13cbd8b36e4b44d469f` and tree `3b90d3bb3f5056cb43050825dc2794e029d25be2` are byte-source bound to the published equal-tree head `2aa5ee849087a3ffb0972b5b410b1d58a710e2a7`. Probe SHA-256 `6b291db8cca63f4a79c8a766a0aec2af51249081797d58991b5d0fe8246ef377`; all six dependency hashes and the unchanged P03 result hashes are checked before execution.

Commands, compiler output, fresh JVM output, complete files and per-file JSON paths are retained here. Two JVMs agree: **True**. All 15 reference files byte-equal in both runs: **True**. See `report.json` for exact field differences. This tests only the historical legacy facade, not native total-accounting qualification.
