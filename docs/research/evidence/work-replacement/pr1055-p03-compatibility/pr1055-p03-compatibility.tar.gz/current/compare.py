#!/usr/bin/env python3
"""Read-only source-bound P03 legacy characterization on the final #1055 tree."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / "Regelsuche"
BASE = Path("/workspace/scratch/7ff736a22947/p04-recovery-sep28/evidence-v3/p04-current-corpus-preparation")
JDK = Path("/tmp/regelsuche-runtime/jdk-25.0.2+10")
LOCAL_HEAD = "f7fd207fec9a131e65c5e13cbd8b36e4b44d469f"
REMOTE_HEAD = "2aa5ee849087a3ffb0972b5b410b1d58a710e2a7"
TREE = "3b90d3bb3f5056cb43050825dc2794e029d25be2"
PROBE_SHA = "6b291db8cca63f4a79c8a766a0aec2af51249081797d58991b5d0fe8246ef377"
MODULES = ["regelsuche-core", "regelsuche-egraph", "regelsuche-search", "regelsuche-validation",
           "regelsuche-math-algorithms", "regelsuche-solver-ir", "regelsuche-learning"]
JAR_LOCATIONS = [
    Path("/workspace/scratch/31120679e672/verification-deps/lib/jackson-databind-2.22.2.jar"),
    Path("/workspace/scratch/31120679e672/verification-deps/lib/jackson-core-2.22.2.jar"),
    Path("/workspace/scratch/31120679e672/verification-deps/lib/jackson-annotations-2.22.jar"),
    Path("/workspace/scratch/31120679e672/verification-deps/lib/jackson-dataformat-yaml-2.22.2.jar"),
    Path("/workspace/scratch/31120679e672/verification-deps/lib/jackson-datatype-jsr310-2.22.2.jar"),
    Path("/workspace/scratch/7ff736a22947/regelsuche-m0/.superpowers/sdd/2026-09-20-work-replacement/p04-current-corpus-preparation/build/dependencies/snakeyaml-2.5.jar"),
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, data):
    (HERE / name).write_text(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n")


def git(*args):
    return subprocess.check_output(["git", "-C", str(ROOT), *args], text=True).strip()


def identity():
    return {"head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"),
            "status": git("status", "--porcelain=v1", "--untracked-files=all")}


def source_paths():
    return sorted(p for module in MODULES for kind in ("java", "resources")
                  for p in (ROOT / module / "src/main" / kind).rglob("*") if p.is_file())


def source_hashes():
    return {str(p.relative_to(ROOT)): sha(p) for p in source_paths()}


def results(path):
    return {str(p.relative_to(path)): sha(p) for p in path.rglob("*") if p.is_file()}


def run(command, label):
    with (HERE / "commands.jsonl").open("a") as stream:
        stream.write(json.dumps([str(a) for a in command]) + "\n")
    with (HERE / (label + ".log")).open("w") as output:
        subprocess.run([str(a) for a in command], cwd=HERE, stdout=output,
                       stderr=subprocess.STDOUT, check=True, timeout=180)


def differences(reference, actual, prefix="$", max_diffs=100):
    out = []
    def walk(a, b, path):
        if len(out) >= max_diffs:
            return
        if isinstance(a, dict) and isinstance(b, dict):
            for key in sorted(a.keys() | b.keys()):
                next_path = path + "[" + json.dumps(key, ensure_ascii=False) + "]"
                if key not in a or key not in b:
                    out.append({"path": next_path, "reference": a.get(key, "<ABSENT>"),
                                "actual": b.get(key, "<ABSENT>")})
                else:
                    walk(a[key], b[key], next_path)
        elif isinstance(a, list) and isinstance(b, list):
            if len(a) != len(b):
                out.append({"path": path + ".length", "reference": len(a), "actual": len(b)})
            for i in range(min(len(a), len(b))):
                walk(a[i], b[i], path + f"[{i}]")
        elif type(a) is not type(b) or a != b:
            out.append({"path": path, "reference": a, "actual": b})
    walk(reference, actual, prefix)
    return out


def main():
    initial = identity()
    if initial != {"head": LOCAL_HEAD, "tree": TREE, "status": ""}:
        raise RuntimeError("Final local source is not the clean expected tree: " + repr(initial))
    source_before = source_hashes()
    probe = HERE / "generator/LegacyExprCorpus.java"
    if sha(probe) != PROBE_SHA or sha(BASE / "generator/LegacyExprCorpus.java") != PROBE_SHA:
        raise RuntimeError("Legacy generator bytes changed")
    old_source = json.loads((BASE / "source-binding.json").read_text())
    # source-binding's map is sorted alphabetically; locate expected digest by basename.
    expected_by_name = {Path(k).name: v for k, v in old_source["dependenciesSha256"].items()}
    jars = {p: sha(p) for p in JAR_LOCATIONS}
    for jar, digest in jars.items():
        if digest != expected_by_name[jar.name]:
            raise RuntimeError("P03 dependency mismatch: " + str(jar))
    baseline_before = results(BASE / "results")
    pinned = json.loads((BASE / "verification.json").read_text())["resultFilesSha256"]
    if baseline_before != pinned or len(pinned) != 15:
        raise RuntimeError("P03 reference bytes do not match immutable verification receipt")

    (HERE / "commands.jsonl").write_text("")
    classes = HERE / "classes"
    if classes.exists():
        shutil.rmtree(classes)
    classes.mkdir()
    temp = HERE / "tmp"
    temp.mkdir(exist_ok=True)
    sourcepath = os.pathsep.join(str(ROOT / m / "src/main/java") for m in MODULES)
    resources = [ROOT / m / "src/main/resources" for m in MODULES
                 if (ROOT / m / "src/main/resources").is_dir()]
    services = set()
    for resource in resources:
        for descriptor in (resource / "META-INF/services").glob("*"):
            for line in descriptor.read_text().splitlines():
                name = line.split("#", 1)[0].strip()
                if name:
                    services.update(p for m in MODULES
                                    if (p := ROOT / m / "src/main/java" / (name.replace(".", "/") + ".java")).is_file())
    cp = os.pathsep.join(map(str, JAR_LOCATIONS))
    run([JDK / "bin/javac", "-J-Djava.io.tmpdir=" + str(temp), "-encoding", "UTF-8", "-proc:none",
         "-sourcepath", sourcepath, "-classpath", cp, "-d", classes, probe, *sorted(services)], "compile")
    runtime = os.pathsep.join(map(str, [classes, *resources, *JAR_LOCATIONS]))
    observed = []
    for i in (1, 2):
        destination = HERE / f"run-{i}"
        if destination.exists():
            shutil.rmtree(destination)
        destination.mkdir()
        run([JDK / "bin/java", "-Xmx768m", "-Dfile.encoding=UTF-8", "-Duser.language=en",
             "-Duser.country=US", "-Djava.io.tmpdir=" + str(temp), "-cp", runtime,
             "de.regelsuche.preparation.LegacyExprCorpus", destination], f"run-{i}")
        observed.append(results(destination))

    final = identity()
    if final != initial or source_hashes() != source_before or results(BASE / "results") != baseline_before:
        raise RuntimeError("Source or P03 baseline changed during verification")
    report = {"localSourceBefore": initial, "localSourceAfter": final,
              "qualifiedRemoteHeadSameTree": REMOTE_HEAD, "generatorSha256": sha(probe),
              "jdk": subprocess.run([str(JDK / "bin/java"), "-version"], capture_output=True,
                                    text=True, check=True).stderr.strip(),
              "jdkHashes": {name: sha(JDK / name) for name in ("bin/java", "bin/javac", "lib/modules", "release")},
              "jarSha256": {str(p): digest for p, digest in jars.items()},
              "productionInputs": len(source_before),
              "productionHashManifestSha256": hashlib.sha256(json.dumps(source_before, sort_keys=True).encode()).hexdigest(),
              "baselineSha256": pinned, "runSha256": observed,
              "independentJvmsIdentical": observed[0] == observed[1],
              "comparison": {}}
    for i in (1, 2):
        location = HERE / f"run-{i}"
        for name in sorted(set(pinned) | set(observed[i-1])):
            a = BASE / "results" / name
            b = location / name
            entry = {"byteEqual": a.is_file() and b.is_file() and a.read_bytes() == b.read_bytes()}
            if not entry["byteEqual"]:
                if a.is_file() and b.is_file():
                    try:
                        entry["jsonDifferences"] = differences(json.loads(a.read_text()), json.loads(b.read_text()))
                    except (UnicodeDecodeError, json.JSONDecodeError) as problem:
                        entry["parseError"] = str(problem)
                else:
                    entry["missing"] = "reference" if not a.is_file() else "current"
            report["comparison"][f"run-{i}/{name}"] = entry
    report["all15BytesEqualBothRuns"] = len(observed[0]) == len(observed[1]) == 15 and all(
        entry["byteEqual"] for entry in report["comparison"].values())
    write("report.json", report)
    (HERE / "REPORT.md").write_text(
        "# PR #1055 P03 public legacy compatibility\n\n"
        f"Local clean final head `{LOCAL_HEAD}` and tree `{TREE}` are byte-source bound to "
        f"the published equal-tree head `{REMOTE_HEAD}`. Probe SHA-256 `{PROBE_SHA}`; "
        "all six dependency hashes and the unchanged P03 result hashes are checked before execution.\n\n"
        "Commands, compiler output, fresh JVM output, complete files and per-file JSON paths are retained here. "
        f"Two JVMs agree: **{report['independentJvmsIdentical']}**. "
        f"All 15 reference files byte-equal in both runs: **{report['all15BytesEqualBothRuns']}**. "
        "See `report.json` for exact field differences. This tests only the historical legacy facade, "
        "not native total-accounting qualification.\n")
    write("artifact-hashes.json", {str(p.relative_to(HERE)): sha(p) for p in HERE.rglob("*")
                                   if p.is_file() and p.name != "artifact-hashes.json"})
    print("Two JVMs identical:", report["independentJvmsIdentical"])
    print("All 15 P03 results byte-identical in both runs:", report["all15BytesEqualBothRuns"])
    if not report["all15BytesEqualBothRuns"]:
        for name, entry in report["comparison"].items():
            if not entry["byteEqual"]:
                print(name, entry.get("jsonDifferences", entry.get("missing", entry.get("parseError"))))
        sys.exit(1)


if __name__ == "__main__":
    main()
