# Cognitive-complexity hotspot trend

Status: **PASSED**

| Status | Cognitive Δ | Cyclomatic Δ | Method |
| --- | ---: | ---: | --- |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/api/searchgraph/MacroSequenceClusterer.java :: public List<SearchGraphClusterDto> cluster(List<DiscoveredTransformation> transformations)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/api/searchgraph/semantic/SemanticSearchGraphAssembler.java :: private MainPathProjection buildMainPathProjection(DiscoveredTransformation mainPath, Map<String,String> rawExpressionToClusterId, Map<String,CanonicalExpressionCluster> clustersByHash, boolean showLowSignal, SemanticMacroStepDisplay showMacroSteps)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/docs/DiscoveryEvidenceSchemaV1.java :: private List<String> validate(JsonNode root, Path evidenceDirectory)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/docs/SearchSpaceGallerySvgWriter.java :: public String write(DiscoveryBenchmarkEvidence evidence, String evidenceFileName)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/docs/StaticReferencePageGenerator.java :: private String renderStatusOverview(ReferenceCampaignRunner.CampaignReport report)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/export/layout/AstAriaRenderer.java :: public static String ariaLabel(String expression, Locale locale)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/radar/RuleRadarSearchService.java :: public SearchResult search(SearchRequest requested)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `app/src/main/java/de/regelsuche/web/WebWorkbenchServer.java :: private void handleExports(HttpExchange exchange)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-autopilot/src/main/java/de/regelsuche/experiments/autopilot/AutonomousProductionLifecycleRunner.java :: private static void validateSuccessfulLifecycle(EvaluationReport evaluation, NoveltyReport novelty, ProofReport proof, HypothesisCandidate lifecycleCandidate, LifecycleDecision lifecycleDecision)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-core/src/main/java/de/regelsuche/transform/PatternMatchAnalyzer.java :: private static PartialState structuralCompare(PatternExpr pattern, Expr expression, int limit)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-experiments/src/main/java/de/regelsuche/example/ScientificSeedCorpora.java :: private static List<SeedExpression> parseYaml(String content)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-learning/src/main/java/de/regelsuche/evolution/EvolutionRewriteProgramAcceptanceThresholds.java :: private static void validate(int minimumImprovedFinalTestCases, int minimumDistinctImprovedFamilies, int minimumNewlyReachedCases, boolean allowMaterialWorkReductionRoute, int minimumMechanicalWorkReductionPermille, int minimumRetainedProgramPrimitiveSteps, boolean requireCompositionTopology, boolean requireDecisionTopology, int maximumCorrectnessRegressions, int maximumHiddenAssumptionRegressions, int maximumUnexpectedUnsupportedCases, int maximumTechnicalFailures, int maximumProgramNodes, int maximumGenomeRules, int requiredCleanReproductions, boolean requirePinnedContainerReproduction, SuccessRoute successRoute, NullResultPolicy nullResultPolicy)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-learning/src/main/java/de/regelsuche/mining/OpenTargetHypothesisCandidateAdapter.java :: private static void validate(OpenTargetConjecture conjecture, EvaluationReport evaluation, Instant createdAt)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-plugin-api/src/main/java/de/regelsuche/plugin/RuleFileParser.java :: RulePackage parse(Path path, List<String> lines)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-search/src/main/java/de/regelsuche/search/strategy/BeamSearchStrategy.java :: public List<SearchState> search(SearchProblem problem)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-solver-portfolio/src/main/java/de/regelsuche/solver/portfolio/SolverPortfolioExecutor.java :: public PortfolioRun execute(PortfolioRequest request, CancellationToken cancellationToken)` |
| UNCHANGED_OR_IMPROVED | +0 | +0 | `regelsuche-validation/src/main/java/de/regelsuche/validation/DeterministicCounterexampleSearchService.java :: private Evaluation evaluate(Expr expression, Map<String,RuntimeValue> variables)` |

## Exception format

An exception must name an exact source/signature pair, finite cognitive and cyclomatic ceilings, a rationale and an ISO expiry date. Expired, duplicate or ceiling-exceeding exceptions fail closed.
