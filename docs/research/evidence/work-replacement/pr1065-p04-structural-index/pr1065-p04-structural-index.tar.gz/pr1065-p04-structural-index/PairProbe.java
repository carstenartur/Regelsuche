package de.regelsuche.search.moves;
import de.regelsuche.ast.*;
import de.regelsuche.scalar.ExactRational;
import de.regelsuche.retention.*;
import java.math.BigInteger;
import java.util.*;
public class PairProbe {
 static class Stop extends RuntimeException {}
 static class Sink implements RetainedOperation.Sink {
  RetainedOperation op; long peak; int checks;
  public void retainedReferences(RetainedGraph.Visitor v){v.reference(op);}
  public void executionWork(long n){}
  public void validationWork(long n){}
  public void checkpoint(){checks++;var u=RetainedGraph.measure(this).retained();peak=Math.max(peak,u.characters()); if(peak>SearchExpressionStore.Limits.DEFAULT.characters() || u.references()>SearchExpressionStore.Limits.DEFAULT.references())throw new Stop();}
 }
 public static void main(String[] args){
  int k=10;
  var leaves=new ArrayList<Expr>();for(int i=0;i<(1<<k);i++){Expr leaf=new VariableExpr("x");for(int j=0;j<k;j++)leaf=new BinaryExpr(leaf,BinaryOperator.ADD,leaf);leaves.add(leaf);}
  while(leaves.size()>1){var next=new ArrayList<Expr>();for(int i=0;i<leaves.size();i+=2)next.add(new BinaryExpr(leaves.get(i),BinaryOperator.ADD,leaves.get(i+1)));leaves=next;}
  Expr left=leaves.getFirst();leaves.clear();
  for(int i=0;i<(1<<k);i++)leaves.add(new VariableExpr("x"));
  while(leaves.size()>1){var next=new ArrayList<Expr>();for(int i=0;i<leaves.size();i+=2)next.add(new BinaryExpr(leaves.get(i),BinaryOperator.ADD,leaves.get(i+1)));leaves=next;}
  Expr right=leaves.getFirst();leaves=null;for(int j=0;j<k;j++)right=new BinaryExpr(right,BinaryOperator.ADD,right);
  System.out.println("input="+RetainedGraph.measure(List.of(left,right)).retained());
  var sink=new Sink();var store=new SearchExpressionStore(SearchExpressionStore.Limits.DEFAULT);
  try(var op=RetainedOperation.open(sink)){sink.op=op;try{SearchExpressionIdentity.same(store,left,right);System.out.println("success");}catch(Stop stop){System.out.println("retention-stop");}catch(OutOfMemoryError failure){System.out.println("OOM");failure.printStackTrace();}}
  System.out.println("checkpoints="+sink.checks+" observedPeakChars="+sink.peak+" work="+store.work());
 }
}