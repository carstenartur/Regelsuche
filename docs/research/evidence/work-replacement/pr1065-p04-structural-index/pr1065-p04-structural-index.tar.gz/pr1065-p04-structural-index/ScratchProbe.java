package de.regelsuche.search.moves;
import de.regelsuche.ast.*;
import de.regelsuche.scalar.ExactRational;
import de.regelsuche.retention.*;
import java.math.BigInteger;
import java.util.*;
public class ScratchProbe {
 static class Stop extends RuntimeException {}
 static class Sink implements RetainedOperation.Sink {
  RetainedOperation op; long peak; int checks;
  public void retainedReferences(RetainedGraph.Visitor v){v.reference(op);}
  public void executionWork(long n){}
  public void validationWork(long n){}
  public void checkpoint(){checks++;var u=RetainedGraph.measure(this).retained();peak=Math.max(peak,u.characters()); if(peak>SearchExpressionStore.Limits.DEFAULT.characters())throw new Stop();}
 }
 public static void main(String[] args){
  var value=new ExactRational(BigInteger.ONE.shiftLeft(65536).add(BigInteger.ONE),BigInteger.ONE);
  var children=new ArrayList<Expr>();for(int i=0;i<20000;i++)children.add(new NumberExpr(value));
  var e=new FunctionExpr("f",children);children=null;
  System.out.println("input="+RetainedGraph.measure(e).retained());
  var sink=new Sink();var store=new SearchExpressionStore(SearchExpressionStore.Limits.DEFAULT);
  try(var op=RetainedOperation.open(sink)){sink.op=op;try{SearchExpressionIdentity.hash(store,e);System.out.println("success");}catch(Stop stop){System.out.println("retention-stop");}catch(OutOfMemoryError failure){System.out.println("OOM");}}
  System.out.println("checkpoints="+sink.checks+" observedPeakChars="+sink.peak+" work="+store.work());
 }
}