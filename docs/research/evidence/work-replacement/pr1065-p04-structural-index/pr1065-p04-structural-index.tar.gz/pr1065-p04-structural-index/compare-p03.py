"""Compile the unchanged public P03 probe against a clean committed candidate."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent / 'Regelsuche'
BASE = HERE / 'compatibility/p03-reference'
PROBE = HERE / 'compatibility/current/generator/LegacyExprCorpus.java'
OUT = HERE / 'p04-review-compatibility'
JDK = Path('/tmp/regelsuche-runtime/jdk-25.0.2+10')
MODULES = ['regelsuche-core', 'regelsuche-egraph', 'regelsuche-search', 'regelsuche-validation',
           'regelsuche-math-algorithms', 'regelsuche-solver-ir', 'regelsuche-learning']

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()

def result_hashes(path):
    return {str(p.relative_to(path)): sha(p) for p in path.rglob('*') if p.is_file()}

def source_hashes():
    return {str(p.relative_to(ROOT)): sha(p) for m in MODULES for kind in ['java', 'resources']
            for p in (ROOT / m / 'src/main' / kind).rglob('*') if p.is_file()}

def run(command, label):
    with (OUT / 'commands.jsonl').open('a') as stream:
        stream.write(json.dumps([str(x) for x in command]) + '\n')
    with (OUT / (label + '.log')).open('w') as stream:
        subprocess.run([str(x) for x in command], cwd=ROOT, stdout=stream, stderr=subprocess.STDOUT,
                       timeout=240, check=True)

def main():
    OUT.mkdir()
    head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
    assert not git('status', '--porcelain', '--', *[m + '/src/main' for m in MODULES])
    before = source_hashes()
    assert sha(PROBE) == '6b291db8cca63f4a79c8a766a0aec2af51249081797d58991b5d0fe8246ef377'
    pinned = json.loads((BASE / 'verification.json').read_text())['resultFilesSha256']
    assert len(pinned) == 15 and result_hashes(BASE / 'results') == pinned
    binding = json.loads((BASE / 'source-binding.json').read_text())
    jars = []
    for name, digest in {Path(p).name: h for p, h in binding['dependenciesSha256'].items()}.items():
        candidates = [p for cache in [HERE.parent / 'gradle-home', Path('/root/.m2/repository')]
                      for p in cache.rglob(name) if sha(p) == digest]
        if not candidates:
            raise RuntimeError('Missing pinned dependency: ' + name)
        jars.append(candidates[0])
    classes, temp = OUT / 'classes', OUT / 'tmp'
    classes.mkdir(); temp.mkdir()
    resources = [ROOT / m / 'src/main/resources' for m in MODULES if (ROOT / m / 'src/main/resources').is_dir()]
    services = set()
    for resource in resources:
        for descriptor in (resource / 'META-INF/services').glob('*'):
            for line in descriptor.read_text().splitlines():
                name = line.split('#', 1)[0].strip()
                if name:
                    services.update(p for m in MODULES
                                    if (p := ROOT / m / 'src/main/java' / (name.replace('.', '/') + '.java')).is_file())
    run([JDK / 'bin/javac', '-encoding', 'UTF-8', '-proc:none',
         '-sourcepath', os.pathsep.join(str(ROOT / m / 'src/main/java') for m in MODULES),
         '-classpath', os.pathsep.join(map(str, jars)), '-d', classes, PROBE, *sorted(services)], 'compile')
    runtime = os.pathsep.join(map(str, [classes, *resources, *jars]))
    observed = []
    for number in [1, 2]:
        destination = OUT / f'run-{number}'; destination.mkdir()
        run([JDK / 'bin/java', '-Xmx768m', '-Dfile.encoding=UTF-8', '-Duser.language=en', '-Duser.country=US',
             '-Djava.io.tmpdir=' + str(temp), '-cp', runtime, 'de.regelsuche.preparation.LegacyExprCorpus', destination], f'run-{number}')
        observed.append(result_hashes(destination))
    assert head == git('rev-parse', 'HEAD') and before == source_hashes()
    assert result_hashes(BASE / 'results') == pinned
    report = dict(sourceHead=head, sourceTree=tree, probeSha256=sha(PROBE), baselineSha256=pinned,
                  dependencySha256={p.name: sha(p) for p in jars}, runSha256=observed,
                  twoFreshJvmsIdentical=observed[0] == observed[1],
                  all15P03FilesByteIdentical=observed[0] == observed[1] == pinned,
                  scope='Historical legacy facade only; native total accounting remains partial.')
    (OUT / 'report.json').write_text(json.dumps(report, indent=2, sort_keys=True) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k not in ['baselineSha256', 'dependencySha256', 'runSha256']}))
    assert report['all15P03FilesByteIdentical'], 'P03 comparison changed; inspect complete output files'

if __name__ == '__main__':
    main()
