#include <errno.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#define RANK 1
#define MAX_INDEX 512
#define MAX_POINTS 16384
#define ALPHA_FUNCTION prefix_max

#if RANK == 1
void ALPHA_FUNCTION(long, long*, long*);
#else
void ALPHA_FUNCTION(long, long*, long**);
#endif

static long read_nonnegative(const char *text, long maximum) {
    char *end;
    errno = 0;
    long value = strtol(text, &end, 10);
    if (errno || end == text || *end || value < 0 || value > maximum) return -1;
    return value;
}

int main(int argc, char **argv) {
    if (argc < 4 + RANK || (argc - 4) % RANK || (argc - 4) / RANK > MAX_POINTS) return 2;
    if (sizeof(long) != 8) return 3;
    long parameter = read_nonnegative(argv[1], MAX_INDEX);
    long seed = read_nonnegative(argv[2], 2);
    long input_size = read_nonnegative(argv[3], MAX_INDEX + 1);
    if (parameter < 0 || seed < 0 || input_size < 1) return 4;

    long extents[] = {1, 1};
    for (int i = 4; i < argc; i++) {
        long coordinate = read_nonnegative(argv[i], MAX_INDEX);
        if (coordinate < 0) return 5;
        int axis = (i - 4) % RANK;
        if (coordinate >= extents[axis]) extents[axis] = coordinate + 1;
    }
    long cells = extents[0] * extents[1];
    long *values = malloc((size_t)cells * sizeof(*values));
    long *input = malloc((size_t)input_size * sizeof(*input));
    if (!values || !input) {
        free(values);
        free(input);
        return 6;
    }
    for (long i = 0; i < input_size; i++) input[i] = (i * 17 + seed * 7) % 19 - 9;
    for (long i = 0; i < cells; i++) values[i] = LONG_MIN;
    #if RANK == 1
    ALPHA_FUNCTION(parameter, input, values);
    #else
    long *rows[MAX_INDEX + 1];
    for (long i = 0; i < extents[0]; i++) rows[i] = values + i * extents[1];
    ALPHA_FUNCTION(parameter, input, rows);
    #endif
    for (int i = 4; i < argc; i += RANK) {
        long index = read_nonnegative(argv[i], MAX_INDEX);
        #if RANK == 2
        index = index * extents[1] + read_nonnegative(argv[i + 1], MAX_INDEX);
        #endif
        printf("%ld\n", values[index]);
    }
    free(values);
    free(input);
    return 0;
}
