import de.regelsuche.benchmark.polynomial.*;
import de.regelsuche.benchmark.polynomial.PolynomialTheoryUtilityMeasuredExecution.MeasuredRun;
import de.regelsuche.benchmark.polynomial.PolynomialTheoryUtilityProfileAdapter.RunDescriptor;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.stream.Collectors;

/** Development diagnosis; executes only public, unchanged frozen formation inputs. */
public class PublicProfileDiagnosis {
    private static void row(StringBuilder out, Object... values) {
        out.append(Arrays.stream(values).map(Object::toString).collect(Collectors.joining("\t"))).append('\n');
    }
    public static void main(String[] args) throws Exception {
        var frozen = PolynomialTheoryUtilityExecutionInputs.freeze();
        var cases = PolynomialTheoryUtilityCaseCorpus.load().cases();
        var output = new StringBuilder();
        row(output, "checkpoint", "profile", "case_id", "availability", "primitive_limit", "mechanical_limit", "factorization_limit", "terminal", "transitions", "requests", "candidates", "mechanical_work", "factorization_work", "matching_work", "source_work", "verification_work", "rendering_work", "cache_lookup_work", "cache_insert_work", "evidence_work", "cache_misses", "detail_codes", "occurrence_statuses", "attempt_outcomes", "raw_stages", "input_id", "result_id", "measurement_id");
        for (var cp : PolynomialTheoryUtilityExecutionPlan.CHECKPOINTS) {
            for (var profile : PolynomialTheoryUtilityProfileRegistry.entries()) {
                var planned = frozen.inputs().stream().filter(x -> cp.checkpointId().equals(x.checkpointId()) && profile.profile().profileId().equals(x.profileId())).toList();
                var first = planned.getFirst();
                if (profile.adapter().isEmpty()) {
                    for (var input : planned) row(output, cp.checkpointId(), input.profileId(), input.caseId(), profile.blocker(), input.admittedPrimitiveWork(), input.totalMechanicalWork(), input.factorizationWork(), "NOT_EXECUTED", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", "-", input.inputId(), "-", "-");
                    continue;
                }
                try (var run = profile.adapter().orElseThrow().openRun(new RunDescriptor(first.runId(), first.profileId(), first.checkpointId(), first.adapterId(), cases.size()))) {
                    var measured = (MeasuredRun) run;
                    var cacheHistory = new PolynomialTheoryUtilityCacheRunHistory(first.runId());
                    for (int i = 0; i < cases.size(); i++) {
                        var input = planned.get(i);
                        var observed = measured.executeObserved(input, cases.get(i));
                        var result = observed.result();
                        result.validateAgainst(input, cases.get(i));
                        if (first.profileId().equals(PolynomialTheoryUtilityDerivedCacheAdapter.PROFILE_ID)) cacheHistory.accept(observed);
                        var m = observed.measurements();
                        var w = result.work();
                        var observations = result.observations();
                        var details = observations == null ? "DISABLED" : observations.occurrences().stream().map(x -> x.path() + ":" + x.detailCode()).collect(Collectors.joining("|"));
                        var statuses = observations == null ? "DISABLED" : observations.occurrences().stream().map(x -> x.path() + ":" + x.terminalStatus()).collect(Collectors.joining("|"));
                        var attempts = m.factorizationAttempts().stream().map(x -> x.verifierOutcome() + ":" + x.candidateCount()).collect(Collectors.joining("|"));
                        var raw = observations == null ? "NONE" : observations.rawWork().totalMechanicalWork().stages().toString();
                        row(output, cp.checkpointId(), input.profileId(), input.caseId(), "OBSERVED", input.admittedPrimitiveWork(), input.totalMechanicalWork(), input.factorizationWork(), result.terminalStatus(), m.generatedTransitionCount(), m.factorizationRequestCount(), m.factorizationCandidateCount(), w.mechanicalWork(), w.factorizationWork(), w.matchingWork(), w.sourceValidationWork(), w.verificationWork(), w.renderingWork(), w.cacheLookupWork(), w.cacheInsertionWork(), w.evidenceConstructionWork(), m.cacheMissCount(), details, statuses, attempts, raw, input.inputId(), result.resultId(), m.measurementId());
                    }
                }
            }
        }
        Files.writeString(Path.of(args[0]), output.toString());
    }
}
