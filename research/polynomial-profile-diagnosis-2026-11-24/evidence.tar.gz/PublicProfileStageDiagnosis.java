import de.regelsuche.benchmark.polynomial.*;
import de.regelsuche.math.algorithms.polynomial.*;
import de.regelsuche.moves.enumerate.TreePosition;
import de.regelsuche.parse.*;
import de.regelsuche.polynomial.*;
import java.nio.file.*;
import java.util.*;
import java.util.stream.Collectors;

/** A transparent wrapper records refused charges; raw ledgers must match the real adapter. */
public class PublicProfileStageDiagnosis {
    static class Recording implements PolynomialWorkAuthority {
        final PolynomialTheoryUtilityWorkAuthority delegate;
        final List<String> denials = new ArrayList<>();
        Recording(PolynomialTheoryUtilityExecutionInput input) { delegate = new PolynomialTheoryUtilityWorkAuthority(input); }
        @Override public long remainingOpaqueWorkUnits() { return delegate.remainingOpaqueWorkUnits(); }
        @Override public PolynomialWorkLedger opaqueInvocationOverhead() { return delegate.opaqueInvocationOverhead(); }
        @Override public void consume(PolynomialWorkLedger charge) {
            try { delegate.consume(charge); }
            catch (PolynomialWorkAuthority.LimitReached limit) {
                var proposed = new LinkedHashMap<>(delegate.ledger().stages());
                charge.stages().forEach((stage, units) -> proposed.merge(stage, units, Math::addExact));
                var work = PolynomialTheoryUtilityCanonicalWorkProjection.measure(PolynomialTheoryUtilityCanonicalWorkProjection.partition(0, new PolynomialWorkLedger(proposed)));
                denials.add(charge.stages() + "=>mechanical:" + work.mechanicalWork() + ",factorization:" + work.factorizationWork());
                throw limit;
            }
        }
    }
    static void row(StringBuilder out, Object... values) {
        out.append(Arrays.stream(values).map(Object::toString).collect(Collectors.joining("\t"))).append('\n');
    }
    public static void main(String[] args) throws Exception {
        var output = new StringBuilder();
        row(output, "checkpoint", "case_id", "path", "mechanical_limit", "factorization_limit", "pipeline_status", "pipeline_detail", "extraction_status", "extraction_detail", "request_work_limit", "report_status", "report_detail", "verified_candidates", "refused_charges", "raw_prefix_matches_adapter");
        var cases = PolynomialTheoryUtilityCaseCorpus.load().cases();
        for (var input : PolynomialTheoryUtilityExecutionInputs.freeze().inputs()) {
            if (!input.profileId().equals("ON_DEMAND_VERIFIED_FACTORIZATION")) continue;
            var formation = cases.stream().filter(x -> x.caseId().equals(input.caseId())).findFirst().orElseThrow();
            var actual = PolynomialTheoryUtilityOnDemandVerifiedFactorizationAdapter.executeObservedCase(input, formation);
            var recording = new Recording(input);
            ExactParsedTerm parsed = null;
            try {
                recording.consume("projection.study-source-parse-code-units", formation.sourceExpression().length());
                parsed = new ExpressionParser().parseExactTerm(formation.sourceExpression());
            } catch (PolynomialWorkAuthority.LimitReached exhausted) { }
            var rows = new StringBuilder();
            int index = 0;
            for (var path : PolynomialTheoryUtilityExecutionObservations.paths(formation)) {
                recording.denials.clear();
                ExactNestedFactorizationTransformationPipeline.Result result = null;
                try {
                    if (parsed == null || recording.delegate.remainingPrimitiveWork() < 7) {
                        recording.denials.add("PRIMITIVE_EXPANSION_REQUIRES_7_OR_SOURCE_NOT_PARSED");
                        throw new PolynomialWorkAuthority.LimitReached();
                    }
                    recording.consume("study.evidence.occurrence-records", 1);
                    recording.consume("projection.study-path-navigation", path.size() + 1L);
                    var selected = new TreePosition(path, "pending").subtreeAt(parsed.expression()).orElseThrow();
                    var position = new TreePosition(path, ExpressionFormatter.formatMeasured(selected, units -> recording.consume("projection.study-position-format-code-units", units)));
                    result = new ExactNestedFactorizationTransformationPipeline(recording).transform(parsed, position, NativeUnivariateFactorizationEngine.rationals(NativeUnivariateFactorizationPolicy.boundedDefaults()), 0);
                    if (result.transformed()) throw new AssertionError("Diagnostic must handle successful transition continuation before use");
                } catch (PolynomialWorkAuthority.LimitReached exhausted) { }
                var fact = result == null ? null : result.factorization().orElse(null);
                var report = fact == null ? null : fact.report().orElse(null);
                var reference = actual.occurrences().get(index++).pipeline();
                if ((reference == null) != (result == null) || (result != null && !reference.certificateHash().equals(result.certificateHash()))) throw new AssertionError("Diagnostic pipeline differs from real adapter");
                row(rows, input.checkpointId(), input.caseId(), path, input.totalMechanicalWork(), input.factorizationWork(), result == null ? "NOT_INVOKED" : result.status(), result == null ? "NONE" : result.detailCode(), fact == null ? "NONE" : fact.extraction().status(), fact == null ? "NONE" : fact.extraction().detailCode(), fact == null || fact.request().isEmpty() ? "NONE" : fact.request().orElseThrow().maxWorkUnits(), report == null ? "NONE" : report.status(), report == null ? "NONE" : report.detailCode(), report == null ? 0 : report.candidates().size(), String.join("|",recording.denials), true);
            }
            if (!recording.delegate.ledger().equals(actual.rawWork())) throw new AssertionError("Diagnostic raw ledger differs from real adapter for " + input.inputId());
            output.append(rows);
        }
        Files.writeString(Path.of(args[0]), output.toString());
    }
}
