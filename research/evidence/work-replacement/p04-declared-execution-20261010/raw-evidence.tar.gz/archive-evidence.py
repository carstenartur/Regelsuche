from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

root = Path(__file__).parent
repo = root.parent / 'Regelsuche-p04-execution-qualification'
destination = repo / 'docs/research/evidence/work-replacement/p04-declared-execution-20261010'
members = ['baseline', 'reconstruction-red', 'reconstruction-red-2', 'reconstruction-green',
    'full-modules', 'review-red', 'review-green', 'full-modules-corrected', 'math-module',
    'public-p03', 'public-corpus-corrected', 'ai-gate-corrected', 'run-gradle.cjs', 'run-tests.py',
    'run-ai-gate.py', 'extractor-javac25.init.gradle', 'independent-review.md', 'review-package.md',
    'verify-public-and-source.py', 'public-and-source-verification.json', 'archive-evidence.py']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
files = sorted(path for member in members for path in
    ([root / member] if (root / member).is_file() else (root / member).rglob('*')) if path.is_file())
archive = destination / 'raw-evidence.tar.gz'
bundle = destination / 'source-history.bundle'
if archive.exists() or bundle.exists():
    raise SystemExit('Refuse to overwrite evidence')
with tarfile.open(archive, 'w:gz') as output:
    for path in files:
        output.add(path, arcname=str(path.relative_to(root)), recursive=False)
branch = 'codex/p04-execution-recovery-20261010'
if subprocess.check_output(['git', 'rev-parse', branch], cwd=repo, text=True).strip() != 'd65456505bfb018d1baa78842ede56f2f2f249de':
    raise SystemExit('Source branch changed before bundling')
subprocess.run(['git', 'bundle', 'create', str(bundle), branch,
    '^fba017704a95f58cb99d1f66cdeece013cdb901e'], cwd=repo, check=True)
subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=repo, check=True)
with tarfile.open(archive) as output:
    for member in output.getmembers():
        if hashlib.sha256(output.extractfile(member).read()).hexdigest() != sha(root / member.name):
            raise SystemExit('Archive roundtrip differs: ' + member.name)
manifest = {'schema': 'regelsuche.p04-declared-execution-evidence/v1',
    'baseCommit': 'fba017704a95f58cb99d1f66cdeece013cdb901e',
    'localSourceCommit': 'd65456505bfb018d1baa78842ede56f2f2f249de',
    'remoteEquivalentCommit': 'df2b73a4f27badb7a615a2467583dd0f55dbfe0f',
    'sourceTree': 'aeee4597a445d9419ec5e53ce860df1ad4df66cc',
    'archive': {'path': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
    'sourceBundle': {'path': bundle.name, 'sha256': sha(bundle), 'bytes': bundle.stat().st_size},
    'included': [{'path': str(path.relative_to(root)), 'sha256': sha(path), 'bytes': path.stat().st_size} for path in files],
    'moduleTests': {'core': 1151, 'search': 696, 'learning': 1093, 'mathAlgorithms': 320,
        'failures': 0, 'errors': 0, 'skipped': 0},
    'historicalParity': {'independentJvmRuns': 2, 'identicalJsonFilesPerRun': 13,
        'diagnosticSemanticParity': '24/26', 'frozenBudgetParity': '0/26'},
    'hostedCI': 'PENDING', 'p04Complete': False, 'economicClaim': False}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({key: manifest[key] for key in ('archive', 'sourceBundle', 'moduleTests')}, indent=2))
