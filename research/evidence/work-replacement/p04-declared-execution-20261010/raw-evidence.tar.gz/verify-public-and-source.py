from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).parent
repo = root.parent / 'Regelsuche-p04-execution-qualification'
public = root / 'public-corpus-corrected'
historical = root.parent / 'p04-recovered-evidence/p04-native-public-corpus/final-matrix-1'
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
comparisons = []
for index in (1, 2):
    for path in sorted((public / f'run-{index}').glob('*.json')):
        prior = historical / f'run-{index}' / path.name
        comparisons.append({'run': index, 'file': path.name, 'currentSha256': sha(path),
            'priorSha256': sha(prior), 'identical': path.read_bytes() == prior.read_bytes()})
binding = json.loads((root / 'full-modules-corrected/source-binding.json').read_text())
current = {str(path.relative_to(repo)): sha(path) for path in sorted(repo.glob('*/src/**/*.java'))}
report = {'sourceCommit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip(),
    'allJavaSourcesEqualFullSuite': current == binding['sources'],
    'historicalComparison': comparisons,
    'all26ComparisonsIdentical': len(comparisons) == 26 and all(row['identical'] for row in comparisons),
    'historicalEvidence': 'docs/research/evidence/work-replacement/p04-native-ownership-20261009/raw-evidence.tar.gz',
    'interpretation': 'Default V7 compatibility only. Retains all frozen-budget failures and partial flags; no economic or P04 completion claim.'}
(root / 'public-and-source-verification.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k != 'historicalComparison'}, indent=2))
if not report['all26ComparisonsIdentical'] or not report['allJavaSourcesEqualFullSuite']:
    raise SystemExit(1)
