# Whole-branch P04 execution inventory review

Repository: /workspace/scratch/4e87c3dfd845/Regelsuche-p04-execution-qualification
Base: fba017704a95f58cb99d1f66cdeece013cdb901e
Head: use branch codex/p04-execution-recovery-20261010 at 03dcb57ee6 (resolve full SHA).
This is a reconstructed, not byte-identically recovered, previously unpublished
feature. Do not reuse any earlier approval. No substantive review of the lost
version was completed. Read the complete diff and relevant existing machinery.

Plan and ledger: docs/superpowers/plans/2026-10-10-native-execution-recovery.md
Contract: docs/research/native-expr-qualification.md
Progress: docs/research/work-replacement-progress.md

Scope: opt-in V8 logical execution inventory and V4 separate export, without
changing default V7/V3, mathematical verification, shared search algorithm,
production refusal or the learner. Actual owned exact pattern/program providers
and installed checked-schema providers may qualify only with known callbacks.
No physical-memory, wall-time, lifecycle speedup or complete P04 claim is made.

Review focus (verbatim from plan):

Recognition must include nested rule callbacks and verifier/provider identity,
not merely outer final classes. Unknown enums and graph views must not gain cost
authority. No work performed by admission or final checking may disappear when
limits fail. Export qualification cannot retroactively qualify the search, and
search completeness cannot manufacture the kernel's bounded relation.

Evidence: /workspace/scratch/4e87c3dfd845/p04-recovery/baseline (2909 passing),
reconstruction-red-2 (only absent-API compilation RED), reconstruction-green
(28 passing incl fresh JVM). Full-modules is in progress. Do not run Gradle or
alter source/HEAD: coordinator owns the serialized build slot. Read-only
inspection and scoped diagnostic reasoning are allowed. Report file/line,
mechanism, user impact and suggested regression for each finding, with severity
by practical impact. Explicitly list anything you decline to judge, any missing
proof supporting COMPLETE_DECLARED_EXECUTION, and deferred minor issues.

The skill's code-reviewer.md resource could not be read; this package supplies
the same explicit description/requirements/base/head/evidence fields. Return a
review, not code changes or a merge authorization.
