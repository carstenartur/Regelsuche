const {spawnSync} = require('node:child_process');
const options = ['-XX:ActiveProcessorCount=2', '-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts'];
for (const protocol of ['http', 'https']) {
  const configured = process.env[protocol.toUpperCase() + '_PROXY'];
  if (configured) {
    const proxy = new URL(configured);
    if (proxy.username || proxy.password) throw new Error('Authenticated proxy needs the configured credential handler');
    options.push(`-D${protocol}.proxyHost=${proxy.hostname}`, `-D${protocol}.proxyPort=${proxy.port || 80}`);
  }
}
const env = {...process.env,
  JAVA_HOME: '/tmp/regelsuche-runtime/jdk-25.0.2+10',
  GRADLE_USER_HOME: '/workspace/scratch/4e87c3dfd845/gradle-home',
  JAVA_TOOL_OPTIONS: [process.env.JAVA_TOOL_OPTIONS || '', ...options].join(' ')};
const result = spawnSync('/tmp/regelsuche-runtime/gradle-9.7.1/bin/gradle',
  [...options.filter(x => x.startsWith('-D')), ...process.argv.slice(2)], {env, stdio:'inherit'});
if (result.error) throw result.error;
process.exit(result.status ?? 1);
