from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

root, commit, output = Path(sys.argv[1]).resolve(), sys.argv[2], Path(sys.argv[3]).resolve()
output.mkdir(exist_ok=False)
parent = Path(tempfile.mkdtemp(prefix='regelsuche-p04-ai-', dir='/tmp'))
checkout = parent / 'checkout'
subprocess.run(['git', 'worktree', 'add', '--detach', str(checkout), commit], cwd=root, check=True)
runner = Path(__file__).with_name('run-gradle.cjs')
initializer = Path(__file__).with_name('extractor-javac25.init.gradle')
extractor = root.parent / 'ai-knowledge-extractor'
command = ['node', str(runner), '--no-daemon', '--no-configuration-cache', '--max-workers=1',
    '--console=plain', '--stacktrace', '--no-build-cache', '--rerun-tasks', '-I', str(initializer),
    '-PenableAiKnowledgeExtractor=true', '-PuseLocalAiKnowledgeExtractor=true',
    '-PaiKnowledgeExtractorCheckout=' + str(extractor), 'aiKnowledgeCheck']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()
binding = {'source': git(checkout, 'rev-parse', 'HEAD'), 'tree': git(checkout, 'rev-parse', 'HEAD^{tree}'),
    'checkout': str(checkout), 'command': command, 'runnerSha256': sha(runner),
    'initSha256': sha(initializer), 'scriptSha256': sha(Path(__file__)),
    'baselineSha256': sha(checkout / 'ai-knowledge/complexity-baseline.json'),
    'extractorHead': git(extractor, 'rev-parse', 'HEAD'), 'extractorStatus': git(extractor, 'status', '--porcelain')}
(output / 'source-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
environment = dict(os.environ, AI_KNOWLEDGE_EXTRACTOR_ENABLED='true')
started = time.time()
with (output / 'gradle.log').open('w') as log:
    result = subprocess.run(command, cwd=checkout, env=environment, stdout=log, stderr=subprocess.STDOUT)
reports = {}
for directory in ['build/ai-knowledge', 'build/reports/quality']:
    for path in (checkout / directory).glob('*'):
        if path.is_file() and path.suffix in ['.json', '.md']:
            destination = output / 'reports' / directory
            destination.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, destination / path.name)
            reports[str(path.relative_to(checkout))] = {'sha256': sha(path), 'fresh': path.stat().st_mtime >= started}
summary = {'exitCode': result.returncode, 'sourceStatus': git(checkout, 'status', '--porcelain'),
    'extractorStatus': git(extractor, 'status', '--porcelain'), 'reports': reports}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'exitCode': result.returncode, 'sourceStatus': summary['sourceStatus'],
    'reports': len(reports), 'allReportsFresh': bool(reports) and all(r['fresh'] for r in reports.values())}))
sys.exit(result.returncode)
