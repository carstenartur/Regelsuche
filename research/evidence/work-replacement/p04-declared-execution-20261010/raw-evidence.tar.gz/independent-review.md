# Independent whole-branch review — 2026-10-10

Reviewer: fresh-context read-only agent `p04_recovered_execution_review`.
Reviewed range: `fba017704a95f58cb99d1f66cdeece013cdb901e..03dcb57ee6e995274836472c0a3a69549f1dc4a9`.
No edits, builds, commits, HEAD changes or additional agents were used by the reviewer.

## Important / P2: lost primitive regeneration work on comparison failure

The new inventory admits Primitive verification. After transport.generate returns,
generated.contains(proof.step()) can abort during observed expression equality.
The verifier had no paidVerification failure transfer, so admission and final replay
omitted the completed flatEngine(N) plus candidateWork(N) receipt (2 + 2*N units).
Observed helper work survives. This is an accounting undercount, not a proof bypass.
Existing program-provider failure tests did not cover this primitive boundary.

Root evaluation: accepted as Important because qualified failure prefixes must not
lose paid work. Three new real tests reproduce expected4/actual0 (direct handoff,
admission, final replay). The minimal fix transfers the completed receipt through
the existing ResourceLimit ledger; repeated takeWork is zero. All16 focused tests
and fresh Core1151/Search696/Learning1093 pass after correction.

## Minor: ambiguous legacy documentation

The table directly below V8/V4 said completion was always false without an explicit
legacy heading. Fixed by labelling the V7/V3 partial-accounting contract. No deferred
review finding remains.

## Boundaries

The reviewer found no additional concrete default V7/V3 charge or successful-result
regression. The inventory conservatively checks exact rule classes/profiles, owned
program stages, provider identity and private checked-schema application ownership.
Unknown callbacks remain partial; export cannot manufacture a bounded relation.

The review did not qualify pending suites, corpus, quality, hosted CI, physical memory,
performance, arbitrary supplied rule truth or completion of P04. Correction evidence
is subsequent root verification, not a second independent review or merge approval.
