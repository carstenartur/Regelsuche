from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

repo = Path(sys.argv[1]).resolve()
output = Path(sys.argv[2]).resolve()
output.mkdir(parents=True, exist_ok=False)
scratch = Path(tempfile.mkdtemp(prefix='regelsuche-p04-tests-', dir='/tmp'))
init = scratch / 'isolated.gradle'
init.write_text('gradle.beforeProject { p ->\n'
    '  p.layout.buildDirectory.set(new File(' + json.dumps(str(scratch / 'build')) +
    ", p.path == ':' ? '_root' : p.path.substring(1).replace(':', '_')))\n"
    '  p.tasks.withType(org.gradle.api.tasks.compile.JavaCompile).configureEach { options.incremental = false }\n'
    '}\n')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=repo, text=True).strip()
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def sources():
    return {str(p.relative_to(repo)): sha(p) for p in sorted(repo.glob('*/src/**/*.java'))}
command = ['node', str(Path(__file__).with_name('run-gradle.cjs')), '--no-daemon',
    '--no-configuration-cache', '--max-workers=1', '--console=plain', '--no-build-cache',
    '--rerun-tasks', '--continue', '--project-cache-dir', str(scratch / 'project-cache'),
    '-I', str(init), *sys.argv[3:]]
head, before = git('rev-parse', 'HEAD'), sources()
binding = {'head': head, 'tree': git('rev-parse', 'HEAD^{tree}'),
    'status': git('status', '--porcelain'), 'sources': before,
    'command': command, 'runnerSha256': sha(Path(__file__)),
    'gradleRunnerSha256': sha(Path(__file__).with_name('run-gradle.cjs')),
    'initSha256': sha(init), 'buildRoot': str(scratch / 'build')}
(output / 'source-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
shutil.copy2(init, output / 'isolated.gradle')
started = time.time()
with (output / 'gradle.log').open('w') as log:
    result = subprocess.run(command, cwd=repo, stdout=log, stderr=subprocess.STDOUT)
reports = {}
for testdir in sorted((scratch / 'build').glob('*/test-results/test')):
    module = testdir.parent.parent.name
    destination = output / module
    destination.mkdir()
    totals = {k: 0 for k in ('tests', 'failures', 'errors', 'skipped')}
    paths = sorted(testdir.glob('TEST-*.xml'))
    for path in paths:
        suite = ET.parse(path).getroot()
        for key in totals:
            totals[key] += int(suite.attrib[key])
        shutil.copy2(path, destination / path.name)
    totals['allReportsFresh'] = bool(paths) and all(p.stat().st_mtime >= started for p in paths)
    reports[module] = totals
summary = {'exitCode': result.returncode, 'modules': reports,
    'headUnchanged': git('rev-parse', 'HEAD') == head, 'sourcesUnchanged': sources() == before}
(output / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
sys.exit(result.returncode or (0 if summary['headUnchanged'] and summary['sourcesUnchanged'] else 1))
