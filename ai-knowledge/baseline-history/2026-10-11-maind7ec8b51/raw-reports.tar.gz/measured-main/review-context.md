# AI Knowledge Review Context

## Repository Overview

- **Repository**: regelsuche-pr1088-predecessor
- **Generation Mode**: deterministic-static
- **Schema Version**: 1
- **Modules**: 67 | **Classes**: 1697 | **Tests**: 1191 | **Documents**: 427
- **Capabilities**: 17 | **Claims**: 8 | **Evidence**: 9

## Module Graph

| Module | Build System | Main Packages | Project Dependencies |
|--------|-------------|---------------|---------------------|
| ai-knowledge-verification | gradle | _none_ | _none_ |
| app | gradle | de.regelsuche.benchmark, de.regelsuche, de.regelsuche.analyze, de.regelsuche.api, de.regelsuche.api.searchgraph, de.regelsuche.api.searchgraph.semantic, de.regelsuche.app.persistence.neo4j, de.regelsuche.app.transform, de.regelsuche.cli, de.regelsuche.demo, de.regelsuche.didactic, de.regelsuche.didactic.analytics, de.regelsuche.didactic.export, de.regelsuche.discovery, de.regelsuche.docs, de.regelsuche.equation, de.regelsuche.evolution, de.regelsuche.explain, de.regelsuche.explanation, de.regelsuche.export, de.regelsuche.export.layout, de.regelsuche.graph, de.regelsuche.ide, de.regelsuche.inequality, de.regelsuche.inventory, de.regelsuche.jobs, de.regelsuche.learning, de.regelsuche.math, de.regelsuche.mining, de.regelsuche.moves, de.regelsuche.moves.apply, de.regelsuche.moves.enumerate, de.regelsuche.moves.hypothesis, de.regelsuche.moves.macro, de.regelsuche.moves.report, de.regelsuche.moves.search, de.regelsuche.paths, de.regelsuche.persistence, de.regelsuche.plugin, de.regelsuche.plugin.example, de.regelsuche.polynomial, de.regelsuche.proof, de.regelsuche.provenance, de.regelsuche.radar, de.regelsuche.runtime, de.regelsuche.search, de.regelsuche.search.memory, de.regelsuche.sympyqa, de.regelsuche.system, de.regelsuche.web | implementation project(':regelsuche-discovery-sdk'), implementation project(':regelsuche-plugin-api'), implementation project(':regelsuche-core'), implementation project(':regelsuche-egraph'), implementation project(':regelsuche-search'), implementation project(':regelsuche-validation'), implementation project(':regelsuche-math-algorithms'), implementation project(':regelsuche-persistence'), implementation project(':regelsuche-persistence-hibernate'), implementation project(':regelsuche-learning'), implementation project(':regelsuche-experiments'), implementation project(':regelsuche-cli'), implementation project(':regelsuche-discovery'), implementation project(':regelsuche-solver-portfolio') |
| app | maven | de.regelsuche.benchmark, de.regelsuche, de.regelsuche.analyze, de.regelsuche.api, de.regelsuche.api.searchgraph, de.regelsuche.api.searchgraph.semantic, de.regelsuche.app.persistence.neo4j, de.regelsuche.app.transform, de.regelsuche.cli, de.regelsuche.demo, de.regelsuche.didactic, de.regelsuche.didactic.analytics, de.regelsuche.didactic.export, de.regelsuche.discovery, de.regelsuche.docs, de.regelsuche.equation, de.regelsuche.evolution, de.regelsuche.explain, de.regelsuche.explanation, de.regelsuche.export, de.regelsuche.export.layout, de.regelsuche.graph, de.regelsuche.ide, de.regelsuche.inequality, de.regelsuche.inventory, de.regelsuche.jobs, de.regelsuche.learning, de.regelsuche.math, de.regelsuche.mining, de.regelsuche.moves, de.regelsuche.moves.apply, de.regelsuche.moves.enumerate, de.regelsuche.moves.hypothesis, de.regelsuche.moves.macro, de.regelsuche.moves.report, de.regelsuche.moves.search, de.regelsuche.paths, de.regelsuche.persistence, de.regelsuche.plugin, de.regelsuche.plugin.example, de.regelsuche.polynomial, de.regelsuche.proof, de.regelsuche.provenance, de.regelsuche.radar, de.regelsuche.runtime, de.regelsuche.search, de.regelsuche.search.memory, de.regelsuche.sympyqa, de.regelsuche.system, de.regelsuche.web | _none_ |
| regelsuche-pr1088-predecessor | gradle | de.regelsuche.benchmark, de.regelsuche, de.regelsuche.analyze, de.regelsuche.api, de.regelsuche.api.searchgraph, de.regelsuche.api.searchgraph.semantic, de.regelsuche.app.persistence.neo4j, de.regelsuche.app.transform, de.regelsuche.cli, de.regelsuche.demo, de.regelsuche.didactic, de.regelsuche.didactic.analytics, de.regelsuche.didactic.export, de.regelsuche.discovery, de.regelsuche.docs, de.regelsuche.equation, de.regelsuche.evolution, de.regelsuche.explain, de.regelsuche.explanation, de.regelsuche.export, de.regelsuche.export.layout, de.regelsuche.graph, de.regelsuche.ide, de.regelsuche.inequality, de.regelsuche.inventory, de.regelsuche.jobs, de.regelsuche.learning, de.regelsuche.math, de.regelsuche.mining, de.regelsuche.moves, de.regelsuche.moves.apply, de.regelsuche.moves.enumerate, de.regelsuche.moves.hypothesis, de.regelsuche.moves.macro, de.regelsuche.moves.report, de.regelsuche.moves.search, de.regelsuche.paths, de.regelsuche.persistence, de.regelsuche.plugin, de.regelsuche.plugin.example, de.regelsuche.polynomial, de.regelsuche.proof, de.regelsuche.provenance, de.regelsuche.radar, de.regelsuche.runtime, de.regelsuche.search, de.regelsuche.search.memory, de.regelsuche.sympyqa, de.regelsuche.system, de.regelsuche.web, example, org.primachsenraum.regelsuche, de.regelsuche.experiments.autopilot, de.regelsuche.benchmarks, de.regelsuche.cli.core, de.regelsuche.algebra, de.regelsuche.assumption, de.regelsuche.ast, de.regelsuche.calculus, de.regelsuche.canonical, de.regelsuche.input, de.regelsuche.json, de.regelsuche.knowledge, de.regelsuche.linalg, de.regelsuche.notify, de.regelsuche.parse, de.regelsuche.python.runtime, de.regelsuche.representation, de.regelsuche.retention, de.regelsuche.rules, de.regelsuche.scalar, de.regelsuche.symbol, de.regelsuche.transform, de.regelsuche.util, de.regelsuche.value, de.regelsuche.sdk.discovery, de.regelsuche.sdk.discovery.cli, de.regelsuche.sdk.discovery.python, de.regelsuche.discovery.domain, de.regelsuche.discovery.representation, de.regelsuche.egraph, de.regelsuche.benchmark.polynomial, de.regelsuche.example, de.regelsuche.example.modular, de.regelsuche.extension, de.regelsuche.extension.runtime, de.regelsuche.math.algorithms.cas, de.regelsuche.math.algorithms.completion, de.regelsuche.math.algorithms.equivalence, de.regelsuche.math.algorithms.linalg, de.regelsuche.math.algorithms.modular, de.regelsuche.math.algorithms.numeric, de.regelsuche.math.algorithms.polynomial, de.regelsuche.math.algorithms.registry, de.regelsuche.math.jas, de.regelsuche.math.sympy, de.regelsuche.sdk.optimization, de.regelsuche.persistence.relational, de.regelsuche.checkpoint, de.regelsuche.quality.jmh, de.regelsuche.quality.release, de.regelsuche.quality.supplychain, de.regelsuche.quality.tests, de.regelsuche.release, de.regelsuche.scoring, de.regelsuche.scoring.cost, de.regelsuche.search.convergence, de.regelsuche.search.estimate, de.regelsuche.search.index, de.regelsuche.search.learning, de.regelsuche.search.moves, de.regelsuche.search.policy, de.regelsuche.search.program, de.regelsuche.search.reachability, de.regelsuche.search.strategy, de.regelsuche.search.telemetry, de.regelsuche.solver.ir, de.regelsuche.solver.portfolio, de.regelsuche.equivalence, de.regelsuche.validation, de.regelsuche.qualification, de.regelsuche.research, de.regelsuche.preparation | _none_ |
| extension-runtime-java25 | gradle | example | _none_ |
| finite-difference-domain-java25 | gradle | example | _none_ |
| geometric-sequence-domain-java25 | gradle | example | _none_ |
| hello-rule-java25 | gradle | example | _none_ |
| java-optimization-java25 | gradle | example | _none_ |
| number-theory-plan-java25 | gradle | org.primachsenraum.regelsuche | _none_ |
| solver-adapter-java25 | gradle | example | _none_ |
| maven-build-contract | maven | _none_ | _none_ |
| playwright-bootstrap | gradle | _none_ | _none_ |
| playwright-bootstrap | maven | _none_ | _none_ |
| regelsuche-pr1088-predecessor | maven | de.regelsuche.benchmark, de.regelsuche, de.regelsuche.analyze, de.regelsuche.api, de.regelsuche.api.searchgraph, de.regelsuche.api.searchgraph.semantic, de.regelsuche.app.persistence.neo4j, de.regelsuche.app.transform, de.regelsuche.cli, de.regelsuche.demo, de.regelsuche.didactic, de.regelsuche.didactic.analytics, de.regelsuche.didactic.export, de.regelsuche.discovery, de.regelsuche.docs, de.regelsuche.equation, de.regelsuche.evolution, de.regelsuche.explain, de.regelsuche.explanation, de.regelsuche.export, de.regelsuche.export.layout, de.regelsuche.graph, de.regelsuche.ide, de.regelsuche.inequality, de.regelsuche.inventory, de.regelsuche.jobs, de.regelsuche.learning, de.regelsuche.math, de.regelsuche.mining, de.regelsuche.moves, de.regelsuche.moves.apply, de.regelsuche.moves.enumerate, de.regelsuche.moves.hypothesis, de.regelsuche.moves.macro, de.regelsuche.moves.report, de.regelsuche.moves.search, de.regelsuche.paths, de.regelsuche.persistence, de.regelsuche.plugin, de.regelsuche.plugin.example, de.regelsuche.polynomial, de.regelsuche.proof, de.regelsuche.provenance, de.regelsuche.radar, de.regelsuche.runtime, de.regelsuche.search, de.regelsuche.search.memory, de.regelsuche.sympyqa, de.regelsuche.system, de.regelsuche.web, example, org.primachsenraum.regelsuche, de.regelsuche.experiments.autopilot, de.regelsuche.benchmarks, de.regelsuche.cli.core, de.regelsuche.algebra, de.regelsuche.assumption, de.regelsuche.ast, de.regelsuche.calculus, de.regelsuche.canonical, de.regelsuche.input, de.regelsuche.json, de.regelsuche.knowledge, de.regelsuche.linalg, de.regelsuche.notify, de.regelsuche.parse, de.regelsuche.python.runtime, de.regelsuche.representation, de.regelsuche.retention, de.regelsuche.rules, de.regelsuche.scalar, de.regelsuche.symbol, de.regelsuche.transform, de.regelsuche.util, de.regelsuche.value, de.regelsuche.sdk.discovery, de.regelsuche.sdk.discovery.cli, de.regelsuche.sdk.discovery.python, de.regelsuche.discovery.domain, de.regelsuche.discovery.representation, de.regelsuche.egraph, de.regelsuche.benchmark.polynomial, de.regelsuche.example, de.regelsuche.example.modular, de.regelsuche.extension, de.regelsuche.extension.runtime, de.regelsuche.math.algorithms.cas, de.regelsuche.math.algorithms.completion, de.regelsuche.math.algorithms.equivalence, de.regelsuche.math.algorithms.linalg, de.regelsuche.math.algorithms.modular, de.regelsuche.math.algorithms.numeric, de.regelsuche.math.algorithms.polynomial, de.regelsuche.math.algorithms.registry, de.regelsuche.math.jas, de.regelsuche.math.sympy, de.regelsuche.sdk.optimization, de.regelsuche.persistence.relational, de.regelsuche.checkpoint, de.regelsuche.quality.jmh, de.regelsuche.quality.release, de.regelsuche.quality.supplychain, de.regelsuche.quality.tests, de.regelsuche.release, de.regelsuche.scoring, de.regelsuche.scoring.cost, de.regelsuche.search.convergence, de.regelsuche.search.estimate, de.regelsuche.search.index, de.regelsuche.search.learning, de.regelsuche.search.moves, de.regelsuche.search.policy, de.regelsuche.search.program, de.regelsuche.search.reachability, de.regelsuche.search.strategy, de.regelsuche.search.telemetry, de.regelsuche.solver.ir, de.regelsuche.solver.portfolio, de.regelsuche.equivalence, de.regelsuche.validation, de.regelsuche.qualification, de.regelsuche.research, de.regelsuche.preparation | _none_ |
| regelsuche-autopilot | gradle | de.regelsuche.experiments.autopilot | api project(':regelsuche-experiments'), api project(':regelsuche-learning') |
| regelsuche-autopilot | maven | de.regelsuche.experiments.autopilot | _none_ |
| regelsuche-benchmarks | gradle | de.regelsuche.benchmarks | api project(':regelsuche-solver-ir'), implementation project(':regelsuche-search'), implementation project(':regelsuche-solver-portfolio') |
| regelsuche-benchmarks | maven | de.regelsuche.benchmarks | _none_ |
| regelsuche-bom | gradle | _none_ | _none_ |
| regelsuche-bom | maven | _none_ | _none_ |
| regelsuche-cli | gradle | de.regelsuche.cli.core | _none_ |
| regelsuche-cli | maven | de.regelsuche.cli.core | _none_ |
| regelsuche-core | gradle | de.regelsuche.algebra, de.regelsuche.api, de.regelsuche.assumption, de.regelsuche.ast, de.regelsuche.calculus, de.regelsuche.canonical, de.regelsuche.input, de.regelsuche.json, de.regelsuche.knowledge, de.regelsuche.linalg, de.regelsuche.moves.enumerate, de.regelsuche.notify, de.regelsuche.parse, de.regelsuche.polynomial, de.regelsuche.python.runtime, de.regelsuche.representation, de.regelsuche.retention, de.regelsuche.rules, de.regelsuche.scalar, de.regelsuche.symbol, de.regelsuche.transform, de.regelsuche.util, de.regelsuche.value | _none_ |
| regelsuche-core | maven | de.regelsuche.algebra, de.regelsuche.api, de.regelsuche.assumption, de.regelsuche.ast, de.regelsuche.calculus, de.regelsuche.canonical, de.regelsuche.input, de.regelsuche.json, de.regelsuche.knowledge, de.regelsuche.linalg, de.regelsuche.moves.enumerate, de.regelsuche.notify, de.regelsuche.parse, de.regelsuche.polynomial, de.regelsuche.python.runtime, de.regelsuche.representation, de.regelsuche.retention, de.regelsuche.rules, de.regelsuche.scalar, de.regelsuche.symbol, de.regelsuche.transform, de.regelsuche.util, de.regelsuche.value | _none_ |
| regelsuche-discovery-sdk | gradle | de.regelsuche.sdk.discovery, de.regelsuche.sdk.discovery.cli, de.regelsuche.sdk.discovery.python | api project(':regelsuche-discovery') |
| regelsuche-discovery-sdk | maven | de.regelsuche.sdk.discovery, de.regelsuche.sdk.discovery.cli, de.regelsuche.sdk.discovery.python | _none_ |
| regelsuche-discovery | gradle | de.regelsuche.discovery, de.regelsuche.discovery.domain, de.regelsuche.discovery.representation | api project(':regelsuche-core'), api project(':regelsuche-search'), api project(':regelsuche-validation') |
| regelsuche-discovery | maven | de.regelsuche.discovery, de.regelsuche.discovery.domain, de.regelsuche.discovery.representation | _none_ |
| regelsuche-egraph | gradle | de.regelsuche.egraph | api project(':regelsuche-core') |
| regelsuche-egraph | maven | de.regelsuche.egraph | _none_ |
| regelsuche-experiments | gradle | de.regelsuche.benchmark, de.regelsuche.benchmark.polynomial, de.regelsuche.example, de.regelsuche.example.modular, de.regelsuche.experiments.autopilot | api project(':regelsuche-search'), api project(':regelsuche-validation'), api project(':regelsuche-discovery'), api project(':regelsuche-math-algorithms'), api project(':regelsuche-optimization-sdk') |
| regelsuche-experiments | maven | de.regelsuche.benchmark, de.regelsuche.benchmark.polynomial, de.regelsuche.example, de.regelsuche.example.modular, de.regelsuche.experiments.autopilot | _none_ |
| regelsuche-extension-api | gradle | de.regelsuche.extension | api project(':regelsuche-core') |
| regelsuche-extension-api | maven | de.regelsuche.extension | _none_ |
| regelsuche-extension-runtime | gradle | de.regelsuche.extension.runtime | api project(':regelsuche-extension-api') |
| regelsuche-extension-runtime | maven | de.regelsuche.extension.runtime | _none_ |
| regelsuche-integration-tests | maven | _none_ | _none_ |
| regelsuche-learning | gradle | de.regelsuche.evolution, de.regelsuche.inventory, de.regelsuche.mining | api project(':regelsuche-core'), api project(':regelsuche-search'), api project(':regelsuche-validation'), api project(':regelsuche-solver-ir'), api project(':regelsuche-math-algorithms') |
| regelsuche-learning | maven | de.regelsuche.evolution, de.regelsuche.inventory, de.regelsuche.mining | _none_ |
| regelsuche-math-algorithms | gradle | de.regelsuche.math.algorithms.cas, de.regelsuche.math.algorithms.completion, de.regelsuche.math.algorithms.equivalence, de.regelsuche.math.algorithms.linalg, de.regelsuche.math.algorithms.modular, de.regelsuche.math.algorithms.numeric, de.regelsuche.math.algorithms.polynomial, de.regelsuche.math.algorithms.registry | api project(':regelsuche-core'), api project(':regelsuche-validation') |
| regelsuche-math-algorithms | maven | de.regelsuche.math.algorithms.cas, de.regelsuche.math.algorithms.completion, de.regelsuche.math.algorithms.equivalence, de.regelsuche.math.algorithms.linalg, de.regelsuche.math.algorithms.modular, de.regelsuche.math.algorithms.numeric, de.regelsuche.math.algorithms.polynomial, de.regelsuche.math.algorithms.registry | _none_ |
| regelsuche-math-jas | gradle | de.regelsuche.math.jas | api project(':regelsuche-validation') |
| regelsuche-math-jas | maven | de.regelsuche.math.jas | _none_ |
| regelsuche-math-sympy | gradle | de.regelsuche.math.sympy | api project(':regelsuche-core') |
| regelsuche-math-sympy | maven | de.regelsuche.math.sympy | _none_ |
| regelsuche-optimization-sdk | gradle | de.regelsuche.math.algorithms.modular, de.regelsuche.sdk.optimization | api project(':regelsuche-search'), api project(':regelsuche-math-algorithms') |
| regelsuche-optimization-sdk | maven | de.regelsuche.math.algorithms.modular, de.regelsuche.sdk.optimization | _none_ |
| regelsuche-persistence-hibernate | gradle | de.regelsuche.persistence.relational | api project(':regelsuche-persistence'), api project(':regelsuche-learning'), api project(':regelsuche-validation'), implementation project(':regelsuche-core') |
| regelsuche-persistence-hibernate | maven | de.regelsuche.persistence.relational | _none_ |
| regelsuche-persistence | gradle | de.regelsuche.checkpoint, de.regelsuche.persistence | api project(':regelsuche-core') |
| regelsuche-persistence | maven | de.regelsuche.checkpoint, de.regelsuche.persistence | _none_ |
| regelsuche-plugin-api | gradle | de.regelsuche.plugin | api project(':regelsuche-search') |
| regelsuche-plugin-api | maven | de.regelsuche.plugin | _none_ |
| regelsuche-quality-aggregate | maven | _none_ | _none_ |
| regelsuche-quality | gradle | de.regelsuche.quality.jmh, de.regelsuche.quality.release, de.regelsuche.quality.supplychain, de.regelsuche.quality.tests | _none_ |
| regelsuche-quality | maven | de.regelsuche.quality.jmh, de.regelsuche.quality.release, de.regelsuche.quality.supplychain, de.regelsuche.quality.tests | _none_ |
| regelsuche-release | gradle | de.regelsuche.release | api project(':regelsuche-autopilot'), api project(':regelsuche-discovery'), implementation project(':regelsuche-math-algorithms') |
| regelsuche-release | maven | de.regelsuche.release | _none_ |
| regelsuche-search | gradle | de.regelsuche.didactic, de.regelsuche.scoring, de.regelsuche.scoring.cost, de.regelsuche.search, de.regelsuche.search.convergence, de.regelsuche.search.estimate, de.regelsuche.search.index, de.regelsuche.search.learning, de.regelsuche.search.memory, de.regelsuche.search.moves, de.regelsuche.search.policy, de.regelsuche.search.program, de.regelsuche.search.reachability, de.regelsuche.search.strategy, de.regelsuche.search.telemetry | api project(':regelsuche-core'), api project(':regelsuche-egraph') |
| regelsuche-search | maven | de.regelsuche.didactic, de.regelsuche.scoring, de.regelsuche.scoring.cost, de.regelsuche.search, de.regelsuche.search.convergence, de.regelsuche.search.estimate, de.regelsuche.search.index, de.regelsuche.search.learning, de.regelsuche.search.memory, de.regelsuche.search.moves, de.regelsuche.search.policy, de.regelsuche.search.program, de.regelsuche.search.reachability, de.regelsuche.search.strategy, de.regelsuche.search.telemetry | _none_ |
| regelsuche-solver-ir | gradle | de.regelsuche.solver.ir | api project(':regelsuche-core'), implementation project(':regelsuche-search'), implementation project(':regelsuche-validation'), implementation project(':regelsuche-math-algorithms') |
| regelsuche-solver-ir | maven | de.regelsuche.solver.ir | _none_ |
| regelsuche-solver-portfolio | gradle | de.regelsuche.solver.portfolio | api project(':regelsuche-solver-ir') |
| regelsuche-solver-portfolio | maven | de.regelsuche.solver.portfolio | _none_ |
| regelsuche-validation | gradle | de.regelsuche.equivalence, de.regelsuche.validation | api project(':regelsuche-core') |
| regelsuche-validation | maven | de.regelsuche.equivalence, de.regelsuche.validation | _none_ |

## Capability Overview

| ID | Label | Status | Types | Tests | Evidence |
|----|-------|--------|-------|-------|----------|
| rewrite-search | Rewrite-based term search | evidence-backed | 388 | 157 | 2 |
| equality-saturation | Equality saturation | evidence-backed | 11 | 5 | 2 |
| hypothesis-mining | Hypothesis and rule-candidate mining | evidence-backed | 164 | 98 | 2 |
| counterexample-search | Counterexample and validation search | implemented-and-tested | 83 | 55 | 0 |
| verified-trace-strategy-learning | Verified shortest-trace learning and conditional continuation dispatch | implemented-and-tested | 8 | 8 | 0 |
| proof-workflows | Proof workflow support | evidence-backed | 67 | 59 | 2 |
| discovery | Discovery path tracking | evidence-backed | 202 | 166 | 2 |
| persistence | Checkpointable search-job persistence | implemented-and-tested | 78 | 46 | 0 |
| web-workbench | Web workbench | implemented-and-tested | 168 | 108 | 0 |
| proof-carrying-showcase | Proof-carrying self-improvement showcase | implemented-and-tested | 18 | 12 | 0 |
| maven-build-contract | Maven and Testcontainers build contract | partial | 0 | 3 | 0 |
| static-reference-publication | Static reference-page publication | evidence-backed | 1 | 2 | 2 |
| historical-rediscovery-diagnostics | Historical rediscovery diagnostics | implemented-and-tested | 6 | 4 | 0 |
| polynomial-factorization | Exact polynomial factorization | implemented-and-tested | 88 | 56 | 0 |
| exact-matrix-representation | Exact matrix preparation and representation replay | implemented-and-tested | 22 | 11 | 0 |
| schematic-exact-plan-replay | Schematic exact-plan resolution, replay and budgeted source | implemented-and-tested | 30 | 23 | 0 |
| public-java-sdk | Standalone Java SDK and external mathematical extensions | evidence-backed | 10 | 5 | 2 |

## Architecture Claims

| ID | Category | Status | Violations |
|----|----------|--------|------------|
| no-infrastructure-in-core | architecture | passed | _none_ |
| search-kernel-clean | architecture | passed | _none_ |
| validation-kernel-clean | architecture | passed | _none_ |
| persistence-port-clean | architecture | passed | _none_ |
| acyclic-module-graph | architecture | passed | _none_ |
| port-interfaces-first | architecture | passed | _none_ |
| deterministic-discovery | quality | passed | _none_ |
| hibernate-isolated | architecture | passed | _none_ |

## Risk Areas

### Weakly Evidenced Capabilities

_None._

### Failed Claims

_None._

## Suggested Context Packs

| ID | File | Status | Token Estimate | Intended Use |
|----|------|--------|----------------|--------------|
| rewrite-search | `context-packs/rewrite-search.json` | evidence-backed | ~16690 | Review evidence and assertions for this capability |
| equality-saturation | `context-packs/equality-saturation.json` | evidence-backed | ~545 | Review evidence and assertions for this capability |
| hypothesis-mining | `context-packs/hypothesis-mining.json` | evidence-backed | ~7348 | Review evidence and assertions for this capability |
| counterexample-search | `context-packs/counterexample-search.json` | implemented-and-tested | ~4526 | Code review with implementation and test evidence |
| verified-trace-strategy-learning | `context-packs/verified-trace-strategy-learning.json` | implemented-and-tested | ~668 | Code review with implementation and test evidence |
| proof-workflows | `context-packs/proof-workflows.json` | evidence-backed | ~3315 | Review evidence and assertions for this capability |
| discovery | `context-packs/discovery.json` | evidence-backed | ~9882 | Review evidence and assertions for this capability |
| persistence | `context-packs/persistence.json` | implemented-and-tested | ~3720 | Code review with implementation and test evidence |
| web-workbench | `context-packs/web-workbench.json` | implemented-and-tested | ~6738 | Code review with implementation and test evidence |
| proof-carrying-showcase | `context-packs/proof-carrying-showcase.json` | implemented-and-tested | ~1167 | Code review with implementation and test evidence |
| maven-build-contract | `context-packs/maven-build-contract.json` | partial | ~154 | Tests exist but implementation may be incomplete |
| static-reference-publication | `context-packs/static-reference-publication.json` | evidence-backed | ~184 | Review evidence and assertions for this capability |
| historical-rediscovery-diagnostics | `context-packs/historical-rediscovery-diagnostics.json` | implemented-and-tested | ~518 | Code review with implementation and test evidence |
| polynomial-factorization | `context-packs/polynomial-factorization.json` | implemented-and-tested | ~4847 | Code review with implementation and test evidence |
| exact-matrix-representation | `context-packs/exact-matrix-representation.json` | implemented-and-tested | ~1397 | Code review with implementation and test evidence |
| schematic-exact-plan-replay | `context-packs/schematic-exact-plan-replay.json` | implemented-and-tested | ~1939 | Code review with implementation and test evidence |
| public-java-sdk | `context-packs/public-java-sdk.json` | evidence-backed | ~576 | Review evidence and assertions for this capability |

The full index is at `context-packs/index.json`.

## Consumption Guide

**CI workflow**: Run `generateAiKnowledgeIndex` (Gradle) or `ai-knowledge:generate` (Maven) and commit the `review-context.md` to track capability health over time.

**AI assistant**: Load `review-context.md` for an overview, then load a specific `context-packs/<capability-id>.json` for targeted review, bug-fixing or feature work.

**Architecture review**: Cross-reference the _Architecture Claims_ table with the _Risk Areas_ section to identify gaps that need attention.
