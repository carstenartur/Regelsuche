#!/usr/bin/env python3
"""Launch the unchanged predecessor's native AI-Knowledge gate with runtime settings."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import urllib.parse

root = Path('/dev/shm/regelsuche-pr1088-predecessor')
evidence = Path('/dev/shm/regelsuche-pr1088-ci')
extractor = Path('/dev/shm/regelsuche-pr1088-extractor')
env = os.environ.copy()
env['JAVA_HOME'] = '/workspace/scratch/4ae3214a4451/runtime/toolchains/jdk-25.0.2+10'
env['GRADLE_USER_HOME'] = '/dev/shm/regelsuche-pr1088-gradle'
env['AI_KNOWLEDGE_EXTRACTOR_ENABLED'] = 'true'
env['PATH'] = env['JAVA_HOME'] + '/bin:' + env.get('PATH', '')
temp = Path('/dev/shm/regelsuche-pr1088-temp')
temp.mkdir(exist_ok=True)
env['TMPDIR'] = str(temp)
opts = ['-XX:-UsePerfData', '-Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts',
        '-Djava.net.preferIPv4Stack=true', '-Djava.io.tmpdir=' + str(temp)]
for protocol, key in [('https', 'HTTPS_PROXY'), ('http', 'HTTP_PROXY')]:
    proxy = urllib.parse.urlparse(env[key])
    assert proxy.hostname and not proxy.username and not proxy.password
    opts.extend(['-D' + protocol + '.proxyHost=' + proxy.hostname,
                 '-D' + protocol + '.proxyPort=' + str(proxy.port or 80)])
env['JDK_JAVA_OPTIONS'] = ' '.join(opts)
initializer = root / 'ai-knowledge/baseline-history/2026-09-20-main81ea9ac7-java25-extractor.init.gradle'
command = ['./gradlew', '--no-daemon', '--no-configuration-cache', '--max-workers=2',
           '-Dorg.gradle.jvmargs=-Xmx1024m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8',
           '--init-script', str(initializer), '-PuseLocalAiKnowledgeExtractor=true',
           '-PaiKnowledgeExtractorCheckout=' + str(extractor),
           'aiKnowledgeCheck', '--console=plain', '--stacktrace']
def git(path, *args):
    return subprocess.check_output(['git', *args], cwd=path, text=True).strip()
assert git(root, 'rev-parse', 'HEAD') == 'd7ec8b51d164dc58dbb3e9e328af8bb356425b93'
assert git(extractor, 'rev-parse', 'HEAD') == 'b409bed957c31d63ce7b6ef37205890f0f0ebd9a'
assert git(root, 'status', '--porcelain=v1', '--untracked-files=all') == ''
assert git(extractor, 'status', '--porcelain=v1', '--untracked-files=all') == ''
receipt = {
    'sourceCommit': git(root, 'rev-parse', 'HEAD'),
    'sourceTree': git(root, 'rev-parse', 'HEAD^{tree}'),
    'extractorCommit': git(extractor, 'rev-parse', 'HEAD'),
    'extractorTree': git(extractor, 'rev-parse', 'HEAD^{tree}'),
    'sourceStatusBefore': '', 'extractorStatusBefore': '',
    'startedAt': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'cwd': str(root), 'command': command, 'shellCommand': shlex.join(command),
    'runtimeEnvironment': {k: env[k] for k in ['JAVA_HOME', 'GRADLE_USER_HOME',
                                             'AI_KNOWLEDGE_EXTRACTOR_ENABLED', 'TMPDIR', 'JDK_JAVA_OPTIONS']},
    'initializerSha256': hashlib.sha256(initializer.read_bytes()).hexdigest(),
    'runtimeLauncherSha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'javaTruststoreSha256': hashlib.sha256(Path('/etc/ssl/certs/java/cacerts').read_bytes()).hexdigest(),
    'status': 'running'
}
receipt_path = evidence / 'native-gate-receipt.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
try:
    with (evidence / 'aiKnowledgeCheck.log').open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log,
                                stderr=subprocess.STDOUT, timeout=600)
    receipt['exitCode'] = result.returncode
    receipt['status'] = 'completed'
except subprocess.TimeoutExpired:
    receipt['exitCode'] = 124
    receipt['status'] = 'timed-out'
finally:
    receipt['finishedAt'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt['sourceStatusAfter'] = git(root, 'status', '--porcelain=v1', '--untracked-files=all')
    receipt['extractorStatusAfter'] = git(extractor, 'status', '--porcelain=v1', '--untracked-files=all')
    receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['status', 'exitCode', 'sourceStatusAfter', 'extractorStatusAfter']}))
raise SystemExit(receipt['exitCode'])
