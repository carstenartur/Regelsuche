# Whole-branch independent recurrence lifecycle review

Review date: 2026-11-03.

## Scope and verdict

Reviewed all eight added files in the diff from `6db96792e249eefb7cb9db20fb9522f7d340eed3` to `a4ff3520f7b34c7c383de11ed6be0e3d9a971fcd`, together with the binding design/implementation plan, relevant existing public learner/snapshot code, inherited process-accounting transport, polynomial auditor helpers, and the supplied task reports and scoped review reports. The root subsequently reported publication as `0d218aec11c8e610bf0097538c22b6c06eaa483b`, with identical tree `fb5cbf1bd6b498ec5b3c303199a00527d45ce42a`; this review is of the fixed source contents, not a claim to independently authenticate remote publication.

**Specification verdict: PASS for the implementation and contracts.**

**Code-quality verdict: PASS.**

**Ready-to-integrate verdict: YES, conditional on the actual registered 27-lifecycle/657-query experiment, separate successful evidence verification, and the unchanged required CI gates on the final published tree.** This is not authorization to omit those gates or to infer performance benefits before inspecting the measurements. Before this report was finalized, the root reported a successful full run and separate verification. I inspected the resulting metadata, supervisor receipt, sequence inventory, saved verification output, and median summary as described below; I did not rerun verification. Required CI remains pending.

No new Critical, Important, or Minor defect was identified. No implementation edit, test rerun, benchmark execution, or subagent was performed. This review report is the only file written.

## Findings by severity

### Critical

None found.

### Important

None found.

### Minor

No new finding. The earlier adapter-specific test-coverage suggestion remains accurately characterized and nonblocking:

- `regelsuche-learning/src/test/java/de/regelsuche/evolution/RecurrenceKnowledgeComparisonWorkerTest.java:92` changes snapshot content without changing the content-addressed filename, so that particular adapter test proves digest rejection rather than independently isolating mathematical reproof. The actual adapter calls the public loader at `regelsuche-learning/src/main/java/de/regelsuche/evolution/RecurrenceKnowledgeComparisonWorker.java:119`; `CumulativeTaskKnowledge.restore` invokes recurrence restoration/reproof. The supplied ledger records the existing real recurrence-family tests as the mathematical reproof coverage. Requiring another duplicate adapter-level case is not necessary to accept this branch.

## Contract and implementation assessment

### Existing public learner and real process lifecycle

The Java adapter is a thin boundary. Initialization, recurrence learning, family generalization, snapshot persistence/restoration, and query solving all invoke the existing public APIs. In particular, `RecurrenceKnowledgeComparisonWorker.java:81`, `:89`, `:107`, `:119`, and `:142` delegate the substantive operations. Returned laws at `:147` come from the actual execution's verified proposal and initial value. I found no replacement learner, expected-answer dispatch, direct recurrence formula shortcut, or modification of solver thresholds.

The adapter's state machine prevents producers from querying, consumers from learning, repeated initialization/restoration, baseline snapshot restoration, exact-only family generalization/restoration, and operations after save. All handled parse/IO/runtime failures poison the worker. Rejected paid learning outcomes retain the production next-generation accounting rather than being silently discarded. Public LearningFailure receipts retain known work and completed lessons at `RecurrenceKnowledgeComparisonWorker.java:183`.

The Python lifecycle starts a baseline consumer directly. Learned profiles perform both registered learning blocks, optionally generalize, save, close the producer, then launch a distinct consumer and restore/reprove the snapshot before querying (`run_recurrence_knowledge.py:253`). Process identity is retained in both startup records and wait4 receipts; accounting requires distinct producer and consumer PIDs at `:400`. Query responses must preserve the generation and acquisition/setup ledger. Thus a successful run cannot qualify merely by simulating learned preparation in the same JVM.

### Registered experiment and input stream

The committed JSON contains the specified profiles, lengths `[1,8,64]`, three repetitions, budgets, timeouts, heap option, no warmups, two p=1/p=2 lessons, and p=3/p=5 family validation. I inspected the explicit query stream against the existing family test: eight rounds of parameters `4,7,-3,0,11,-7,1/2`, then the one-dimensional negative control; initial states and task degree match. The rotating schedule at `run_recurrence_knowledge.py:104` executes actual prefixes, producing 27 lifecycles and 657 planned requests.

`load_protocol` requires the registered byte hash before interpreting the protocol; execution independently requires those protocol bytes to exist in HEAD. This prevents a different query stream or changed budgets from silently using the registered label. The Python task dimension bound at `:59` is now 1..3 and its regression covers rejection of dimension 4. This aligns the meaningful dimension boundary with the public transition type while leaving the registered 1D/2D experiment unchanged.

### Mathematical audit versus experiment qualification

`audit_response` binds each response to its query ID, exact task, profile, generation, budget, and coherent solved/reused/outcome flags. Positive laws must have a nonconstant sparse polynomial within the requested variables and degree. Its Fraction-based simultaneous affine substitution constructs every transformed variable from the original variables, then checks the full polynomial identity and independently evaluates the initial state (`run_recurrence_knowledge.py:159` through `:187`). It accepts alternate valid laws. It does not require string identity with the production solver's preferred polynomial.

Unsolved outcomes must have no law and coherent flags. The resulting valid-unsolved classification is correctly presented as receipt consistency, not a proof that no law exists. That limitation matters for ordinary users interpreting the negative controls and is stated both in the research document and generated report.

Mathematical validity, complete measurement, equal audited quality, and registered arm qualification are distinct. The final fixes preserve that distinction: `account_sequence` checks exact-only nonreuse and family reuse for every audited solved row at `:390`, while `registeredQualityAccepted` also requires the registered solved vector at `:427`. `paired_comparisons` at `:449` requires complete measurements and equal full vectors before applying the registered qualification gate. Wrong arm reuse can therefore remain inspectable as a mathematically valid measurement without receiving ratios. All-unsolved equality cannot masquerade as experimental success.

### Resource accounting, failures, and denominators

`ReceiptSession` publishes its owned-process receipt even if construction fails before READY. The lifecycle retains the object before initialization, so final cleanup can still reach it. The inherited AccountedSession uses wait4 rather than prematurely reaping with Popen.wait/poll; its CPU receipt covers process user/system resources, including JVM threads and startup/shutdown. Each sequence separately records controller process CPU, and full lifecycle CPU is their sum. Peak worker RSS is the maximum observed worker peak, not a sum or a heap/algorithm-memory claim.

The sequence timer includes initialization, acquisition, persistence, both process boundaries where applicable, transport, external exact auditing, and final shutdown. Lifecycle accounting checks that the total contains recorded operation and row timing. Logical accounting includes historical acquisition once, actual restore work, and every audited query. It remains a separate metric.

On an unavailable setup worker, the query loop writes blocked rows for the planned prefix. On ordinary transport timeout/failure, inherited transport closes and accounts for the worker, returns the failed response, and marks later requests blocked. The rows retain invalid audit results instead of converting them to successful zero-cost work. Complete protocol operations must have their actual request, response, and transport evidence (`run_recurrence_knowledge.py:329`), and missing operations, rows, receipts, bad shutdowns, errors, or failed audits prevent complete qualification. Negative controls remain part of the full vector and query count.

The outer supervisor's command wall boundary includes runtime snapshotting and child report/manifest writes. Its own final receipt write is explicitly excluded. The child records its actual canonical invocation, and verification binds it to the supervisor receipt; the outer CPU scope is separately labeled as child plus reaped descendants, including the controller. These scopes avoid confusing logical work, worker CPU, controller CPU, wall time, and process peak memory.

### Evidence binding and offline verification

Execution uses a clean committed source identity, retained protocol bytes, exact ordered runtime copies/inventory, Java executable/release hashes, and retained classpath input bytes. Workers launch from the copied classpath, not later mutable original build directories. The implementation distinguishes source provenance from compiled runtime bytes; the root's fresh native production build remains the procedural check that connects them. The driver rejects ordinary test-class paths, and no compatibility-bytecode substitution is present in the reviewed change.

Snapshots are retained and hashed, and save/restore responses must agree on their generation and content hash. Query-side ledger/generation binding prevents silently changing the learned state during the sequence.

Offline verification checks recursive manifest inventory and digests, runtime inventory/hash, canonical command/invocation metadata, exact scheduled order/counts, all 657 rows, required operation inventory, stderr and snapshot inventory, saved/restored snapshot traces, recomputed audits/accounting, and the derived summary/comparisons. It checks the supervisor's manifest binding and wall/CPU receipt shape and scope. Original path strings are validated lexically to preserve relocated evidence. The verifier can accept a faithfully retained failed experiment without calling it successful; that is the intended distinction.

These hashes establish retained-artifact consistency and provenance references, not an external signature or proof against an attacker rewriting every artifact coherently. No stronger authenticity claim is made by this review or required for the described local developmental experiment.

### Tests, documentation, and historical scope

The focused tests meaningfully cover the intended risk boundaries: strict adapter input/state behavior, real public learn/generalize/save/restore/run, paid acquisition cutoffs, immutable query generation, rational and negative queries, valid alternate laws, simultaneous affine substitution, wrong identities/budgets/laws, failed READY receipt retention, query timeout rows, missing protocol-operation evidence, wrong registered reuse, missing process receipts, incomplete schedules, and runtime/manifest/summary/command tampering.

The source review observed only the eight new files in the whole-branch diff. Historical learned-schema-v2 code/protocol/results and CI definitions are unchanged. Reused helpers are not edited. The research document explains native reproduction, actual process boundaries, retained failures, conditional ratios, public-development scope, and the bounded baseline's full-basis work. It does not advertise a wall/CPU benefit merely because logical work improved.

## Evidence read and deliberately unjudged behaviors

The supplied reports state that native Java 25 focused tests passed (19 tests), focused Python tests passed after the final dimension-boundary addition (18 tests), and a real FAMILY length-1 smoke used distinct JVMs with a valid external audit. I read these as supplied evidence and inspected the corresponding implementation/test sources; I did not independently rerun them.

I specifically decline to certify:

- An independent rerun of the final experiment or offline verifier, or a new statistical/performance study. I inspected the completed evidence listed below and relied on the root's reported verifier exit status; the complete semantic verifier was not executed a second time in this read-only review.
- Required CI results on the published tree, resolution of broader historical environment prerequisites, or PR merge readiness before those gates pass.
- Cryptographic authenticity of the remote Git publication, exact remote branch ancestry, or that the prior PR has actually merged; those are integration-owner checks.
- A reproducible-build guarantee linking source hashes to compiled classes, JDK/dependency supply-chain authenticity, or machine-level isolation. Source identity and exact executed runtime bytes are separately bound, and the fresh-build procedural gate remains explicit.
- Behavior under controller SIGKILL, power loss, out-of-disk failures, OS accounting failure, or arbitrary adversarial corruption of all evidence plus its hashes. Ordinary worker transport/startup/timeout failures are covered by the reviewed retention paths; abrupt loss of the controlling process is not promised as transactional durability.
- General superiority across recurrence families, sealed-holdout validity, precise statistical uncertainty from three repetitions, intrinsic algorithm working-set memory, or a no-law theorem from an unsolved receipt.

These boundaries do not block the implementation verdict. They identify the independent execution/integration gates and the documented limits that must remain in the final user-facing result.

## Completed execution evidence inspected before finalization

The root subsequently reported both the registered execution and separate `--verify` exited zero. I read the actual artifacts in `/workspace/scratch/297dfcdf4103/recurrence-lifecycle-20261103-run1`, plus the saved verification and medians under `lifecycle-evidence`. The metadata names published source `0d218aec11c8e610bf0097538c22b6c06eaa483b` and tree `git:fb5cbf1bd6b498ec5b3c303199a00527d45ce42a`. The supervisor receipt records return code zero, a complete child invocation, a manifest hash, and a 42.272499961-second command wall boundary.

Direct inspection/counting of the retained sequence records found 27 sequences, 657 rows, and 45 worker receipts. All 27 recorded accountings are complete and registered-qualifying; their audited-query totals are 657 and solved totals are 576. The saved separate-verifier output agrees: each profile has nine complete/qualified lifecycles, 219 audited/retained requests, and 192 solved requests. This is inspection of recorded output and consistency counts, not a claim that I independently recomputed all semantic audits.

The recorded result is a negative elapsed-time/CPU result despite the logical-work reduction. For length 64, the median FAMILY wall is 2.000345771 seconds versus BASELINE 1.519385702 seconds; median full CPU is 5.190277138 versus 4.345012663 seconds. FAMILY total logical work is 75,595 versus BASELINE 264,736, and both solve 56/64. FAMILY's recorded median worker peak is lower (128.84375 MiB versus 208.640625 MiB), with the documented process-peak interpretation. These observations support explicitly reporting that the tested lifecycle has not amortized wall or CPU by 64 requests. They do not locate a later break-even point or establish an intrinsic-memory advantage.

The experiment and verification conditions now have observed retained evidence plus the root's execution-status confirmation. The remaining integration condition is the unchanged required CI gates and correct PR ancestry/merge order. No source revision was requested by this review.
