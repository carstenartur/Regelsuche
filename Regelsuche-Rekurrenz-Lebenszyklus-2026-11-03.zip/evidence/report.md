# Recurrence knowledge lifecycle evidence

PUBLIC_DEVELOPMENT: known development family; no sealed holdout or general CAS claim.

| Profile | Complete / planned lifecycles | Audited / retained queries | Solved | Total lifecycle wall (s) | Whole worker CPU (s) | Maximum worker RSS (bytes) |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| BASELINE | 9 / 9 | 219 / 219 | 192 | 9.005699 | 22.241629 | 222162944 |
| EXACT_FROZEN | 9 / 9 | 219 / 219 | 192 | 16.749235 | 38.863195 | 218218496 |
| FAMILY | 9 / 9 | 219 / 219 | 192 | 15.217801 | 34.90556 | 140128256 |

Every prefix and repetition starts fresh workers; learned profiles acquire, save, shut down,
then restore/reprove in a distinct consumer. Baseline pays its own empty initialization.
All 657 planned requests, including negative outcomes and blocked failures, remain in rows.
Sequence wall includes controller IO and exact law audits through worker shutdown.
Worker CPU includes every owned JVM thread from startup through shutdown; controller CPU is separate.
RSS is the maximum worker process peak across sequential workers, not a sum or intrinsic heap requirement.
Logical work counts historic acquisition once, actual restore, and query work; elapsed time is never reconstructed from it.
Positive laws are independently proved; coherent negative receipts are retained without certifying the absence of any law.
Ratios require complete operations/receipts/rows, equal complete audited solved vectors, and registered development acceptance (1, 7, 56 solved for lengths 1, 8, 64).
Registered arm acceptance additionally requires FAMILY to reuse every solved request and EXACT_FROZEN to reuse none.
Full lifecycle CPU adds the separately measured controller process CPU (including exact audit) to all worker CPU.

| Learned profile | Length | Repetition | Qualified | Wall speedup | Worker CPU speedup | Full CPU speedup | Logical work speedup |
| --- | ---: | ---: | --- | ---: | ---: | ---: | ---: |
| EXACT_FROZEN | 1 | 0 | True | 0.3333783697998101 | 0.3102972000245106 | 0.31046110944406474 | 0.17792103142626914 |
| EXACT_FROZEN | 1 | 1 | True | 0.4856782637811649 | 0.42864102603453574 | 0.42860926929970594 | 0.17792103142626914 |
| EXACT_FROZEN | 1 | 2 | True | 0.4401571647151586 | 0.40940455847275403 | 0.4092060960865413 | 0.17792103142626914 |
| EXACT_FROZEN | 8 | 0 | True | 0.5118442399630238 | 0.5227659079686996 | 0.5233650093040938 | 0.6175663311985361 |
| EXACT_FROZEN | 8 | 1 | True | 0.5230564135141459 | 0.5922197891466612 | 0.5927247161700906 | 0.6175663311985361 |
| EXACT_FROZEN | 8 | 2 | True | 0.5306189635070225 | 0.5471742582798392 | 0.5469026212560902 | 0.6175663311985361 |
| EXACT_FROZEN | 64 | 0 | True | 0.47923576526322853 | 0.5997389225638203 | 0.6008920647114452 | 0.9261425652794493 |
| EXACT_FROZEN | 64 | 1 | True | 0.7080914085243043 | 0.7210275789409383 | 0.7233150764706439 | 0.9261425652794493 |
| EXACT_FROZEN | 64 | 2 | True | 0.7590803850935863 | 0.8059363757003293 | 0.8070403834646191 | 0.9261425652794493 |
| FAMILY | 1 | 0 | True | 0.5162302673541956 | 0.4511487551440464 | 0.45129841061148146 | 0.12441889950131012 |
| FAMILY | 1 | 1 | True | 0.4346577890683239 | 0.4064271439164431 | 0.4062843530436856 | 0.12441889950131012 |
| FAMILY | 1 | 2 | True | 0.4080978591787564 | 0.3760898401524941 | 0.37598348974296625 | 0.12441889950131012 |
| FAMILY | 8 | 0 | True | 0.580055149780714 | 0.5637188607141862 | 0.564468970383959 | 0.8275784416754242 |
| FAMILY | 8 | 1 | True | 0.5706890740076592 | 0.6074171039197165 | 0.6080356074646832 | 0.8275784416754242 |
| FAMILY | 8 | 2 | True | 0.5388252408342822 | 0.5450259387669096 | 0.5456052818955995 | 0.8275784416754242 |
| FAMILY | 64 | 0 | True | 0.6889075940212016 | 0.8218666581213155 | 0.82297362496001 | 3.502030557576559 |
| FAMILY | 64 | 1 | True | 0.7243944049939599 | 0.8367633070776584 | 0.8371446355317915 | 3.502030557576559 |
| FAMILY | 64 | 2 | True | 0.759561533824444 | 0.8516844859505556 | 0.852915316471701 | 3.502030557576559 |

A speedup below one is a measured regression. No performance acceptance is predeclared.
The outer supervisor measures this entire child through reports and manifest writing.
command-receipt.json is written after that measured boundary; its own write is excluded.
