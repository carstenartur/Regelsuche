# Regelsuche – vollständiger Rekurrenz-Lebenszyklus, 3. November 2026

Dieses Paket enthält den vollständigen festgelegten Entwicklungsversuch mit 27 Durchgängen, 657 Aufgaben und 45 echten Java-Prozessen. Alle Durchgänge waren vollständig, erfüllten die vorgesehene Aufgabenqualität und wurden separat nachgeprüft.

## Ergebnis

Bei 64 Aufgaben lösen alle drei Verfahren 56 Aufgaben. Die gelernte Familie benötigt 75.595 logische Arbeitseinheiten gegenüber 264.736 bei der vorhandenen Synthesebasis. Im vollständigen Lebenszyklus beträgt die gemessene Medianzeit jedoch 2,000 s gegenüber 1,519 s; die gesamte CPU-Zeit 5,190 s gegenüber 4,345 s. Innerhalb der geprüften Folgenlängen ist daher noch keine Amortisation von Laufzeit oder CPU nachgewiesen. Der Versuch und seine Eingaben wurden nach diesem Ergebnis nicht angepasst.

## Inhalt

- `evidence/`: unveränderte vollständige Messdaten einschließlich aller tatsächlichen Runtimebytes, Anfragen, Gesetze, Prozessbelege, gespeicherten Wissensstände, Berichte, Hashinventare und äußerem Kommandobeleg.
- `results.md`: ausführlicher Messbericht mit Grenzen und Reproduktion.
- `numeric-summary.json`: alle 27 Bilanzen, Mediane und paarweisen Vergleiche.
- `environment.json`: beobachtete gemeinsame Ausführungsumgebung.
- `verification/`: separate erfolgreiche Nachprüfung, gezielte Java-/Python-Testbelege und unabhängiges Code-Review.

## Quellstand und Nachprüfung

Quelle: https://github.com/carstenartur/Regelsuche/tree/0d218aec11c8e610bf0097538c22b6c06eaa483b

Der veröffentlichte Quellstand enthält den Prüfer. Nach dem Entpacken aus einem Checkout dieses Standes ausführen:

```bash
python -m scripts.external_polynomial_comparison.run_recurrence_knowledge --verify /absoluter/pfad/zum/entpackten/evidence
```

Die Nachprüfung funktioniert auch nach Verschieben des Pakets. Sie benötigt keine vorhandenen ursprünglichen Workspacepfade. Für eine erneute Ausführung des Experiments sind Java 25 und der im Bericht beschriebene Produktionsbuild nötig. Die Nachprüfung selbst verwendet die gespeicherten Daten und exakte Python-Arithmetik.

Die vollständige Manifestbindung lautet `sha256:d18cee6a3db145243881d6537f83278453328c353daf3012957e9ea6dd267ec6`. Der abschließende äußere Kommandobeleg liegt definitionsgemäß außerhalb dieses Manifests und bindet dessen Hash. Alle historischen v2-Experimente bleiben unverändert.

Dies ist eine bekannte Entwicklungsfamilie mit drei Wiederholungen je Bedingung auf einem geteilten Ausführungssystem, kein versiegelter Holdout oder allgemeiner Effizienznachweis. Speicherwerte sind Prozess-RSS-Spitzen, keine intrinsischen Heap- oder Gesamtmaschinenwerte.
